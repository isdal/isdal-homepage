/**
Copyright (C) 2008  Tomas Isdal

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package net.isdal.newlineremover.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.ChangeListener;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.KeyboardListener;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.Widget;

public class NewLineRemoverGWT implements EntryPoint, ChangeListener,
		KeyboardListener {

	TextArea inputArea;
	TextArea outputArea;

	public void onModuleLoad() {

		Grid panel = new Grid(1, 2);

		inputArea = new TextArea();
		inputArea.setWidth("97%");
		inputArea.setReadOnly(false);
		inputArea.addChangeListener(this);
		inputArea.addKeyboardListener(this);
		panel.setWidget(0, 0, inputArea);
		// hack to make the cells each have size 50%
		// size 50% doesn't seem to work... (GWT 1.5RC1)
		panel.getCellFormatter().setWidth(0, 0, "1500px");
		panel.getCellFormatter().setHeight(0, 0, "100%");

		outputArea = new TextArea();
		outputArea.setReadOnly(true);
		outputArea.setWidth("97%");
		panel.setWidget(0, 1, outputArea);
		panel.getCellFormatter().setWidth(0, 1, "1500px");
		panel.getCellFormatter().setHeight(0, 1, "100%");
		this.updateSize();
		RootPanel.get().add(panel);
		inputArea.setFocus(true);
	}

	public void onChange(Widget sender) {
		updateOutput();
	}

	private void updateSize() {
		int lines = Math.max(inputArea.getText().split("\n").length, outputArea
				.getText().split("\n").length);
		lines = Math.max(lines + 10, 20);

		inputArea.setVisibleLines(lines);
		outputArea.setVisibleLines(lines);
	}

	private void updateOutput() {
		boolean addedNewLine = false;
		String input = inputArea.getText();

		String[] split = input.split("\n");
		StringBuffer output = new StringBuffer();
		int linenum = 0;
		for (String line : split) {
			line = trim(line);
			if (line.length() == 0) {
				if (!addedNewLine) {
					output.append("\n\n");
					addedNewLine = true;
				}
			} else {
				addedNewLine = false;
				output.append(line + " ");
			}
			linenum++;
		}
		outputArea.setText(output.toString());
		updateSize();
	}

	/* remove leading whitespace */
	public static String ltrim(String source) {
		return source.replaceAll("^\\s+", "");
	}

	/* remove trailing whitespace */
	public static String rtrim(String source) {
		return source.replaceAll("\\s+$", "");
	}

	/* replace multiple whitespaces between words with single blank */
	public static String itrim(String source) {
		return source.replaceAll("\\b\\s{2,}\\b", " ");
	}

	/* remove all superfluous whitespaces in source string */
	public static String trim(String source) {
		return itrim(ltrim(rtrim(source)));
	}

	public void onKeyDown(Widget sender, char keyCode, int modifiers) {
		updateOutput();
	}

	public void onKeyPress(Widget sender, char keyCode, int modifiers) {
	}

	public void onKeyUp(Widget sender, char keyCode, int modifiers) {
		updateOutput();
	}

}
