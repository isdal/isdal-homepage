package al.isd.interviews.facebook.lz77;

import static al.isd.interviews.facebook.lz77.LZ77Utils.log;

/**
 * This class maintains a buffer of the last bytes written to it.
 * 
 * @author Tomas Isdal (t@isd.al)
 * 
 */
public class RotatingBuffer {
    private final byte[] backingArray;
    private int currentWritePos = 0;

    /**
     * Create a new rotating buffer that keeps a history of <capacity> items.
     * 
     * @param capacity
     *            the capacity of the buffer.
     */
    public RotatingBuffer(int capacity) {
        backingArray = new byte[capacity];
    }

    /**
     * Copy bytes from this buffer into the supplied buffer starting at the
     * supplied offset.
     * 
     * @param buffer
     *            the target buffer.
     * @param realtiveOffset
     *            the offset to start reading from.
     * @param len
     *            the number of bytes to copy.
     * @return the number of bytes copied.
     */
    public int copy(byte[] buffer, int realtiveOffset, int len) {
        int preCopyWritePos = currentWritePos;
        if (LZ77Utils.ENABLE_LOGGING) {
            log("copy: len=%d off=%d", len, realtiveOffset);
        }
        for (int i = 0; i < len; i++) {
            byte value = readByOffset(preCopyWritePos, realtiveOffset - i);
            buffer[i] = value;
            write(value);
        }
        return len;
    }

    /**
     * Read a byte from the buffer. A relative offset of 0 will return the last
     * byte written. An offset of 1 returns the previous byte and so on.
     * 
     * @param relativeOffset
     *            the offset to read from.
     * @return the byte at the specified offset.
     */
    byte read(int relativeOffset) {
        return readByOffset(currentWritePos, relativeOffset);
    }

    /**
     * Read a byte based on the offset from the supplied write position.
     * 
     * @param writePos
     *            The write position to base the offset calculation on.
     * @param relativeOffset
     *            the offset to read from.
     * @return the byte at the specified offset based on the supplied write
     *         position.
     */
    private byte readByOffset(int writePos, int relativeOffset) {
        if (relativeOffset > backingArray.length) {
            throw new ArrayIndexOutOfBoundsException(String.format(
                    "Offset too large: offset=%d len=%d", relativeOffset, backingArray.length));
        }
        int pos = writePos - 1 - relativeOffset;
        if (pos < 0) {
            pos += backingArray.length;
        }
        byte value = backingArray[pos];
        if (LZ77Utils.ENABLE_LOGGING) {
            log("reading:\tpos=%d value=%d", pos, value);
        }
        return value;
    }

    /**
     * Write a byte to the buffer.
     * 
     * @param value
     *            the byte to write.
     */
    public void write(byte value) {
        backingArray[currentWritePos] = value;
        currentWritePos++;
        // Check for wrap.
        if (currentWritePos >= backingArray.length) {
            currentWritePos = 0;
        }
    }
}
