package al.isd.interviews.facebook.lz77.bitutils;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

/**
 * Convenience class for reading bits from an input stream.
 * 
 * @author Tomas Isdal (t@isd.al)
 */
public class BitInputStream {
    private final InputStream in;

    // Field storing a partially read byte in case reads cross byte
    // boundaries. Will only contain values between 0 and 255.
    // @VisibleForTesting
    int partiallyReadByte = 0;

    // Position of the next unread bit in the buffer.
    // @VisibleForTesting
    int partialReadPos = 8;

    public BitInputStream(InputStream in) {
        this.in = in;
    }

    /**
     * Close the source stream.
     * 
     * @throws IOException
     */
    public void close() throws IOException {
        in.close();
    }

    /**
     * Read up to 31 bits and returns the result as an int.
     * 
     * @param numBits
     *            number of bits to read.
     * @return The integer value of those bits.
     * @throws IOException
     *             if an I/O error occurs.
     * @throws EOFException
     *             if the end of file is reached.
     */
    public int readBits(int numBits) throws EOFException, IOException {
        if (numBits > 31) {
            throw new IllegalArgumentException("Maximum number of bits exceeded (" + numBits
                    + " > 31)");
        }
        if (numBits <= 0) {
            throw new IllegalArgumentException("Number of bits must be positive (" + numBits
                    + " <=0)");
        }
        int result = 0;
        int bitsRead = 0;
        while (bitsRead < numBits) {
            int bitsLeft = numBits - bitsRead;
            if (bitsLeft <= 8 - partialReadPos) {
                /*
                 * 1: We have enough bits in the partialRead buffer to complete
                 * the read: just add the bits we are interested in to the
                 * result and return.
                 */
                return readPartialValue(result, bitsLeft);
            } else {
                /*
                 * 2: We don't have enough bits in the buffer, copy the
                 * remaining bits to the result and read the next byte from the
                 * input stream.
                 */
                int toRead = 8 - partialReadPos;
                bitsRead += toRead;
                result = readPartialValue(result, toRead);
                // Read a byte and put in the buffer.
                partialReadPos = 0;
                partiallyReadByte = in.read();
                if (BitUtils.ENABLE_LOGGING) {
                    BitUtils.log("read from stream: ", partiallyReadByte);
                }

                if (partiallyReadByte == -1) {
                    throw new EOFException();
                }
            }
        }
        throw new IllegalStateException("Reached illegal read state. " + numBits);
    }

    /**
     * Read a len bits from the buffered byte and copy them into the result.
     * 
     * @param result
     *            the current value to append to.
     * @param len
     *            the number of bits to read.
     * @return the incoming result appended 'from the right' with the value of
     *         the len bits read from the buffer.
     */
    // @VisibleForTesting
    int readPartialValue(int result, int len) {
        result = BitInputStream.readPartialValue(partiallyReadByte, partialReadPos, result, len);
        partialReadPos += len;
        return result;
    }

    /**
     * Returns a mask used to filter out a subset of a byte.
     * 
     * @param start
     *            the bit at which the mask should start.
     * @param len
     *            the number of bits to set.
     * @return
     *         an int with bits set according to the supplied parameters.
     */
    // @VisibleForTesting
    static int getMask(int start, int len) {
        int mask = 0xFF;
        mask = 0xFF & mask << (8 - len);
        mask = mask >>> start;
        return mask;
    }

    /**
     * Read a len bits from the source byte and copy them into the result.
     * 
     * @param source
     *            the byte to read from.
     * @param sourceOffset
     *            the offset to start reading at.
     * @param result
     *            the current value to append to.
     * @param len
     *            the number of bits to read.
     * @return the incoming result appended 'from the right' with the value of
     *         the len bits read from the source.
     */
    // @VisibleForTesting
    static int readPartialValue(int source, int sourceOffset, int result, int len) {
        // Shift the result left to make room for the new data.
        result = result << len;
        // Read len bits for the partial value.
        int value = source & getMask(sourceOffset, len);
        // Shift the value to the right aligned.
        value = value >>> 8 - len - sourceOffset;
        // Copy the new data into the result.
        result |= value;
        if (BitUtils.ENABLE_LOGGING) {
            BitUtils.log("source value:\t", source);
            BitUtils.log("read partial value: ", value);
            BitUtils.log("result:\t\t", result);
        }
        return result;
    }
}