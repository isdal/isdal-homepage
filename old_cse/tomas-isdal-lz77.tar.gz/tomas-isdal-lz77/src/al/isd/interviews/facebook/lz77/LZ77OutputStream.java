package al.isd.interviews.facebook.lz77;

import static al.isd.interviews.facebook.lz77.LZ77Utils.log;

import java.io.IOException;
import java.io.OutputStream;

import al.isd.interviews.facebook.lz77.bitutils.BitOutputStream;

/**
 * This class implements a stream filter for writing compressed data in
 * the 'Almost-LZ77' file format.
 * 
 * @author Tomas Isdal (t@isd.al)
 */
public class LZ77OutputStream extends OutputStream {
    private long bytesWritten = 0;
    // The current word we are working on.
    private int[] currentWord = new int[LZ77Utils.MAX_W_SIZE];
    // The position in the word array for the next byte.
    private int currentWordLength = 0;

    private final LZ77Dictionary dict;
    private final BitOutputStream out;

    /**
     * Create a new LZ77 output stream filter around the provided OutputStream.
     * 
     * @param out
     *            the output stream to write LZ77 compressed data to.
     */
    public LZ77OutputStream(OutputStream out) {
        this.out = new BitOutputStream(out);
        this.dict = new LZ77Dictionary(LZ77Utils.ADDRESSABLE_BYTES, LZ77Utils.MAX_W_SIZE,
                LZ77Utils.CLEAR_GARBAGE_FREQUENCY);
    }

    /*
     * @see java.io.OutputStream#close()
     */
    @Override
    public void close() throws IOException {
        // Write out any leftover buffered bytes.
        flush();
        out.close();
    }

    /*
     * @see java.io.OutputStream#flush()
     */
    @Override
    public void flush() throws IOException {
        for (int i = 0; i < currentWordLength; i++) {
            writeByteRecord(currentWord[i]);
        }
        dict.resetMatchingState();
    }

    /*
     * @see java.io.OutputStream#write(int)
     */
    @Override
    public void write(int value) throws IOException {
        /*
         * The compression algorithm is based on the one described at the
         * wikipedia page for LZW:
         * 
         * http://en.wikipedia.org/wiki/Lempel–Ziv–Welch#Encoding
         * ===========================COPIED======================================
         * 
         * A high level view of the encoding algorithm is shown here:
         * 
         * 1. Initialize the dictionary to contain all strings of length one.
         * 
         * 2. Find the longest string W in the dictionary that matches the
         * current input.
         * 
         * 3. Emit the dictionary index for W to output and remove W from the
         * input.
         * 
         * 4. Add W followed by the next symbol in the input to the dictionary.
         * 
         * 5. Go to Step 2.
         * ======================================================================
         */
        // Crop to 8 bits
        value = 0xff & value;
        if (LZ77Utils.ENABLE_LOGGING) {
            log("read byte:\t%d", value);
        }
        /*
         * The keep expanding the prefix as long as:
         * 1. The word exists in the dictionary.
         * 2. The word length is less that the max size.
         */
        if (currentWordLength < LZ77Utils.MAX_W_SIZE
                && dict.match(value, bytesWritten + currentWordLength)) {
            // This prefix is in the dict, save value and read next byte.
            currentWord[currentWordLength++] = value;
        } else {
            // No longer matching in dict.
            if (LZ77Utils.ENABLE_LOGGING) {
                log("No match in dict");
            }
            if (currentWordLength == 1) {
                // We only matched one byte. Write the buffered byte + the
                // current byte.
                bytesWritten += writeByteRecord(currentWord[0]);
                bytesWritten += writeByteRecord(value);
            } else {
                // Matched more than one byte. Find the offset to the last
                // time we wrote this word.
                int lastWrittenAtOffset = (int) (bytesWritten - dict.getLastWritePos() - 1)
                        + currentWordLength;
                if (LZ77Utils.ENABLE_LOGGING) {
                    log("preparing record:\tbytesWritten=%d lastWritePos=%d currentWPos=%d",
                            bytesWritten, dict.getLastWritePos(), currentWordLength);
                }
                // And write out the record.
                writeOffsetRecord(lastWrittenAtOffset, currentWordLength);
                bytesWritten += currentWordLength;

                // Followed by the unmatched value.
                bytesWritten += writeByteRecord(value);
            }
            currentWordLength = 0;
            // Add the current word appended with the current (unmatched) byte
            // to the dictionary.
            dict.add(value, bytesWritten);
            // Reset the dict matching state.
            dict.resetMatchingState();
        }
    }

    /**
     * Write a type '0' LZ77 record to the output stream.
     * 
     * @param value
     *            8-bit value.
     * @return
     * @throws IOException
     */
    private int writeByteRecord(int value) throws IOException {
        if (LZ77Utils.ENABLE_LOGGING) {
            log("writing one byte:\t%d", value);
        }
        out.write(0, LZ77Utils.TYPE_SIZE);
        out.write(value, LZ77Utils.BYTE_SIZE);
        return 1;
    }

    /**
     * Write a type '1' LZ77 record to the output stream.
     * 
     * @param offset
     *            the offset in the output stream.
     * @param len
     *            the length of the record.
     * @throws IOException
     */
    private void writeOffsetRecord(int offset, int len) throws IOException {
        if (LZ77Utils.ENABLE_LOGGING) {
            log("writing record: len=%d pointer=%d", len, offset);
        }
        out.write(1, LZ77Utils.TYPE_SIZE);
        out.write(offset, LZ77Utils.POINTER_SIZE);
        out.write(len, LZ77Utils.LEN_SIZE);
    }

}
