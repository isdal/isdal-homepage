package al.isd.interviews.facebook.lz77;

import static al.isd.interviews.facebook.lz77.LZ77Utils.log;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import al.isd.interviews.facebook.lz77.bitutils.BitInputStream;

/**
 * This class implements a stream filter for reading compressed data in
 * the 'Almost-LZ77' file format.
 * 
 * @author Tomas Isdal (t@isd.al)
 */
public class LZ77InputStream extends InputStream {
    public static boolean ENABLE_LOGGING = LZ77Utils.ENABLE_LOGGING;

    // Decompressed data ready to be read.
    private byte[] bufferedData;
    private int bufferedDataReadPosition;

    private int bufferedDataWritePosition;
    private boolean endReached = false;
    private final BitInputStream in;

    private final RotatingBuffer recentlyWritten;

    /**
     * Create a new LZ77 input stream filter around the provided InputStream.
     * 
     * @param in
     *            the input stream to read LZ77 compressed data from.
     */
    public LZ77InputStream(InputStream in) {
        this.in = new BitInputStream(in);
        this.recentlyWritten = new RotatingBuffer(LZ77Utils.ADDRESSABLE_BYTES);
        this.bufferedData = new byte[LZ77Utils.MAX_W_SIZE];
    }

    /*
     * @see java.io.InputStream#close()
     */
    @Override
    public void close() throws IOException {
        in.close();
    }

    /*
     * @see java.io.InputStream#read()
     */
    @Override
    public int read() throws IOException {
        // Read any buffered data we already unpacked.
        if (bufferedDataReadPosition < bufferedDataWritePosition) {
            byte value = bufferedData[bufferedDataReadPosition];
            bufferedDataReadPosition++;
            return LZ77Utils.unsignedByteToInt(value);
        }
        // If we have nothing buffered and nothing to read, return -1.
        if (endReached) {
            return -1;
        }
        // Fill the buffer and try again.
        readOneRecord();
        return read();
    }

    /**
     * Read one record from the source stream and copy the result into the local
     * data buffer.
     * 
     * Format:
     * A 0 bit followed by eight bits means just copy the eight bits to the
     * output directly.
     * 
     * A 1 bit is followed by a pointer of 12 bits followed by a length encoded
     * in 4 bits. This is to be interpreted as "copy the <length> bytes from
     * <pointer> bytes ago in the output to the current location".
     * 
     * @throws IOException
     *             if and I/O error occurs.
     */
    private void readOneRecord() throws IOException {
        try {
            // Reset the pointers.
            bufferedDataReadPosition = 0;
            bufferedDataWritePosition = 0;

            int type = in.readBits(LZ77Utils.TYPE_SIZE);
            if (ENABLE_LOGGING) {
                log("record type: %d", type);
            }
            switch (type) {
            case 0:
                // Read 8 bits and write them to the output
                int value = in.readBits(LZ77Utils.BYTE_SIZE);
                if (ENABLE_LOGGING) {
                    log("copying one byte:\t%d", value);
                }
                byte byteVal = (byte) value;
                recentlyWritten.write(byteVal);
                bufferedData[bufferedDataWritePosition] = byteVal;
                bufferedDataWritePosition++;
                break;
            case 1:
                // Read 12 bits pointer.
                int pointer = in.readBits(LZ77Utils.POINTER_SIZE);
                // Read 4 bits length.
                int len = in.readBits(LZ77Utils.LEN_SIZE);
                /*
                 * Copy len bytes from the recently written buffer starting at
                 * the pointer into the read buffer. The copy will also write
                 * the same data to head of the recent buffer.
                 */
                bufferedDataWritePosition += recentlyWritten.copy(bufferedData, pointer, len);
                break;
            default:
                throw new RuntimeException(String.format("invalid type: %d", type));
            }
        } catch (EOFException e) {
            endReached = true;
        }
    }

}
