package al.isd.interviews.facebook.lz77;

/**
 * A trie based dictionary used for longest-prefix matching during LZ77
 * compression.
 * 
 * @author Tomas Isdal (t@isd.al)
 * 
 */
public class LZ77Dictionary {

    // Counter keeping track of the number of adds.
    private long addCount = 0;
    private Trie currentNode;

    // Clear out all expired nodes every 'garbageCollectFrequency' adds.
    private final int garbageCollectFrequency;
    // The maximum number of byte in the past that an item can be fetched from.
    private final int maxByteOffset;

    private final int maxDepth;

    private final Trie root;

    /**
     * Create a new LZ77 Dictionary.
     * 
     * @param maxByteOffset
     *            The maximum number of bytes that can be accessed from the
     *            output stream. Any words matched more than maxByteOffset
     *            are no longer reachable and can not contribute to a prefix
     *            match.
     * @param maxDepth
     *            The maximum word size that can be used. Matching any words
     *            longer than this is unnecessary since they can not be copied
     *            from the output buffer anyway.
     * @param garbageCollectFrequency
     *            The frequency of which the trie is traversed to prune out
     *            unreachable nodes.
     */
    public LZ77Dictionary(int maxByteOffset, int maxDepth, int garbageCollectFrequency) {
        this.maxDepth = maxDepth;
        this.maxByteOffset = maxByteOffset;
        this.root = createRoot();
        this.currentNode = root;
        this.garbageCollectFrequency = garbageCollectFrequency;
    }

    /**
     * (stateful) Add a node with value <value> as a child to the current node
     * in the trie.
     * 
     * @param value
     *            the value to add.
     * @param currentWritePos
     *            the current write position in the output stream.
     */
    public void add(int value, long currentWritePos) {
        if (currentNode.depth < maxDepth) {
            Trie newNode = currentNode.getChild(value);
            if (newNode == null) {
                newNode = new Trie(currentNode, value);
            }
            currentNode.setChild(newNode);
            newNode.lastWrittenAtPos = currentWritePos;
        }

        if (addCount++ % garbageCollectFrequency == 0) {
            // Prefixes that no longer are reachable from the current write
            // position should be removed from the tree.
            // To decrease the risk of removing a node just before it is needed
            // we keep the object around (but inactive) for 4x the window size.
            root.clearExpired(currentWritePos - 4 * maxByteOffset);
        }
    }

    /**
     * (stateful) Retrieve the last position the current node value was written
     * to the output.
     * 
     * @return the position the current node was written to the output.
     */
    public long getLastWritePos() {
        return currentNode.lastWrittenAtPos;
    }

    /**
     * (stateful) The implementation is state-full. Each call to <match> walk
     * down one level in the trie.
     * 
     * @param value
     *            the prefix to match.
     * @param currentWritePos
     *            the current write position.
     * @return true if there is a matching prefix in the trie, false otherwise.
     */
    public boolean match(int value, long currentWritePos) {
        Trie child = currentNode.getChild(value);
        // Child not null and still reachable.
        if (child != null && child.isRechable(currentWritePos - maxByteOffset)) {
            currentNode.lastWrittenAtPos = currentWritePos;
            currentNode = child;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Reset the matching state of the dictionary to allow it to match a new
     * word.
     */
    public void resetMatchingState() {
        currentNode = root;
    }

    /*
     * Create a root node with children.
     */
    private static Trie createRoot() {
        Trie root = new Trie(null, 0);
        for (int i = 0; i < 256; i++) {
            root.setChild(new Trie(root, i));
        }
        return root;
    }

    private static class Trie {
        /*
         * Keeping an array is memory-inefficient since the children array
         * generally has a low load factor. The advantage with an array is that
         * it allows for really fast lookups.
         * 
         * By lazily instantiating the array when a child is added we avoid
         * allocating an array for leaf nodes.
         * 
         * An alternative implementation based on java.util.HashMap resulted in
         * a compression speed decrease (of marmot.bmp) by ~30% on a 2008era
         * macbook pro.
         */
        private Trie[] children;
        // The distance to the root.
        private int depth;

        // The last position this node was written at.
        long lastWrittenAtPos;
        private Trie parent;

        private int value;

        /**
         * Create a new Trie node.
         * 
         * @param parent
         *            the parent node.
         * @param value
         *            the value of the node.
         */
        public Trie(Trie parent, int value) {
            this.parent = parent;
            if (parent != null) {
                depth = parent.depth + 1;
            }
            this.value = value;
        }

        /**
         * Remove unreachable nodes from the trie. If a node is unreachable it
         * means that it's children is unreachable as well so in that case
         * removing the current node from the trie is enough.
         * 
         * @param minLastWritePos
         *            the last position at which the node must have been seen.
         */
        public void clearExpired(long minLastWritePos) {
            if (!isRechable(minLastWritePos)) {
                removeFromTrie();
            } else if (children != null) {
                for (int i = 0; i < children.length; i++) {
                    Trie child = children[i];
                    if (child != null) {
                        child.clearExpired(minLastWritePos);
                    }
                }
            }
        }

        /**
         * Retrieves a child node from this node.
         * 
         * @param value
         * @return Return the child with value <value> or null if the node has
         *         not child with that value.
         */
        public Trie getChild(int value) {
            if (children == null) {
                return null;
            } else {
                return children[value];
            }
        }

        /**
         * Returns true if the node is still reachable, meaning that the node
         * was last seen after <minLastWritePos>.
         * 
         * @param minLastWritePos
         *            the last position at which the node must have been seen.
         * @return
         *         Returns true if the current node is still reachable.
         */
        public boolean isRechable(long minLastWritePos) {
            return depth < 2 || lastWrittenAtPos > minLastWritePos;
        }

        /**
         * Remove this node from the trie.
         */
        public void removeFromTrie() {
            parent.children[value] = null;
        }

        /**
         * Add a child node to this node.
         * 
         * @param child
         *            the node to add.
         */
        public void setChild(Trie child) {
            if (children == null) {
                children = new Trie[256];
            }
            children[child.value] = child;
        }
    }
}
