package al.isd.interviews.facebook.lz77.bitutils;

/**
 * Convenience class for bit operations.
 * 
 * @author Tomas Isdal (t@isd.al)
 * 
 */
public class BitUtils {
    // Print out debug logging information.
    public static boolean ENABLE_LOGGING = false;

    static String formatInt(int val) {
        return String.format("%16s", Integer.toBinaryString(val)).replace(" ", "0");
    }

    static void log(String msg, int val) {
        System.out.println(msg + "\t" + formatInt(val));
    }
}