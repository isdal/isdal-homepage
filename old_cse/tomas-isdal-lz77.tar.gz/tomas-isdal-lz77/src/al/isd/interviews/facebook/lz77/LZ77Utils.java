package al.isd.interviews.facebook.lz77;


/**
 * Helper functions used to the LZ77 classes.
 * 
 * @author Tomas Isdal (t@isd.al)
 */
public class LZ77Utils {
    // Set to true to print out debug logging information to stdout.
    public static boolean ENABLE_LOGGING = false;

    // The size of the pointer field in bits.
    static final int POINTER_SIZE = 12;

    // The maximum number of bytes we can address with pointer size bits.
    static final int ADDRESSABLE_BYTES = 1 << POINTER_SIZE;

    // The size of the length field in bits.
    static final int LEN_SIZE = 4;

    // The longest prefix we can match.
    static final int MAX_W_SIZE = (1 << LEN_SIZE) - 1;

    // Size of a byte in bits.
    static final int BYTE_SIZE = 8;

    // Size of the type field in bits.
    static final int TYPE_SIZE = 1;

    // Frequency with which to clear out expired dictionary items.
    static final int CLEAR_GARBAGE_FREQUENCY = 100 * 1000;

    public static int unsignedByteToInt(byte b) {
        return 0xFF & (int) b;
    }

    public static void log(String pattern, Object... parameters) {
        if (ENABLE_LOGGING) {
            System.out.println(String.format(pattern, parameters));
        }
    }

    public static String arrayToString(int[] array, int len) {
        if (!ENABLE_LOGGING) {
            return "";
        }
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < len; i++) {
            b.append(array[i] + ",");
        }
        return b.toString();
    }
}
