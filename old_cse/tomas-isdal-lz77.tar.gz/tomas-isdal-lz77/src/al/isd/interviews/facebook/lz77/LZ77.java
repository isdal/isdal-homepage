package al.isd.interviews.facebook.lz77;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class LZ77 {

    /**
     * USAGE: java -jar lz77.jar <-c|-x> [input] [output]
     * If no output is specified stdout is used.
     * If no input is specified stdin is used.
     */
    public static void main(String[] args) {
        boolean compress = getType(args);
        InputStream in = getInputStream(args, compress);
        OutputStream out = getOutputStream(args, compress);
        copyStreamAndClose(in, out, true);
    }

    /**
     * Checks if in compress mode.
     * 
     * @param args
     *            the command line arguments.
     * @return true if in compress mode, false otherwise.
     */
    private static boolean getType(String[] args) {
        if (args.length == 0) {
            printUsageAndExit();
        } else if ("-x".equals(args[0])) {
            System.err.println("extract mode");
            return false;
        } else if ("-c".equals(args[0])) {
            System.err.println("compress mode");
            return true;
        } else {
            System.err.println("-c or -x must be specified");
            printUsageAndExit();
        }
        return true;
    }

    /**
     * Parse command line arguments and return the output stream to use.
     * 
     * @param args
     *            command line arguments.
     * @param compress
     * @return an output stream for the specified file, or system.out if no file
     *         was provided.
     */
    static OutputStream getOutputStream(String[] args, boolean compress) {
        OutputStream out = System.out;
        try {
            if (args.length >= 3) {
                File output = new File(args[2]);
                if (!output.isFile() && !output.createNewFile()) {
                    System.out.println("unable to create file: " + output);
                    printUsageAndExit();
                }
                System.err.println("Writing to " + output);
                out = new BufferedOutputStream(new FileOutputStream(output));
            } else {
                System.err.println("Writing to stdout");
            }
        } catch (FileNotFoundException f) {
            // Already checked.
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (compress) {
            out = new LZ77OutputStream(out);
        }
        return out;
    }

    /**
     * Parse command line arguments and return the input stream to use.
     * 
     * @param args
     *            command line arguments.
     * @param compress
     * @return an input stream for the file specified, or system.in if no file
     *         was provided.
     */
    static InputStream getInputStream(String[] args, boolean compress) {
        InputStream in = System.in;
        try {
            if (args.length >= 2) {
                File file = new File(args[1]);
                if (!file.exists() || !file.isFile()) {
                    System.err.println("invalid input file: " + args[1]);
                    printUsageAndExit();
                }
                System.err.println("Reading from " + file);
                in = new BufferedInputStream(new FileInputStream(file));
            } else {
                System.err.println("Reading from stdin");
            }
        } catch (FileNotFoundException f) {
            // Already checked.
        }
        if (!compress) {
            in = new LZ77InputStream(in);
        }
        return in;
    }

    private static void printUsageAndExit() {
        System.err.println("USAGE: java -jar lz77.jar <-c|-x> [input] [output]");
        System.err.println(" -c compress");
        System.err.println(" -x extract");
        System.exit(1);
    }

    /**
     * Copy all contents from an input stream into and output stream.
     * 
     * @param in
     *            The stream to read from.
     * @param out
     *            The stream to write to.
     * @param printProgess
     *            If true a progress indicator will be printed to stderr every
     *            1MB.
     */
    static void copyStreamAndClose(InputStream in, OutputStream out, boolean printProgess) {
        int counter = 0;
        int data;
        try {
            while ((data = in.read()) != -1) {
                out.write(data);
                if (printProgess && ++counter % (1024 * 1024) == 0) {
                    System.err.println(String.format("completed %d MB", counter / 1024 / 1024));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                System.err.println("error when closing input: " + e.getMessage());
            }
            try {
                out.close();
            } catch (IOException e) {
                System.err.println("error when closing output: " + e.getMessage());
            }
        }
    }
}
