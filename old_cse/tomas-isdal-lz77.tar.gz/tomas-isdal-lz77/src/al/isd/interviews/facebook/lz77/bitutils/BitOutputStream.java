package al.isd.interviews.facebook.lz77.bitutils;

import static al.isd.interviews.facebook.lz77.bitutils.BitUtils.log;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Convenience class for writing bits to an output stream.
 * 
 * @author Tomas Isdal (t@isd.al)
 */
public class BitOutputStream {
    private final OutputStream out;

    // Used to store bits that have been written but not yet flushed to the
    // output stream.
    protected int partiallyWrittenByte = 0;

    // Position in the output buffer.
    protected int partiallyWrittenPos = 0;

    private long totalBitsWritten = 0;

    /**
     * Create a new BitOutput stream around the provided OutputStream.
     * 
     * @param out
     *            the OutputStream to write to.
     */
    public BitOutputStream(OutputStream out) {
        this.out = out;
    }

    /**
     * Write any remaining data and close the underlying output stream.
     * 
     * @throws IOException
     *             if an I/O error occurs.
     */
    public void close() throws IOException {
        // Flush out any partially written data.
        write();
        out.close();
    }

    /**
     * Returns the number of bytes written to the stream.
     * 
     * @return the number of bytes written.
     */
    public long getBytesWritten() {
        return totalBitsWritten / 8;
    }

    /**
     * Write the data in the partially written buffer to the underlying output
     * stream.
     * 
     * @throws IOException
     */
    protected void write() throws IOException {
        if (BitUtils.ENABLE_LOGGING) {
            log("writing to stream: ", partiallyWrittenByte);
        }
        out.write(partiallyWrittenByte);
        partiallyWrittenPos = 0;
        partiallyWrittenByte = 0;
    }

    /**
     * Write the <len> right-most bits in source to the underlying output
     * stream.
     * 
     * @param source
     *            the source to read from.
     * @param len
     *            the number of bits to write.
     * @throws IOException
     *             if an I/O error occurs.
     */
    public void write(int source, int len) throws IOException {
        if (source < 0) {
            throw new IllegalArgumentException(String.format(
                    "Only positive values as supported (value=%d)", source));
        }
        if (source >> len > 0) {
            throw new IllegalArgumentException(String.format(
                    "Data has bits set outside specified range (bug?, value=%s)",
                    BitUtils.formatInt(source)));
        }
        if (len > 31) {
            throw new IllegalArgumentException(String.format(
                    "Maximum number of bits exceeded (%d > 31", len));
        }

        int bitsWritten = 0;
        while (bitsWritten < len) {
            int lenToWrite = Math.min(len - bitsWritten, 8 - partiallyWrittenPos);
            // Right align the bits we are going to write this iteration.
            int aligned = source >> (len - lenToWrite - bitsWritten);

            // Left shift the bits to the correct position in the buffer.
            int shifted = 0xFF & (aligned << (8 - lenToWrite - partiallyWrittenPos));

            // Copy the data into the buffer.
            partiallyWrittenByte |= shifted;

            if (BitUtils.ENABLE_LOGGING) {
                log("source\t\t", source);
                log("aligned data:\t", aligned);
                log("shifted data:\t", shifted);
                log("buffer content:\t", partiallyWrittenByte);
            }

            // Update position pointer.
            partiallyWrittenPos += lenToWrite;
            bitsWritten += lenToWrite;

            // If the buffer is full: write to outputstream.
            if (partiallyWrittenPos == 8) {
                write();
            }
        }
        totalBitsWritten += len;
    }
}