package al.isd.interviews.facebook.lz77;

import static org.junit.Assert.assertArrayEquals;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedList;
import java.util.List;

/**
 * Read the file or files specified and report statistics such as
 * compression speed and compression ratio.
 * 
 * The entire content of the file is first read into ram to ensure that the
 * throughput reflects the limitations of the compression algorithm and not the
 * source file system.
 * 
 * @author Tomas Isdal (t@isd.al)
 * 
 */
public class LZ77Performance {

    public static void main(String[] args) throws IOException {
        if (args.length == 0) {
            System.err.println("USAGE: LZ77Performance <file_or_dir>...");
            System.exit(1);
        }
        List<File> testFiles = new LinkedList<File>();
        for (String file : args) {
            File fileObject = new File(file);
            if (!fileObject.exists()) {
                System.err.println("File not found: " + file);
            } else {
                testFiles.addAll(getFiles(fileObject));
            }
        }
        for (File file : testFiles) {
            perfTest(file);
        }
    }

    /**
     * Recursively get all files starting at fileObject.
     * 
     * @param fileObject
     *            the base file.
     * @return a list of files reachable trough fileObject.
     */
    private static List<File> getFiles(File fileObject) {
        List<File> testFiles = new LinkedList<File>();
        if (fileObject.isFile()) {
            testFiles.add(fileObject);
        } else if (fileObject.isDirectory()) {
            for (File dirContent : fileObject.listFiles()) {
                testFiles.addAll(getFiles(dirContent));
            }
        }
        return testFiles;
    }

    private static double bytesToMb(long bytes) {
        return bytes / 1024.0 / 1024.0;
    }

    private static void perfTest(File file) throws IOException {
        System.out.println("\n\nTesting compression performace for: " + file);
        // Garbage collect the last test so it won't happen in the middle of
        // this one.
        Runtime.getRuntime().gc();
        Runtime.getRuntime().gc();
        // Read the file into RAM to avoid measuring the disk speed and not the
        // compression speed.
        byte[] data = LZ77InputOutputStreamTest.readSmallFile(file, Integer.MAX_VALUE);
        ByteArrayOutputStream compressed = new ByteArrayOutputStream(data.length);
        ByteArrayOutputStream decompressed = new ByteArrayOutputStream(data.length);

        // Compress the data.
        long startTime = System.currentTimeMillis();
        // Write the data through the compression output stream.
        OutputStream lz77OutputStream = new LZ77OutputStream(compressed);
        lz77OutputStream.write(data);
        lz77OutputStream.close();

        // Write throughput stats.
        long elapsed = System.currentTimeMillis() - startTime;
        double mBps = bytesToMb(data.length) / (elapsed / 1000.0);
        System.out.println(String.format("compressed %.1f MB in %.1f seconds (%.2f MB/s)",
                bytesToMb(data.length), elapsed / 1000.0, mBps));

        byte[] compressedData = compressed.toByteArray();
        double factor = compressedData.length / (double) data.length;
        System.out.println(String.format(
                "compression stats: old_size=%.2fMB, new_size=%.2fMB (%.1f%%)",
                bytesToMb(data.length), bytesToMb(compressedData.length), 100 * factor));

        // Decompress the data.
        startTime = System.currentTimeMillis();
        InputStream stream = new LZ77InputStream(new ByteArrayInputStream(compressedData));
        int value;
        while ((value = stream.read()) != -1) {
            decompressed.write(value);
        }
        elapsed = System.currentTimeMillis() - startTime;
        mBps = data.length / 1024.0 / 1024.0 / (elapsed / 1000.0);

        System.out.println(String.format("decompressed %.1f MB in %.1f seconds (%.2f MB/s)",
                data.length / 1024.0 / 1024.0, elapsed / 1000.0, mBps));

        // Verify that it worked...
        byte[] decompressedData = decompressed.toByteArray();
        assertArrayEquals(data, decompressedData);
    }
}
