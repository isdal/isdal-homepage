package al.isd.interviews.facebook.lz77.bitutils;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.junit.Test;

import al.isd.interviews.facebook.lz77.bitutils.BitOutputStream;

/**
 * Tests for the BitOutputStream class.
 * 
 * @author Tomas Isdal (t@isd.al)
 * 
 */
public class BitOutputStreamTest {

    @Test
    public void testWrite() throws IOException {
        {
            // Test writing across a boundary.
            ByteArrayOutputStream baout = new ByteArrayOutputStream();
            BitOutputStream bos = new BitOutputStream(baout);
            bos.write(0, 1);
            bos.write(2, 2);
            bos.write(0x71, 7);
            bos.write(0, 6);
            assertEquals(0x5C, (int) baout.toByteArray()[0]);
            assertEquals(0x40, (int) baout.toByteArray()[1]);
        }
        {
            // Test writing of larger payloads.
            ByteArrayOutputStream baout = new ByteArrayOutputStream();
            BitOutputStream bos = new BitOutputStream(baout);
            bos.write(0x1111, 16);
            assertEquals(0x11, (int) baout.toByteArray()[0]);
            assertEquals(0x11, (int) baout.toByteArray()[1]);
        }
    }
}
