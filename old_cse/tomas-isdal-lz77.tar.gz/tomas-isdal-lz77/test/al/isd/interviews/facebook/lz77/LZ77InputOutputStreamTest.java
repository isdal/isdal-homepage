package al.isd.interviews.facebook.lz77;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;

import org.junit.Test;

import al.isd.interviews.facebook.lz77.bitutils.BitOutputStream;

/**
 * End-to-End tests of compression and decompression using the LZ77InputStream
 * and LZ77OutputStream classes.
 * 
 * @author Tomas Isdal (t@isd.al)
 * 
 */
public class LZ77InputOutputStreamTest {

    /**
     * Test that the compression/decompression works for a big chunk of random
     * data.
     * 
     * @throws IOException
     *             if and I/O error occurs.
     */
    @Test
    public void testBigChunkOfRandom() throws IOException {
        // One MB and then some.
        int size = 1025 * 1025;

        // Fixed seed for reproducibility.
        int randomSeed = 54321;
        int iterations = 1;
        for (int i = 0; i < iterations; i++) {
            Random rand = new Random(randomSeed + i);
            System.out.println(String.format("iteration=%d seed=%d", i, randomSeed + i));

            // Generate random data.
            byte[] data = new byte[size];
            rand.nextBytes(data);

            // Compress, decompress, and verify that it worked.
            compressDecompressAndVerify(data);
        }
    }

    /**
     * Test that the compression/decompression works for data with a large
     * amount of long repeating patterns exercising the full range of allowed
     * word sizes.
     * 
     * @throws IOException
     *             if and I/O error occurs.
     */
    @Test
    public void testCompressMaxDepth() throws IOException {
        // Generate a repeating pattern to trigger a 15 byte prefix match.
        ByteArrayOutputStream testData = new ByteArrayOutputStream();
        testData.write(0);
        for (int i = 0; i < LZ77Utils.MAX_W_SIZE + 5; i++) {
            for (int j = 0; j < i; j++) {
                testData.write(j);
            }
        }
        byte[] data = testData.toByteArray();

        // Compress, decompress, and verify that it worked.
        compressDecompressAndVerify(data);
    }

    /**
     * Test that the compression/decompression works for fancy English text.
     * 
     * @throws IOException
     *             if and I/O error occurs.
     */
    @Test
    public void testCompressShakespeare() throws IOException {
        // Read some fancy English.
        byte[] data = readSmallFile(new File("testdata/allswell.html"), Integer.MAX_VALUE);

        // Compress, decompress, and verify that it worked.
        compressDecompressAndVerify(data);
    }

    /**
     * Simple test with a basic repeating pattern verifying that the pattern
     * recognition functionality works.
     * 
     * @throws IOException
     *             if and I/O error occurs.
     */
    @Test
    public void testCompressSimple() throws IOException {
        byte[] data = new byte[] { 0, 1, 0, 1, 2, 0, 1, 2, 3 };
        compressDecompressAndVerify(data);
    }

    /**
     * The example has to work right :-)
     * "mahi mahi" can be compressed as:
     * <0,'m'><0,'a'><0,'h'><0,'i'><0,' '><1,4,4>
     * 
     * @throws IOException
     *             if and I/O error occurs.
     */
    @Test
    public void testMahiMahi() throws IOException {
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        BitOutputStream bitOut = new BitOutputStream(byteOut);

        char[] mahi = new char[] { 'm', 'a', 'h', 'i', ' ' };
        for (int i = 0; i < mahi.length; i++) {
            bitOut.write(0, LZ77Utils.TYPE_SIZE);
            bitOut.write(mahi[i], LZ77Utils.BYTE_SIZE);
        }
        bitOut.write(1, LZ77Utils.TYPE_SIZE);
        bitOut.write(4, LZ77Utils.POINTER_SIZE);
        bitOut.write(4, LZ77Utils.LEN_SIZE);
        bitOut.close();
        byte[] compressedData = byteOut.toByteArray();

        byte[] decompressedData = readStream(new LZ77InputStream(new ByteArrayInputStream(
                compressedData)), compressedData.length, Integer.MAX_VALUE);

        String mahiMahi = new String(decompressedData);
        System.out.println(mahiMahi);
        assertEquals("mahi mahi", mahiMahi);
    }

    /**
     * Return a String containing a comma-separated list of the content of the
     * supplied array.
     * 
     * @param array
     *            the array to use.
     * @param limit
     *            only use first 'limit' bytes of the array.
     * @return a comma-separated String with the content of the array.
     */
    static String arrayToString(byte[] array, int limit) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < limit && i < array.length; i++) {
            b.append(array[i] + ",");
        }
        return b.toString().substring(0, b.length() - 1);
    }

    /**
     * Compress the content of the data parameter, decompress it, and verify
     * that the result equals what we started with.
     * 
     * @param data
     *            the content to compress/decompress.
     * @throws IOException
     *             if and I/O error occurs.
     */
    private static void compressDecompressAndVerify(byte[] data) throws IOException {
        ByteArrayOutputStream compressed = new ByteArrayOutputStream(data.length);

        // Write the data through the compression output stream.
        OutputStream lz77OutputStream = new LZ77OutputStream(compressed);
        lz77OutputStream.write(data);
        lz77OutputStream.close();

        byte[] compressedData = compressed.toByteArray();

        // Unpack it.
        byte[] decompressedData = readStream(new LZ77InputStream(new ByteArrayInputStream(
                compressedData)), data.length, Integer.MAX_VALUE);

        // And verify that it is correct.
        assertArrayEquals(data, decompressedData);
    }

    /**
     * Read a file completely and store it in an byte array.
     * 
     * @param file
     *            The file to read.
     * @param limit
     *            Only read 'limit' bytes and not the complete file.
     * @return a byte array with at most 'limit' bytes from the file.
     * @throws IOException
     *             if and I/O error occurs.
     */
    static byte[] readSmallFile(File file, int limit) throws IOException {
        int len = (int) file.length();
        return readStream(new BufferedInputStream(new FileInputStream(file), 1024 * 1024), len,
                limit);
    }

    /**
     * Read a stream and store it in an byte array.
     * 
     * @param stream
     *            The stream to read from.
     * @param contentLengthEstimate
     *            an estimate of the number of bytes to read. It is used as an
     *            performance optimization and is not required to be correct.
     * @param limit
     *            Only read 'limit' bytes and not the complete stream.
     * @return a byte array with at most 'limit' bytes from the stream .
     * @throws IOException
     *             if and I/O error occurs.
     */
    static byte[] readStream(InputStream stream, int contentLengthEstimate, int limit)
            throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(contentLengthEstimate);
        int value;
        int num = 0;
        while ((value = stream.read()) != -1 && num++ < limit) {
            out.write(value);
        }
        return out.toByteArray();
    }

    /**
     * Class verifying that the bytes written to the underlying
     * ByteArrayOutputStream matches the expected values provided when the
     * object was initialized.
     * 
     * If an incorrect value is written a list of up to 10 previous and 10
     * following values are printed to ease debugging (especially when fixing
     * off-by-one errors). The application is terminated if an unexpected
     * byte is observed.
     * 
     */
    static class ByteVerifyingOutputStream extends ByteArrayOutputStream {
        int count = 0;
        private final byte[] data;

        private ByteVerifyingOutputStream(byte[] data) {
            this.data = data;
        }

        @Override
        public void write(int value) {
            byte valueAsByte = (byte) value;
            if (data[count] != valueAsByte) {
                System.out.println("error! surrounding bytes:");
                for (int i = Math.max(0, count - 10); i < Math.min(data.length, count + 11); i++) {
                    System.out.print(valueAsByte + ", ");
                }
                System.out.println("\ncount=" + count + " value=" + valueAsByte + " data="
                        + data[count]);

                assertEquals(data[count], valueAsByte);
            }
            super.write(value);
            count++;
        }
    }

}
