package al.isd.interviews.facebook.lz77.bitutils;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Random;

import al.isd.interviews.facebook.lz77.bitutils.BitInputStream;
import al.isd.interviews.facebook.lz77.bitutils.BitOutputStream;

/**
 * Generates a large amount of random reads and writes and prints out throughput
 * statistics for the BitInputStream and BitOutputStream classes.
 * 
 * @author Tomas Isdal (t@isd.al)
 * 
 */
public class BitStreamsPerformance {

    private final static int SIZE = 10 * 1024 * 1024;
    private final static int RANDOM_SEED = 12345;
    private final static int MAX_CHUNK_BITS = 31;

    public static void main(String[] args) throws IOException {
        ByteArrayOutputStream baout = new ByteArrayOutputStream(SIZE * 4);

        Random rand = new Random(RANDOM_SEED);
        int[][] testData = new int[SIZE][2];
        int[] readData = new int[SIZE];
        for (int i = 0; i < testData.length; i++) {
            int len = 1 + rand.nextInt(MAX_CHUNK_BITS - 1);
            int data = rand.nextInt(1 << len);
            testData[i][0] = data;
            testData[i][1] = len;
        }
        System.out.println("filled test array with random data");

        long startTime = System.currentTimeMillis();
        BitOutputStream bos = new BitOutputStream(baout);
        for (int i = 0; i < testData.length; i++) {
            int len = testData[i][1];
            int data = testData[i][0]; 
            bos.write(data, len);
        }
        bos.close();

        long elapsed = System.currentTimeMillis() - startTime;
        long bytesCopied = bos.getBytesWritten();
        double mBps = bytesCopied / 1024.0 / 1024.0 / (elapsed / 1000.0);
        System.out.println(String.format("wrote %.1f MB in %.1f seconds (%.2f MB/s)",
                bytesCopied / 1024.0 / 1024.0, elapsed / 1000.0, mBps));

        byte[] payload = baout.toByteArray();

        startTime = System.currentTimeMillis();
        BitInputStream bis = new BitInputStream(new ByteArrayInputStream(payload));
        for (int i = 0; i < testData.length; i++) {
            int len = testData[i][1];
            readData[i] = bis.readBits(len);
        }
        elapsed = System.currentTimeMillis() - startTime;
        bytesCopied = payload.length;
        mBps = bytesCopied / 1024.0 / 1024.0 / (elapsed / 1000.0);

        System.out.println(String.format("read %.1f MB in %.1f seconds (%.2f MB/s)",
                bytesCopied / 1024.0 / 1024.0, elapsed / 1000.0, mBps));

        // Verify correctness.
        for (int i = 0; i < readData.length; i++) {
            assertEquals(testData[i][0], readData[i]);
        }
    }
}
