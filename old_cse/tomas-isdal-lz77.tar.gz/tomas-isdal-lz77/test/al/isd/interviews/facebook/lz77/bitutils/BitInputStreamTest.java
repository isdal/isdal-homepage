package al.isd.interviews.facebook.lz77.bitutils;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.junit.Test;

import al.isd.interviews.facebook.lz77.bitutils.BitInputStream;

/**
 * Unit tests for the BitInputStream class.
 * 
 * @author Tomas Isdal (t@isd.al)
 * 
 */
public class BitInputStreamTest {

    /**
     * Verify that bits are read correctly.
     * 
     * @throws IOException
     */
    @Test
    public void testReadBits() throws IOException {
        byte[] data = new byte[3];
        data[0] = (byte) (0xAA);
        data[1] = (byte) (0xAF);
        data[2] = (byte) (0xAA);
        BitInputStream bis = new BitInputStream(new ByteArrayInputStream(data));
        assertEquals(1, bis.readBits(1));
        assertEquals(0, bis.readBits(1));
        assertEquals(10, bis.readBits(4));
        assertEquals(10, bis.readBits(4));
        assertEquals(2, bis.readBits(2));
        assertEquals(0xFA, bis.readBits(8));
    }

    /**
     * Verify that partial reads correctly increment the existing result.
     */
    @Test
    public void testGetPartialValue() {
        // Test partial reads without any existing result.
        assertEquals(Integer.parseInt("10101010", 2),
                BitInputStream.readPartialValue(0xAA, 0, 0, 8));
        assertEquals(Integer.parseInt("00000101", 2),
                BitInputStream.readPartialValue(0xAA, 0, 0, 3));
        assertEquals(Integer.parseInt("00001010", 2),
                BitInputStream.readPartialValue(0xAA, 4, 0, 4));

        // Verify that the existing result is shifted properly.
        assertEquals(Integer.parseInt("00000010", 2), BitInputStream.readPartialValue(0, 0, 0x1, 1));
        assertEquals(Integer.parseInt("10101010", 2),
                BitInputStream.readPartialValue(0xA, 4, 0xA, 4));
    }

    /**
     * Verify that the mask is created correctly.
     */
    @Test
    public void testMask() {
        // Test start offset.
        assertEquals(Integer.parseInt("10000000", 2), BitInputStream.getMask(0, 1));
        assertEquals(Integer.parseInt("01000000", 2), BitInputStream.getMask(1, 1));
        assertEquals(Integer.parseInt("01100000", 2), BitInputStream.getMask(1, 2));

        // Test end offset.
        assertEquals(Integer.parseInt("00000001", 2), BitInputStream.getMask(7, 1));
        assertEquals(Integer.parseInt("00000010", 2), BitInputStream.getMask(6, 1));
        assertEquals(Integer.parseInt("00000011", 2), BitInputStream.getMask(6, 2));

        // Full read.
        assertEquals(Integer.parseInt("11111111", 2), BitInputStream.getMask(0, 8));

    }

}
