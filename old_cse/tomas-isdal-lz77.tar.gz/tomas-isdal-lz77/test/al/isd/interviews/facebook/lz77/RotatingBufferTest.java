package al.isd.interviews.facebook.lz77;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.junit.Test;

/**
 * Unit tests for the RotatingBuffer class.
 * 
 * @author Tomas Isdal (t@isd.al)
 */
public class RotatingBufferTest {
    /**
     * Test basic read/write.
     */
    @Test
    public void testReadWrite() {
        final byte arrayLength = 17;
        RotatingBuffer rotatingBuffer = new RotatingBuffer(arrayLength);
        rotatingBuffer.write((byte) 1);
        assertEquals(1, rotatingBuffer.read(0));

        rotatingBuffer.write((byte) 2);
        assertEquals(2, rotatingBuffer.read(0));
        assertEquals(1, rotatingBuffer.read(1));

        // Test that wrapping is correct.
        for (byte i = 0; i < arrayLength; i++) {
            rotatingBuffer.write(i);
        }
        for (byte i = 0; i < arrayLength; i++) {
            assertEquals(arrayLength - i - 1, rotatingBuffer.read(i));
        }
    }

    /**
     * Test copy based on offset.
     */
    @Test
    public void testCopy() throws IOException {
        {
            int len = 17;
            byte[] destination = new byte[17];
            RotatingBuffer rotatingBuffer = new RotatingBuffer(len);
            // Write a couple bytes to make sure we wrap in the loop.
            rotatingBuffer.write((byte) 47);
            rotatingBuffer.write((byte) 47);
            rotatingBuffer.write((byte) 47);

            // Fill the entire buffer.
            for (int i = 0; i < len; i++) {
                rotatingBuffer.write((byte) (12 + i));
            }
            // Copy the entire buffer.
            rotatingBuffer.copy(destination, len - 1, len);

            // Make sure the right bytes ended up in the destination.
            for (byte i = 0; i < len; i++) {
                assertEquals(i + 12, destination[i]);
            }
            // And make sure that they got written to the buffer as well.
            for (byte i = 0; i < len; i++) {
                assertEquals(i + 12, rotatingBuffer.read(len - i - 1));
            }
        }
    }
}
