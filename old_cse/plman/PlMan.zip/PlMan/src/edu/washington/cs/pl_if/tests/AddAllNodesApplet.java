package edu.washington.cs.pl_if.tests;

import java.applet.Applet;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AddAllNodesApplet extends Applet implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4177549412284222218L;


	private boolean running =false;
	
	
	JTextField sliceField;

	JTextField nameField;

	JPasswordField passwordField;
	
	JLabel statusLabel;

	public void init() {
		// It is required but does not need anything.
		setLayout(new GridLayout(4, 2));
		JButton  runButton = new JButton("Add all nodes");
		runButton.setActionCommand("add_all");
		runButton.addActionListener(this);

		JLabel slice = new JLabel("Slice:");
		sliceField = new JTextField("my_cool_slice", 35);
		JLabel username = new JLabel("Username:");
		nameField = new JTextField("user@university.edu", 35);
		JLabel password = new JLabel("Password:");
		passwordField = new JPasswordField(35);
		
		statusLabel = new JLabel();
		
		add(slice);
		add(sliceField);
		add(username);
		add(nameField);
		add(password);
		add(passwordField);

		add(runButton);
		add(statusLabel);
		setSize(300, 100);
		// pack();
		// show();
		// runButton.addActionListener(this);
	}

	// This method gets called when the applet is terminated
	// That's when the user goes to another page or exits the browser.
	public void stop() {
		// no actions needed here now.
	}

	public void actionPerformed(ActionEvent evt) {

		if(!running){

			statusLabel.setText("Contacting PLC");
//			sliceField.setEditable(false);
//			nameField.setEditable(false);
//			passwordField.setEditable(false);
			running = true;
			
			AddAllNodes nodeEngine = new AddAllNodes(sliceField.getText(),nameField.getText(),new String(passwordField.getPassword()));
			nodeEngine.start();
			
			GuiUpdater guiUpt = new GuiUpdater(statusLabel,nodeEngine);
			guiUpt.start();
			
		}
	}
	
	
	private class GuiUpdater extends Thread{
		
		private JLabel statusLabel;
		private AddAllNodes nodeEngine;
		
		public GuiUpdater(JLabel statusLabel,AddAllNodes nodeEngine){
			this.statusLabel = statusLabel;
			this.nodeEngine = nodeEngine;
			
		}
		
		public void run(){
			
			String statusText = "Contacting PLC";
			
			String dots = "";
			while(!nodeEngine.isDone()){
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(statusText.equals(nodeEngine.getStatusText())){
					dots = dots + ".";
					
				} else{
					statusText = nodeEngine.getStatusText();
				}
				this.statusLabel.setText(statusText + dots);
			}
			running = false;
		}
	}
}	
