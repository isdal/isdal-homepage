package edu.washington.cs.pl_if.gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

import swing2swt.layout.BorderLayout;
import edu.washington.cs.pl_if.gui.table.DataTable;
import edu.washington.cs.pl_if.gui.table.GenericRowComparator;
import edu.washington.cs.pl_if.gui.table.RowComparator;
import edu.washington.cs.pl_if.gui.table.TableRow;
import edu.washington.cs.pl_if.gui.table.UpdateThread;
import edu.washington.cs.pl_if.rpc.client.RpcClient;

public class SelectHostsWizard extends Wizard {

	private HostSelectPage hostSelectPage;

	private String[] selectedHosts = new String[0];

	public SelectHostsWizard(Integer[] allHosts, String description) {
		hostSelectPage = new HostSelectPage("Select hosts");
		hostSelectPage.setAvailableHosts(allHosts);
		hostSelectPage.setDescription(description);
		hostSelectPage.setTitle("Select hosts");
		this.addPage(hostSelectPage);
	}

	public void dispose() {
		hostSelectPage.dispose();
	}

	public String[] getSelectedHosts() {
		return selectedHosts;
	}

	public boolean isVisible() {
		return true;
	}

	@Override
	public boolean performFinish() {
		this.selectedHosts = hostSelectPage.getSelectedHosts();
		if (selectedHosts.length > 0) {
			// for (int i = 0; i < selectedHosts.length; i++) {
			// System.out.println(selectedHosts[i]);
			// }
			return true;
		}
		return false;
	}

	// public void updateGui() {
	// System.out.println("updated!");
	// hostSelectPage.updateGui();
	// }

	private class HostSelectPage extends WizardPage {
		private static final int BUTTON_NUM = 6;

		private static final int PROGRESS_BAR_LENGTH = 100;

		private Integer[] allHosts;

		private ProgressBar bar;

		private DataTable<SelectHostTableRow> hostTable;

		private Button nRandom;

		private Button nRandomSites;

		private Button selectAll;

		public HostSelectPage(String pageName) {
			super(pageName);
		}

		public void createControl(final Composite parent) {

			Composite topLevel = new Composite(parent, SWT.BORDER);
			GridLayout layout = new GridLayout();
			layout.numColumns = BUTTON_NUM;
			topLevel.setLayout(layout);

			// parent.setLayout(new GridLayout(1,false));
			// topLevel.setLayoutData(new
			// GridData(SWT.FILL,SWT.FILL,true,true));

			GridData makeBig = new GridData();
			makeBig.horizontalAlignment = SWT.FILL;
			makeBig.verticalAlignment = SWT.FILL;
			makeBig.grabExcessHorizontalSpace = true;
			makeBig.grabExcessVerticalSpace = true;
			makeBig.horizontalSpan = BUTTON_NUM;
			makeBig.verticalSpan = 1;

			GridData makeWide = new GridData();
			makeWide.horizontalAlignment = SWT.FILL;
			makeWide.grabExcessHorizontalSpace = true;
			makeWide.horizontalSpan = BUTTON_NUM;

			addTable(topLevel);
			hostTable.setLayoutData(makeBig);

			Composite buttonRow = new Composite(topLevel, SWT.BORDER);

			GridLayout rowLayout = new GridLayout();
			// rowLayout.wrap = true;
			rowLayout.numColumns = BUTTON_NUM;
			buttonRow.setLayout(rowLayout);
			buttonRow.setLayoutData(makeWide);
			// create the buttons

			Label quickSelectLabel = new Label(buttonRow, SWT.PUSH | SWT.SINGLE);
			quickSelectLabel.setText("Quick select: ");
			// quickSelectLabel.setLayoutData(fill);
			quickSelectLabel.setLayoutData(new GridData(
					GridData.VERTICAL_ALIGN_CENTER));

			final Text numHosts = new Text(buttonRow, SWT.BORDER | SWT.PUSH);

			numHosts.setText("num");
			numHosts
					.setForeground(new Color(parent.getDisplay(), 190, 190, 190));
			numHosts.setEditable(true);
			numHosts.addKeyListener(new KeyAdapter() {
				public void keyReleased(KeyEvent e) {
					String val = numHosts.getText();
					try {
						Integer.parseInt(val);

					} catch (NumberFormatException ex) {
						if (val.length() > 0) {
							numHosts
									.setText(val.substring(0, val.length() - 1));
						}
					}
				}
			});
			numHosts.addMouseListener(new MouseAdapter() {
				public void mouseDown(MouseEvent e) {
					String val = numHosts.getText();
					try {
						Integer.parseInt(val);

					} catch (NumberFormatException ex) {

						numHosts.setText("0");
						numHosts.setForeground(new Color(parent.getDisplay(),
								0, 0, 0));
					}
				}
			});

			SelectButtonListener buttonListener = new SelectButtonListener(
					numHosts);
			nRandomSites = new Button(buttonRow, SWT.PUSH);
			nRandomSites.setText("Random Sites");
			nRandomSites.addMouseListener(buttonListener);

			nRandom = new Button(buttonRow, SWT.PUSH);
			nRandom.setText("Random Hosts");
			nRandom.addMouseListener(buttonListener);

			selectAll = new Button(buttonRow, SWT.PUSH);
			selectAll.setText("All hosts");
			selectAll.addMouseListener(buttonListener);

			// add the progress bar
			bar = new ProgressBar(topLevel, SWT.PUSH);
			GridData barData = new GridData(GridData.GRAB_HORIZONTAL
					| GridData.FILL_HORIZONTAL);
			barData.horizontalSpan = BUTTON_NUM;
			bar.setLayoutData(barData);
			bar.setMinimum(0);
			bar.setMaximum(PROGRESS_BAR_LENGTH);

			setControl(topLevel);
			setPageComplete(true);

		}

		public void dispose() {
			hostTable.dispose();
		}

		public String[] getSelectedHosts() {
			Integer[] selected = hostTable.getCheckedIds();
			ArrayList<String> hostnames = new ArrayList<String>();

			for (int i = 0; i < selected.length; i++) {
				SelectHostTableRow row = hostTable.getTableData(selected[i]
						.intValue());
				if (row != null) {
					hostnames.add(row.getHostname());
				}
			}

			return hostnames.toArray(new String[hostnames.size()]);
		}

		public void setAvailableHosts(Integer hosts[]) {
			this.allHosts = hosts;
		}

		// public void updateGui() {
		//
		// hostTable.updateGui();
		// System.out.println("updating select table");
		// }

		public void updateProgress(double progress) {
			if (!bar.isDisposed()) {
				int i = (int) Math.round(progress * PROGRESS_BAR_LENGTH);
				bar.setSelection(i);
			}
		}

		private void addTable(Composite parent) {
			final String[] columns = { "Selected", "Site", "Hostname",
					"Load average", "comon query time", "mem free", "mem total" };
			final int[] columnWidths = { 50, 100, 100, 75, 75, 75, 75 };
			final int growColNum = 2;
			final int updateRate = 500;
			final int checkBoxPos = 0;

			hostTable = new DataTable<SelectHostTableRow>(parent, SWT.MULTI,
					columns, columnWidths, new SelectHostRowComparator());

			hostTable.setSortCol(1);
			// hostTable.setRowDoubleClickedListener(new Listener() {
			// public void handleEvent(Event event) {
			// int[] index = hostTable.getSelectedIds();
			// for (int i = 0; i < index.length; i++) {
			// hostTable.toggleChecked(index[i]);
			//
			// }
			// }
			// });

			hostTable.setMouseListener(new MouseListener() {
				public void mouseUp(MouseEvent e) {
					// Point pt = new Point(e.x, e.y);
					// Table table = (Table) e.widget;
					// TableItem item = table.getItem(pt);
					// hostTable.toggleChecked((Integer)
					// item.getData("row_id"));
				}

				public void mouseDoubleClick(MouseEvent e) {
					Point pt = new Point(e.x, e.y);
					Table table = (Table) e.widget;
					TableItem item = table.getItem(pt);
					table.deselectAll();
					table.setSelection(item);
					int[] index = hostTable.getSelectedIds();
					for (int i = 0; i < index.length; i++) {
						hostTable.toggleChecked(index[i]);

					}
				}

				public void mouseDown(MouseEvent e) {
				}
			});

			hostTable.setKeyListener(new KeyAdapter() {
				public void keyReleased(KeyEvent e) {
					System.out.println(e.keyCode);
					if (e.keyCode == 32) {
						int[] selectedRows = hostTable.getSelectedIds();
						for (int i = 0; i < selectedRows.length; i++) {
							int rowId = selectedRows[i];
							hostTable.toggleChecked(rowId);
						}
					}
				}
			});
			hostTable.setResizePolicy(growColNum);
			hostTable.setCheckBoxCol(checkBoxPos);
			hostTable.setLayoutData(BorderLayout.CENTER);

			hostTable.setUpdateThread(new UpdateSelectHostTableThread(this,
					hostTable, allHosts, updateRate), "selectHostUpdateThread");
		}

		private class SelectButtonListener extends MouseAdapter {
			private final Text numHosts;

			private SelectButtonListener(final Text numHosts) {
				super();
				this.numHosts = numHosts;
			}

			public void mouseUp(MouseEvent e) {
				if (e.getSource().equals(selectAll)) {
					selectHosts(hostTable.getAllRows().size());
				} else {
					try {
						int num = Integer.parseInt(numHosts.getText());
						if (e.getSource().equals(nRandomSites)) {
							System.out.println("sites: " + num);
							selectSites(num);
						} else if (e.getSource().equals(nRandom)) {
							System.out.println("hosts: " + num);
							selectHosts(num);
						}
					} catch (NumberFormatException ex) {
						MessageBox messageBox = new MessageBox(hostSelectPage
								.getShell(), SWT.ICON_ERROR | SWT.OK);
						messageBox.setText("number error");
						messageBox
								.setMessage("You must specify the number to select");
						messageBox.open();
					}
				}
			}

			private void selectSites(int num) {
				List<SelectHostTableRow> allRows = hostTable.getAllRows();
				List<String> allSites = new ArrayList<String>();
				List<String> selectedSites = new ArrayList<String>();
				List<String> alreadySelectedSites = new ArrayList<String>();
				HashMap<String, ArrayList<Integer>> siteMapping = new HashMap<String, ArrayList<Integer>>();

				for (int i = 0; i < allRows.size(); i++) {
					if (allRows.get(i).getRowId() > 0) {
						int row = allRows.get(i).getRowId();
						String site = allRows.get(i).getSite();
						// check if this row is checked already
						if (hostTable.isChecked(row)) {
							// add to checked sites
							alreadySelectedSites.add(site);
						}
						if (!siteMapping.containsKey(site)) {
							siteMapping.put(site, new ArrayList<Integer>());
						}
						siteMapping.get(site).add(row);

					}
				}

				// take out the sites that already have a selected host in them
				for (String site : alreadySelectedSites) {
					siteMapping.remove(site);
				}

				allSites.addAll(siteMapping.keySet());

				// create a random list of sites
				if (num >= allSites.size()) {
					selectedSites = allSites;
				} else {
					while (selectedSites.size() < num && allSites.size() > 0) {
						int rand = (int) (Math.random() * allSites.size());
						selectedSites.add(allSites.remove(rand));

					}
				}
				// for each selected site, select a random host in that site
				for (String site : selectedSites) {
					List<Integer> hosts = siteMapping.get(site);
					int host = (int) Math.round((hosts.size() - 1)
							* Math.random());
					hostTable.toggleChecked(hosts.get(host));
					System.out.println(site + ":" + host);
				}
			}

			private void selectHosts(int num) {
				List<SelectHostTableRow> allRows = hostTable.getAllRows();
				List<Integer> allIds = new ArrayList<Integer>();
				List<Integer> selectedIds = new ArrayList<Integer>();

				// create a list of all hosts that are not selected yet
				for (int i = 0; i < allRows.size(); i++) {
					if (allRows.get(i).getRowId() > 0) {
						if (!hostTable.isChecked(allRows.get(i).getRowId())) {
							allIds.add(allRows.get(i).getRowId());
						}
					}
				}

				if (num >= allIds.size()) {
					selectedIds = allIds;
				} else {
					// loop until we have selected enough hosts
					while (selectedIds.size() < num && allIds.size() > 0) {
						int rand = (int) (Math.random() * allIds.size());
						selectedIds.add(allIds.remove(rand));

					}
				}

				// toggle the checkbox, this is safe since all hosts that are
				// selected not are checked
				for (int i = 0; i < selectedIds.size(); i++) {
					hostTable.toggleChecked(selectedIds.get(i));
					// System.out.println("" + selectedIds.get(i));
				}
			}

		}
	}

	private class SelectHostRowComparator implements
			RowComparator<SelectHostTableRow> {

		private int column;

		private int direction;

		private RowComparator<SelectHostTableRow> genericComparator = new GenericRowComparator<SelectHostTableRow>();

		/*
		 * (non-Javadoc)
		 * 
		 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#compare(edu.washington.cs.pl_if.gui.table.host.HostTableRow,
		 *      edu.washington.cs.pl_if.gui.table.host.HostTableRow)
		 */
		public int compare(SelectHostTableRow r1, SelectHostTableRow r2) {
			int rc = 0;
			final int LOAD = 3;
			final int RESPONSE = 4;
			final int MEM_FREE = 5;
			final int MEM_TOTAL = 6;
			// Determine which field to sort on, then sort
			// on that field
			switch (column) {
			case LOAD:
				Double d1 = r1.getLoadAverage();
				Double d2 = r2.getLoadAverage();
				rc = d1.compareTo(d2);
				break;
			case RESPONSE:
				d1 = r1.getResponseTime();
				d2 = r2.getResponseTime();
				rc = d1.compareTo(d2);
				break;
			case MEM_FREE:
				d1 = r1.getMemFree();
				d2 = r2.getMemFree();
				rc = d1.compareTo(d2);
				break;
			case MEM_TOTAL:
				d1 = r1.getMemTotal();
				d2 = r2.getMemTotal();
				rc = d1.compareTo(d2);
				break;

			default:
				return genericComparator.compare(r1, r2);
			}

			// Check the direction for sort and flip the sign
			// if appropriate
			if (direction == DESCENDING) {
				rc = -rc;
			}
			return rc;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#reverseDirection()
		 */
		public void reverseDirection() {
			direction = 1 - direction;
			genericComparator.setDirection(direction);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#setColumn(int)
		 */
		public void setColumn(int column) {
			this.column = column;
			genericComparator.setColumn(column);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#setDirection(int)
		 */
		public void setDirection(int direction) {
			this.direction = direction;
			genericComparator.setDirection(direction);
		}
	}

	private class SelectHostTableRow implements TableRow {

		private boolean checked;

		

		private final String hostname;

		private final int id;

		private final double loadAverage;

		private final double responseTime;

		private final double memFree;

		private final double memTotal;

		private final String site;

		public SelectHostTableRow(Map map, boolean checked) {
			this.hostname = (String) map.get("hostname");
			this.site = (String) map.get("site");
			this.loadAverage = parseDouble((String) map.get("load_average"));
			this.responseTime = parseDouble((String) map.get("response_time"));
			this.id = Integer.parseInt((String) map.get("node_id"));
			this.memFree = parseDouble((String) map.get("mem_free"));
			this.memTotal = parseDouble((String) map.get("mem_total"));
		}

		public void setChecked(boolean checked) {
			this.checked = checked;
		}

		public String getHostname() {
			return hostname;
		}

		public double getLoadAverage() {
			return loadAverage;
		}

		public double getResponseTime() {
			return responseTime;
		}

		public int getRowId() {
			return id;
		}

		public String getSite() {
			return site;
		}

		public boolean isVisible() {
			return true;
		}

		public String[] toStringArray() {

			String[] str = { checked ? " " : "", site, hostname,
					doubleToString(loadAverage), doubleToString(responseTime),
					doubleToString(memFree), doubleToString(memTotal) };

			return str;
		}

		private String doubleToString(double d) {
			if (Double.isNaN(d)) {
				return "?";
			}
			return "" + (Math.round(d * 100.0) / 100.0);
		}

		private double parseDouble(String string) {
			try {
				if (string != null) {
					double d = Double.parseDouble(string);

					return d;
				}
			} catch (NumberFormatException e) {
				// ignore, there was an error
				System.err.println("comon: " + this.hostname
						+ " parse error double: '" + string + "'");
			}
			return Double.NaN;
		}

		public int getId() {
			return id;
		}

		public double getMemFree() {
			return memFree;
		}

		public double getMemTotal() {
			return memTotal;
		}
	}

	private class UpdateSelectHostTableThread implements
			UpdateThread<SelectHostTableRow> {
		private final Integer[] allHosts;

		private int maxSleepTime;

		private final HostSelectPage parent;

		private final DataTable<SelectHostTableRow> parentTable;

		private volatile boolean quit = false;

		public UpdateSelectHostTableThread(HostSelectPage parent,
				DataTable<SelectHostTableRow> parentTable, Integer[] allHosts,
				int maxSleepTime) {
			this.allHosts = allHosts;
			this.parent = parent;
			this.parentTable = parentTable;
			this.maxSleepTime = maxSleepTime;
		}

		public void halt() {
			// System.out.println("stopping update thread");
			this.quit = true;
		}

		public void run() {
			try {
				RpcClient.getInstance().fetchCoMonData();

				while (!quit) {
					final double coMonProgress = RpcClient.getInstance()
							.getCoMonProgress();
					// System.out.println("Comon: " + coMonProgress);
					if (coMonProgress == 1.0) {
						quit = true;
						System.out.println("comon: done");
					}
					Object[] rowData = RpcClient.getInstance().getHostStats(
							allHosts);

					Vector<SelectHostTableRow> newData = new Vector<SelectHostTableRow>(
							rowData.length);

					for (int i = 0; i < rowData.length; i++) {
						Map rowMap = (Map) rowData[i];
						String rowId = (String) rowMap.get("node_id");
						// just make sure rowId isn't null
						rowId = (rowId == null) ? "-1" : rowId;
						newData.add(new SelectHostTableRow(rowMap, parentTable
								.isChecked(Integer.parseInt(rowId))));
					}
					// System.out.println("got data: " + rowData.length);
					parentTable.setTableData(newData);
					if (!parentTable.isDisposed()) {
						parentTable.getDisplay().asyncExec(new Runnable() {
							public void run() {
								// System.out.println("updating table");
								parent.updateProgress(coMonProgress);
								parentTable.updateGui();

							}
						});
					}
					Thread.sleep(maxSleepTime);

				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
}
