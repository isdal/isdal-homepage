package edu.washington.cs.pl_if.gui;


import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

import swing2swt.layout.BorderLayout;
import edu.washington.cs.pl_if.gui.table.DataTable;
import edu.washington.cs.pl_if.gui.table.command.CommandOverviewRow;
import edu.washington.cs.pl_if.gui.table.command.CommandOverviewUpdateThread;

public class GuiCommandOverview extends Composite{

	DataTable<CommandOverviewRow> commandTable;

	final int commandId;

	public GuiCommandOverview(Composite parent, int style, int commandId) {
		super(parent, style);
		setLayout(new BorderLayout(1, 1));
		this.commandId = commandId;
		this.createTableHost(this);
		//System.out.println("created table");
		commandTable.setLayoutData(BorderLayout.CENTER);
	}

	public void update(){
		commandTable.updateGui();
		super.update();
	}
	
	private void createTableHost(final Composite parent) {

		final String[] columns = { "Site", "Hostname", "Exec command",
				"Exit status", "Time", "Outputed rows", "Last line" };
		final int[] columnWidths = { 100, 200, 100, 75, 50, 100, 50 };
		final int growColNum = 6;
		final int updateRate = 1000;
		//Composite comp = new Composite(parent,SWT.NONE);
		//comp.setLayout(new BorderLa)
		commandTable = new DataTable<CommandOverviewRow>(parent, SWT.SINGLE,
				columns, columnWidths, null);

		commandTable.setRowDoubleClickedListener(new Listener() {
			public void handleEvent(Event event) {

				int index = (commandTable.getSelectedIds().length > 0) ? commandTable.getSelectedIds()[0] : -1;
				if (index >= 0) {
					GuiMain.getInstance().addShowTab(index);
				}
			}
		});
		
		commandTable.setResizePolicy(growColNum);

		//commandTable.setProgressBarCol(progressBarPos);
		commandTable.setUpdateThread(new CommandOverviewUpdateThread(
				commandTable, updateRate,commandId), "host_status");
		commandTable.setLayoutData(BorderLayout.CENTER);
	}

	public boolean shouldUpdate() {
		
		return true;
	}

	

}
