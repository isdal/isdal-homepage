package edu.washington.cs.pl_if.gui;

import java.awt.FlowLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabFolder2Adapter;
import org.eclipse.swt.custom.CTabFolderEvent;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import swing2swt.layout.BorderLayout;
import edu.washington.cs.pl_if.Credentials;
import edu.washington.cs.pl_if.Main;
import edu.washington.cs.pl_if.gui.console.Console;
import edu.washington.cs.pl_if.rpc.client.RpcClient;

public class GuiMain implements Runnable {

	public final static long GUI_MAX_SLEEP_TIME = 500;

	public static final String[] HOST_FILE_FILTER = { "*.hosts" };

	public final static long OVERVIEW_UPDATE_LIMIT = 500;

	public Vector<RequiresUpdates> guiUpdateElements = new Vector<RequiresUpdates>();

	public volatile static boolean running = false;

	private static Credentials cred;

	private static GuiMain instance = null;

	private static boolean quit = false;

	private long CONSOLE_TAB_UPDATE_LIMIT = 200;

	private GuiHostOverview guiHostOverview;

	private GuiUpdateThread guiUpdateThread;

	// private long lastOverviewUpdate = 0;

	private long lastTabUpdate = 0;

	private volatile boolean showDisconnected = false;

	private final ConcurrentHashMap<String, CTabItem> tabItems = new ConcurrentHashMap<String, CTabItem>();

	protected Display display;

	protected Shell shell;

	protected CTabFolder tabFolder = null;

	public static GuiMain getInstance() {
		if (instance == null) {
			instance = new GuiMain();
		}
		return instance;
	}

	public static GuiMain getInstance(Credentials cred, InetAddress server) {
		if (instance == null) {
			RpcClient.getInstance().startClient(server, cred);
			instance = new GuiMain();
		}

		return instance;
	}

	public static void main(String args[]) {

		try {
			Map<String, String> argMap = Main.parseArgs(args);
			String configFile = "pl_manager.conf";
			if (argMap.containsKey("config")) {
				configFile = argMap.get("config");
			}
			System.out.println(configFile);

			Map<String, String> config;

			config = Main.getConfigFromFile(configFile);
			Main.prompt(config);

			cred = new Credentials(config);
			System.out.println(cred.toString());

			GuiMain.getInstance();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// this is to fix the strange os x swt crap
		if (System.getProperty("os.name").contains("Mac OS X")
				&& System.getProperty("os.version").contains("10.5")) {
			while (running) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	protected GuiMain() {
		running = true;

		Thread t = new Thread(this);
		t.setName("Gui");
		// for some reason this is needed on the mac
		if (System.getProperty("os.name").contains("Mac OS X")
				&& System.getProperty("os.version").contains("10.5")) {
			t.setDaemon(false);
		}
		t.start();
	}

	public void addCommandTab(int commandId) {
		String title = RpcClient.getInstance().getCommand(commandId);
		if (!tabItems.containsKey(title)) {

			final CTabItem tabItem = new CTabItem(tabFolder, SWT.CLOSE);
			tabItem.setText(title);
			GuiCommandOverview overview = new GuiCommandOverview(tabFolder,
					SWT.NONE, commandId);
			tabItem.setControl(overview);
			tabItems.put(title, tabItem);
		}
		tabFolder.setSelection(tabItems.get(title));
	}

	public void addShowTab(int hostIndex) {

		String hostname = RpcClient.getInstance().getHostname(hostIndex);
		if (!tabItems.containsKey(hostname)) {

			final CTabItem tabItem = new CTabItem(tabFolder, SWT.CLOSE);
			tabItem.setText(hostname);

			// System.err.println(tabFolder.hashCode());
			Console console = new Console(tabFolder, SWT.NONE, hostIndex);
			tabItem.setControl(console);
			tabItems.put(hostname, tabItem);
		}
		tabFolder.setSelection(tabItems.get(hostname));

	}

	public void downloadDir(String remotePath, String localPath, String filter,
			String namingType) {
		RpcClient.getInstance().download(remotePath, localPath, filter,
				namingType);
	}

	public boolean isDisposed() {
		return shell.isDisposed();
	}

	public boolean isShowDisconnected() {
		return showDisconnected;
	}

	public void kill() {
		quit = true;
		guiUpdateThread.halt();

	}

	public void lostConnection() {
		MessageBox messageBox = new MessageBox(shell, SWT.ICON_QUESTION
				| SWT.OK);
		messageBox.setMessage("Lost connection to controller");
		messageBox.setText("Connection lost");
		messageBox.open();
		quit();

	}

	/**
	 * Open the window
	 */
	public final void open() {

		shell.addListener(SWT.Close, new Listener() {
			public void handleEvent(Event event) {
				if (!quit) {
					quit();
				}
			}
		});
		shell.addShellListener(new ShellAdapter() {
			public void shellClosed(ShellEvent e) {
				if (!quit) {
					quit();
				}
			}

		});

		display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();

		guiUpdateThread = new GuiUpdateThread(this);
		guiUpdateThread.start();

		while (!shell.isDisposed() && !quit) {
			if (!display.readAndDispatch()) {
				this.refresh();
				display.sleep();
			}

		}
	}

	public void quit() {
		quit = true;
		MessageBox messageBox = new MessageBox(shell, SWT.ICON_QUESTION
				| SWT.YES | SWT.NO);
		messageBox
				.setMessage("Do want to close the connection controller as well?");
		messageBox.setText("Exiting Gui");
		int response = messageBox.open();
		if (response == SWT.CANCEL) {
			return;
		} else if (response == SWT.YES) {
			RpcClient.getInstance().shutdown();
		}

		guiUpdateThread.halt();

	}

	public void refresh() {
		synchronized (guiUpdateElements) {
			//
			for (int i = 0; i < guiUpdateElements.size(); i++) {
				RequiresUpdates element = guiUpdateElements.get(i);
				if (element.isVisible() && element.shouldUpdate()) {
					element.updateGui();
					// System.out.println("gui update: " + i);
				}
			}
		}

		updateConsoleTabs();
	}

	public void run() {
		// System.err.println("Starting gui");
		shell = new Shell();
		// System.err.println("created shell");

		if (cred != null) {
			IpInputDialog dialog = new IpInputDialog(shell);
			dialog.setTitle("Enter controller ip");
			dialog.setText("Please enter controller ip or hostname:");
			dialog.setDefaultHost("127.0.0.1");
			InetAddress server = (dialog.open());
			if (server == null) {
				System.exit(1);
			}
			RpcClient.getInstance().startClient(server, cred);
		}
		this.open();
		running = false;
	}

	public void setShowDisconnected(boolean showDisconnected) {
		System.out.println("Show disc:" + showDisconnected);
		this.showDisconnected = showDisconnected;
		this.refresh();
	}

	public void updateConsoleTabs() {
		CTabItem showingItem = tabFolder.getSelection();
		if (showingItem != null) {
			if (tabItems.containsKey(showingItem.getText())) {
				if (System.currentTimeMillis() > lastTabUpdate
						+ CONSOLE_TAB_UPDATE_LIMIT) {

					tabFolder.getSelection().getControl().update();
					lastTabUpdate = System.currentTimeMillis();
				}
			}
		}
	}

	// public void updateOverview() {
	// // guiHostOverview.isVisible();
	// if (guiHostOverview.isVisible()) {
	// if (System.currentTimeMillis() > lastOverviewUpdate
	// + OVERVIEW_UPDATE_LIMIT) {
	// if (guiHostOverview != null) {
	// // if (!guiHostOverview.isDisposed()) {
	// guiHostOverview.updateGuiData();
	// // }
	// }
	// lastOverviewUpdate = System.currentTimeMillis();
	// }
	// }
	// }

	public void wakeUpDisplay() {
		shell.getDisplay().wake();
	}

	private void checkForUpdates() {
		boolean newVersion = Main.checkForUpdates();
		if (newVersion) {
			MessageBox messageBox = new MessageBox(shell, SWT.OK | SWT.CANCEL
					| SWT.ICON_INFORMATION);
			messageBox.setMessage("New version available");
			messageBox.setMessage("A new version is available, upgrade now?");
			if (messageBox.open() == SWT.OK) {
				System.out.println("updating");

				boolean success = Main.update();
				if (success) {
					messageBox = new MessageBox(shell, SWT.OK | SWT.CANCEL
							| SWT.ICON_WORKING);
					messageBox.setText("Success");
					messageBox
							.setMessage("Update successful, press ok to close now, cancel to close later later");
					if (messageBox.open() == SWT.OK) {
						this.quit();
					}
				} else {
					messageBox = new MessageBox(shell, SWT.OK | SWT.ICON_ERROR);
					messageBox.setText("Error");
					messageBox.setMessage("There was a problem during update");
					messageBox.open();
				}
			}
		} else {
			MessageBox messageBox = new MessageBox(shell, SWT.OK
					| SWT.ICON_WORKING);
			messageBox.setText("No new version available");
			messageBox.setMessage("You are running the latest version");
			messageBox.open();
		}
	}

	private void connectToHostsInFilePrompt() {
		FileDialog fileDialog = new FileDialog(shell, SWT.SINGLE);
		fileDialog.setFilterPath(".");

		fileDialog.setFilterExtensions(GuiMain.HOST_FILE_FILTER);
		fileDialog.setText("Select file to load hosts from");
		String fileString = fileDialog.open();

		if (fileString != null) {
			try {
				BufferedReader reader = new BufferedReader(new FileReader(
						fileString));

				String line = reader.readLine();
				while (line != null) {
					try {
						InetAddress host = InetAddress.getByName(line);
						RpcClient.getInstance().connectToHost(
								host.getHostName());
					} catch (UnknownHostException e) {
						System.err.println("unable to resolve host: '" + line
								+ "'");
					}
					line = reader.readLine();
				}
				reader.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void addHostInFileToSlicePrompt() {
		FileDialog fileDialog = new FileDialog(shell, SWT.SINGLE);
		fileDialog.setFilterPath(".");

		fileDialog.setFilterExtensions(GuiMain.HOST_FILE_FILTER);
		fileDialog.setText("Select file to load hosts from");
		String fileString = fileDialog.open();

		if (fileString != null) {
			try {
				BufferedReader reader = new BufferedReader(new FileReader(
						fileString));

				String line = reader.readLine();
				ArrayList<String> hostNames = new ArrayList<String>();
				while (line != null) {
					InetAddress host = InetAddress.getByName(line);
					hostNames.add(host.getHostName());

					line = reader.readLine();
				}

				RpcClient.getInstance().addHostsToSlice(
						hostNames.toArray(new String[hostNames.size()]));
				reader.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void createConnectMenu(Menu menuBar) {
		Menu connectMenu;
		MenuItem connectHeader;
		final MenuItem quickConnectIem;
		final MenuItem numberedConnectItem;
		final MenuItem connectToFileItem;
		final MenuItem saveConnectedToFileItem;
		final MenuItem saveFinishedToFileItem;
		final MenuItem selectWizard;
		// connect menu
		connectMenu = new Menu(shell, SWT.DROP_DOWN);

		connectHeader = new MenuItem(menuBar, SWT.CASCADE);
		connectHeader.setText("&Connect");
		connectHeader.setMenu(connectMenu);

		quickConnectIem = new MenuItem(connectMenu, SWT.PUSH);
		quickConnectIem.setText("Quick connect");
		quickConnectIem.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				openDialog();
			}

			public void widgetSelected(SelectionEvent e) {
				openDialog();
			}

			private void openDialog() {
				IpInputDialog dialog = new IpInputDialog(shell);
				dialog.setTitle("Connect to host");
				dialog.setText("Please enter ip or hostname:");
				InetAddress server = (dialog.open());
				if (server != null) {
					RpcClient.getInstance().connectToHost(server.getHostName());
				}
			}
		});
		numberedConnectItem = new MenuItem(connectMenu, SWT.PUSH);
		numberedConnectItem.setText("Connect to numbered hosts");
		numberedConnectItem.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				openDialog();
			}

			public void widgetSelected(SelectionEvent e) {
				openDialog();
			}

			private void openDialog() {
				NumberedIpInputDialog dialog = new NumberedIpInputDialog(shell);
				dialog.setTitle("Connect to host");
				dialog.setText("Please enter ip or hostname:");
				InetAddress[] servers = (dialog.open());
				if (servers != null) {
					for (InetAddress server : servers) {
						RpcClient.getInstance().connectToHost(
								server.getHostName());
					}
				}
			}
		});

		new MenuItem(connectMenu, SWT.SEPARATOR);
		connectToFileItem = new MenuItem(connectMenu, SWT.PUSH);
		connectToFileItem.setText("Connect to hosts in file");
		connectToFileItem.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				connectToHostsInFilePrompt();
			}

			public void widgetSelected(SelectionEvent e) {
				connectToHostsInFilePrompt();
			}
		});

		saveConnectedToFileItem = new MenuItem(connectMenu, SWT.PUSH);
		saveConnectedToFileItem.setText("Save connected hosts to file");
		saveConnectedToFileItem.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				saveConnectedHostsToFilePrompt();
			}

			public void widgetSelected(SelectionEvent e) {
				saveConnectedHostsToFilePrompt();
			}
		});

		saveFinishedToFileItem = new MenuItem(connectMenu, SWT.PUSH);
		saveFinishedToFileItem.setText("Save finished hosts to file");
		saveFinishedToFileItem.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				saveFinishedHostsToFilePrompt();
			}

			public void widgetSelected(SelectionEvent e) {
				saveFinishedHostsToFilePrompt();
			}
		});

		new MenuItem(connectMenu, SWT.SEPARATOR);

		selectWizard = new MenuItem(connectMenu, SWT.PUSH);
		selectWizard.setText("Select hosts wizard");
		selectWizard.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				createDialog();
			}

			public void widgetSelected(SelectionEvent e) {
				createDialog();
			}

			private void createDialog() {
				Object[] allHosts = RpcClient.getInstance().getAvailableHosts();
				Integer[] hosts = new Integer[allHosts.length];
				for (int i = 0; i < allHosts.length; i++) {
					hosts[i] = (Integer) allHosts[i];

				}
				System.out.println("allhosts: " + allHosts.length);
				SelectHostsWizard d = new SelectHostsWizard(hosts,
						"Select the hosts to connect to");

				WizardDialog dialog = new WizardDialog(shell, d);

				dialog.open();

				d.dispose();
				String[] selectedHosts = d.getSelectedHosts();
				for (int i = 0; i < selectedHosts.length; i++) {
					String host = selectedHosts[i];
					RpcClient.getInstance().connectToHost(host);
				}
			}
		});

	}

	private void createTransferMenu(Menu menuBar) {
		Menu transferMenu;
		MenuItem transferHeader;
		final MenuItem transferUploadDir;
		final MenuItem transferUploadFile;
		final MenuItem transferDownload;
		transferMenu = new Menu(shell, SWT.DROP_DOWN);

		transferHeader = new MenuItem(menuBar, SWT.CASCADE);
		transferHeader.setText("&Transfer");
		transferHeader.setMenu(transferMenu);

		transferUploadDir = new MenuItem(transferMenu, SWT.PUSH);
		transferUploadDir.setText("&Upload Directory");
		transferUploadDir.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				showDirPrompt();
			}

			public void widgetSelected(SelectionEvent e) {
				showDirPrompt();
			}

			private void showDirPrompt() {
				String path = uploadDirPrompt();
				if (path != null) {
					RpcClient.getInstance().upload(path);
				}
			}

		});

		transferUploadFile = new MenuItem(transferMenu, SWT.PUSH);
		transferUploadFile.setText("&Upload File");
		transferUploadFile.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				showFilePrompt();
			}

			public void widgetSelected(SelectionEvent e) {
				showFilePrompt();
			}

			private void showFilePrompt() {
				String path = uploadFilePrompt();
				if (path != null) {
					RpcClient.getInstance().upload(path);
				}
			}

		});

		new MenuItem(transferMenu, SWT.SEPARATOR);
		transferDownload = new MenuItem(transferMenu, SWT.PUSH);
		transferDownload.setText("&Download Wizard");
		transferDownload.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				this.createDialog();
			}

			public void widgetSelected(SelectionEvent e) {
				this.createDialog();
			}

			private void createDialog() {
				DownloadWizard d = new DownloadWizard(getInstance());
				WizardDialog dialog = new WizardDialog(shell, d);
				dialog.open();
			}

		});
	}

	private void saveConnectedHostsToFilePrompt() {
		FileDialog fileDialog = new FileDialog(shell, SWT.SAVE);
		fileDialog.setFilterPath(".");
		fileDialog.setFilterExtensions(GuiMain.HOST_FILE_FILTER);
		fileDialog.setText("Choose file to save to");
		String fileString = fileDialog.open();

		if (fileString != null) {
			try {
				BufferedWriter writer = new BufferedWriter(new FileWriter(
						fileString));

				Object[] hosts = RpcClient.getInstance().getConnectedHosts();
				for (int i = 0; i < hosts.length; i++) {
					String host = (String) hosts[i];
					writer.write(host + "\n");
				}
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void saveFinishedHostsToFilePrompt() {
		FileDialog fileDialog = new FileDialog(shell, SWT.SAVE);
		fileDialog.setFilterPath(".");
		fileDialog.setFilterExtensions(GuiMain.HOST_FILE_FILTER);
		fileDialog.setText("Choose file to save to");
		String fileString = fileDialog.open();

		if (fileString != null) {
			try {
				BufferedWriter writer = new BufferedWriter(new FileWriter(
						fileString));
				int totalCommandNum = RpcClient.getInstance().totalCommandNum();

				Object[] rowData = RpcClient.getInstance()
						.getHostStatusOverview();

				for (int i = 0; i < rowData.length; i++) {
					Map map = (Map) rowData[i];
					String host = (String) map.get("hostname");
					int completedCommandNum = (Integer) map
							.get("completed_command_num");
					if (completedCommandNum == totalCommandNum) {
						writer.write(host + "\n");
					}
				}

				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private String uploadDirPrompt() {
		DirectoryDialog dialog = new DirectoryDialog(shell);
		dialog.setFilterPath("."); // Windows specific
		String path = dialog.open();
		return path;

	}

	private String uploadFilePrompt() {
		FileDialog dialog = new FileDialog(shell);
		dialog.setFilterPath("."); // Windows specific
		String path = dialog.open();
		return path;
	}

	/**
	 * Create contents of the window
	 */
	protected void createContents() {

		shell.setLayout(new BorderLayout(0, 0));
		shell.setSize(800, 600);
		shell.setText("PL experiment manager");

		tabFolder = new CTabFolder(shell, SWT.BORDER);
		tabFolder.setLayoutData(BorderLayout.CENTER);

		final CTabItem overviewTabItem = new CTabItem(tabFolder, SWT.NONE);
		overviewTabItem.setText("Overview");
		guiHostOverview = new GuiHostOverview(tabFolder, SWT.NONE);
		synchronized (guiUpdateElements) {
			guiUpdateElements.add(guiHostOverview);
		}

		overviewTabItem.setControl(guiHostOverview);

		tabFolder.setSimple(false);
		tabFolder.setUnselectedCloseVisible(false);
		tabFolder.setUnselectedImageVisible(false);

		tabFolder.addCTabFolder2Listener(new CTabFolder2Adapter() {
			public void close(CTabFolderEvent e) {
				if (e.item.equals(overviewTabItem)) {
					e.doit = false;
				} else {
					tabItems.remove(((CTabItem) e.item).getText());
				}
			}
		});

		// final CTabItem item3 = new CTabItem(tabFolder, SWT.NONE);
		// item3.setText("tab3");
		// System.err.println(tabFolder.hashCode());
		//
		this.createMenuBar();
	}

	protected void createMenuBar() {
		Menu menuBar, fileMenu, helpMenu, viewMenu, plcMenu;

		MenuItem fileMenuHeader, helpMenuHeader, viewMenuHeader, plcMenuHeader;

		final MenuItem fileExitItem, helpGetHelpItem, helpCheckUpdate, viewShowDisconnected, plcAddAllHosts;

		menuBar = new Menu(shell, SWT.BAR);

		// file menu
		fileMenu = new Menu(shell, SWT.DROP_DOWN);

		fileMenuHeader = new MenuItem(menuBar, SWT.CASCADE);
		fileMenuHeader.setText("&File");
		fileMenuHeader.setMenu(fileMenu);

		new MenuItem(fileMenu, SWT.SEPARATOR);
		fileExitItem = new MenuItem(fileMenu, SWT.PUSH);
		fileExitItem.setText("E&xit");
		fileExitItem.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				quit();
			}

			public void widgetSelected(SelectionEvent e) {
				quit();
			}
		});

		// view menu
		viewMenu = new Menu(shell, SWT.DROP_DOWN);

		viewMenuHeader = new MenuItem(menuBar, SWT.CASCADE);
		viewMenuHeader.setText("&View");
		viewMenuHeader.setMenu(viewMenu);

		viewShowDisconnected = new MenuItem(viewMenu, SWT.CHECK);
		viewShowDisconnected.setText("&Show disconnected");
		viewShowDisconnected.setSelection(showDisconnected);
		viewShowDisconnected.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				setShowDisconnected(viewShowDisconnected.getSelection());
			}

			public void widgetSelected(SelectionEvent e) {
				setShowDisconnected(viewShowDisconnected.getSelection());
			}

		});
		// create the Connect menu
		createConnectMenu(menuBar);

		// transfer menu
		createTransferMenu(menuBar);

		// plc menu
		plcMenu = new Menu(shell, SWT.DROP_DOWN);

		plcMenuHeader = new MenuItem(menuBar, SWT.CASCADE);
		plcMenuHeader.setText("&PLC");
		plcMenuHeader.setMenu(plcMenu);

		plcAddAllHosts = new MenuItem(plcMenu, SWT.PUSH);
		plcAddAllHosts.setText("&Add Hosts to Slice");
		plcAddAllHosts.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				this.add();
			}

			public void widgetSelected(SelectionEvent e) {
				this.add();
			}

			private void add() {

				ArrayList<Integer> hostnames = new ArrayList<Integer>();
				Object[] hosts = RpcClient.getInstance().getHostsNotInSlice();
				for (int i = 0; i < hosts.length; i++) {
					Integer hostId = (Integer) hosts[i];
					hostnames.add(hostId);
				}

				// System.out.println("got " + hostnames.size());

				if (hostnames.size() > 0) {

					SelectHostsWizard d = new SelectHostsWizard(hostnames
							.toArray(new Integer[hostnames.size()]),
							"Select the hosts to be added to the slice ");
					// + cred.getSlice() + "'.");

					WizardDialog dialog = new WizardDialog(shell, d);

					dialog.open();

					d.dispose();
					String[] selectedHosts = d.getSelectedHosts();

					RpcClient.getInstance().addHostsToSlice(selectedHosts);
				} else {
					MessageBox messageBox = new MessageBox(shell,
							SWT.ICON_WORKING | SWT.OK);
					messageBox
							.setMessage("All nodes are already in this slice");
					messageBox.setText("All nodes in slice");
					messageBox.open();

				}

			}

		});

		MenuItem plcAddHostsInFile = new MenuItem(plcMenu, SWT.PUSH);
		plcAddHostsInFile.setText("Add Hosts in &File to Slice");
		plcAddHostsInFile.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				this.add();
			}

			public void widgetSelected(SelectionEvent e) {
				this.add();
			}

			private void add() {
				addHostInFileToSlicePrompt();
			}
		});

		// help menu
		helpMenuHeader = new MenuItem(menuBar, SWT.CASCADE);
		helpMenuHeader.setText("&Help");

		helpMenu = new Menu(shell, SWT.DROP_DOWN);
		helpMenuHeader.setMenu(helpMenu);

		helpCheckUpdate = new MenuItem(helpMenu, SWT.PUSH);
		helpCheckUpdate.setText("&Check for updates");
		helpCheckUpdate.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				checkForUpdates();
			}

			public void widgetSelected(SelectionEvent e) {
				checkForUpdates();
			}

		});
		new MenuItem(helpMenu, SWT.SEPARATOR);
		helpGetHelpItem = new MenuItem(helpMenu, SWT.PUSH);
		helpGetHelpItem.setText("&About");

		shell.setMenuBar(menuBar);

	}

	// small thread making sure that the gui is updated at least every x ms
	private class GuiUpdateThread extends Thread {
		private boolean quit = false;

		GuiMain parent;

		public GuiUpdateThread(GuiMain parent) {
			this.setDaemon(true);
			this.setName("GuiUpdateThread");
			this.parent = parent;
		}

		public void halt() {
			quit = true;
			this.interrupt();
		}

		public void run() {
			while (!quit && !parent.isDisposed()) {

				parent.wakeUpDisplay();
				try {
					Thread.sleep(GuiMain.GUI_MAX_SLEEP_TIME);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
				}
			}
		}
	}

	private class IpInputDialog extends Dialog {
		private String defaultHost = "";

		private String text = "";

		private String title = "";

		private InetAddress value;

		/**
		 * @param parent
		 */
		public IpInputDialog(Shell parent) {
			super(parent);
		}

		/**
		 * @param parent
		 * @param style
		 */
		public IpInputDialog(Shell parent, int style) {
			super(parent, style);
		}

		/**
		 * Makes the dialog visible.
		 * 
		 * @return
		 */
		public InetAddress open() {
			Shell parent = getParent();
			final Shell shell = new Shell(parent, SWT.TITLE | SWT.BORDER
					| SWT.APPLICATION_MODAL);
			shell.setText(title);

			shell.setLayout(new GridLayout(2, true));

			Label label = new Label(shell, SWT.NULL);
			label.setText(text);

			final Text inputText = new Text(shell, SWT.SINGLE | SWT.BORDER);
			GridData makeBig = new GridData();
			makeBig.horizontalAlignment = SWT.FILL;
			inputText.setLayoutData(makeBig);
			inputText.setSize(100, 20);
			inputText.setText(defaultHost);
			// inputText.setLayoutData(layoutData)
			final Button buttonOK = new Button(shell, SWT.PUSH);
			buttonOK.setText("Ok");
			buttonOK.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));
			Button buttonCancel = new Button(shell, SWT.PUSH);
			buttonCancel.setText("Cancel");

			inputText.addKeyListener(new KeyAdapter() {
				public void keyReleased(KeyEvent e) {
					try {
						if (e.keyCode == 13) {
							value = InetAddress.getByName(inputText.getText());
							value.getHostAddress();
							// System.out.println(value.getHostAddress());
							// value.getHostAddress();

							shell.dispose();

						} else {
							buttonOK.setEnabled(true);
						}
					} catch (UnknownHostException ex) {

						buttonOK.setEnabled(false);
					}
				}

			});
			// text.addListener(SWT.Modify, new Listener() {
			// public void handleEvent(Event event) {
			// try {
			// value = InetAddress.getByName(text.getText());
			// value.getHostAddress();
			// buttonOK.setEnabled(true);
			// } catch (Exception e) {
			// buttonOK.setEnabled(false);
			// }
			// }
			// });

			buttonOK.addListener(SWT.Selection, new Listener() {
				public void handleEvent(Event event) {
					try {

						value = InetAddress.getByName(inputText.getText());
						System.out.println(value.getHostAddress());
						// value.getHostAddress();

						shell.dispose();

					} catch (UnknownHostException ex) {

						buttonOK.setEnabled(false);
					}

				}
			});

			buttonCancel.addListener(SWT.Selection, new Listener() {
				public void handleEvent(Event event) {
					value = null;
					shell.dispose();
				}
			});

			shell.addListener(SWT.Traverse, new Listener() {
				public void handleEvent(Event event) {
					if (event.detail == SWT.TRAVERSE_ESCAPE)
						event.doit = false;
				}
			});

			// inputText.setText("");
			shell.pack();
			shell.open();

			Display display = parent.getDisplay();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}

			return value;
		}

		public void setDefaultHost(String host) {
			this.defaultHost = host;
		}

		public void setText(String text) {
			this.text = text;
		}

		public void setTitle(String title) {
			this.title = title;
		}
	}

	private class NumberedIpInputDialog extends Dialog {
		private String title = "";

		private InetAddress[] value;

		private Text baseHostText;
		private Text fromNumText;
		private Text toNumText;
		private Text domainText;
		private Text previewText;

		private KeyAdapter textPreviewListener;
		private ArrayList<String> hosts;

		/**
		 * @param parent
		 */
		public NumberedIpInputDialog(Shell parent) {
			super(parent);
		}

		/**
		 * @param parent
		 * @param style
		 */
		public NumberedIpInputDialog(Shell parent, int style) {
			super(parent, style);
		}

		/**
		 * Makes the dialog visible.
		 * 
		 * @return
		 */
		public InetAddress[] open() {
			Shell parent = getParent();
			final Shell shell = new Shell(parent, SWT.TITLE | SWT.BORDER
					| SWT.APPLICATION_MODAL);
			shell.setText(title);

			shell.setLayout(new GridLayout(1, true));

			GridData makeWide = new GridData();
			makeWide.horizontalAlignment = SWT.FILL;
			GridData makeBig = new GridData();
			makeBig.horizontalAlignment = SWT.FILL;
			makeBig.verticalAlignment = SWT.FILL;

			Composite com = new Composite(shell, SWT.NULL);
			// com.setLayoutData(makeWide);
			com.setLayout(new GridLayout(8, false));
			Label label = new Label(com, SWT.NULL);
			label.setText("Hostname:");

			baseHostText = new Text(com, SWT.SINGLE | SWT.BORDER);
			baseHostText.setLayoutData(makeWide);
			baseHostText.setSize(50, 20);
			baseHostText.setText("node");

			label = new Label(com, SWT.NULL);
			label.setText("from #:");

			fromNumText = new Text(com, SWT.SINGLE | SWT.BORDER);
			fromNumText.setSize(40, 20);
			fromNumText.setText("00");

			label = new Label(com, SWT.NULL);
			label.setText("to #:");

			toNumText = new Text(com, SWT.SINGLE | SWT.BORDER);
			toNumText.setSize(40, 20);
			toNumText.setText("01");

			label = new Label(com, SWT.NULL);
			label.setText("");

			domainText = new Text(com, SWT.SINGLE | SWT.BORDER);
			domainText.setLayoutData(makeWide);
			domainText.setSize(100, 20);
			domainText.setText(".proj.group.emulab.net");

			Label l = new Label(shell, SWT.NONE);
			l.setText("Preview:");
			previewText = new Text(shell, SWT.MULTI | SWT.BORDER | SWT.V_SCROLL
					| SWT.READ_ONLY);
			previewText.setSize(200, 200);
			previewText.setEditable(false);
			previewText.setLayoutData(makeBig);
			// new Label(shell, SWT.NONE);

			// inputText.setLayoutData(layoutData)
			Composite com2 = new Composite(shell, SWT.NULL);
			com2.setLayout(new FillLayout(SWT.HORIZONTAL));
			// com2.setLayoutData(makeWide);
			final Button buttonOK = new Button(com2, SWT.PUSH);
			buttonOK.setText("Ok");
			Button buttonCancel = new Button(com2, SWT.PUSH);
			buttonCancel.setText("Cancel");

			buttonOK.addListener(SWT.Selection, new Listener() {
				public void handleEvent(Event event) {
					try {

						value = new InetAddress[hosts.size()];
						for (int i = 0; i < hosts.size(); i++) {
							value[i] = InetAddress.getByName(hosts.get(i));
							System.out.println(value[i].getHostAddress());
						}
						shell.dispose();

					} catch (UnknownHostException ex) {

						previewText.setText("unknown host error: " + ex.getMessage());
					}

				}
			});

			buttonCancel.addListener(SWT.Selection, new Listener() {
				public void handleEvent(Event event) {
					value = null;
					shell.dispose();
				}
			});

			shell.addListener(SWT.Traverse, new Listener() {
				public void handleEvent(Event event) {
					if (event.detail == SWT.TRAVERSE_ESCAPE)
						event.doit = false;
				}
			});

			textPreviewListener = new KeyAdapter() {
				public void keyReleased(KeyEvent e) {
					updatePreviewText();
				}

			};

			baseHostText.addKeyListener(textPreviewListener);
			fromNumText.addKeyListener(textPreviewListener);
			toNumText.addKeyListener(textPreviewListener);
			domainText.addKeyListener(textPreviewListener);

			updatePreviewText();
			// inputText.setText("");
			shell.pack();
			shell.open();

			Display display = parent.getDisplay();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}

			return value;
		}

		private void updatePreviewText() {
			try {
				hosts = new ArrayList<String>();
				String baseHost = baseHostText.getText();
				int fromNum = Integer.parseInt(fromNumText.getText());
				int toNum = Integer.parseInt(toNumText.getText());
				String baseDomain = domainText.getText();

				StringBuilder b = new StringBuilder();
				for (int i = fromNum; i <= toNum; i++) {
					String hostname = baseHost + i + baseDomain;
					hosts.add(hostname);
					b.append(hostname + "\n");
				}
				for (int i = hosts.size(); i < 10; i++) {
					b.append("\n");
				}

				previewText.setText(b.toString());
			} catch (NumberFormatException e) {
				previewText.setText("invalid");
			}
		}

		public void setTitle(String title) {
			this.title = title;
		}
	}

}
