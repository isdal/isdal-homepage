package edu.washington.cs.pl_if;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

import com.twmacinta.util.MD5;

import edu.washington.cs.pl_if.gui.GuiMain;
import edu.washington.cs.pl_if.rpc.server.RpcServer;

public class Main {

	private static final Main instance = new Main();

	private static final int DEFAULT_CONCURRENT_COPY_LIMIT = 20;

	private static String remoteMD5 = null;

	private static double downloadProgress = 0;

	public static double getDownloadProgress() {
		return downloadProgress;
	}

	private static Map<String, String> config;

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// fix the annoying leopard no classloader bug
		// http://lists.apple.com/archives/Java-dev/2008/Feb/msg00179.html
		if (System.getProperty("os.name").contains("Mac OS X")
				&& System.getProperty("os.version").contains("10.5")) {
			ClassLoader scl = ClassLoader.getSystemClassLoader();
			Thread t = Thread.currentThread();
			ClassLoader cl = t.getContextClassLoader();
			if (cl == null) {
				t.setContextClassLoader(scl);
			}
		}

		// TODO Auto-generated method stub
		String configFile = "pl_manager.conf";
		Map<String, String> argMap = parseArgs(args);
		try {

			if (argMap.containsKey("config")) {
				configFile = argMap.get("config");
			}
			System.out.println(configFile);

			// Set the security credentials and start the rpc server
			Credentials cred;
			// read the config file
			Map<String, String> config = getConfigFromFile(configFile);
			// prompt the user if prompt stuff is specfied
			prompt(config);

			cred = new Credentials(config);
			System.out.println(cred.toString());

			handleHttpProxy();

			//System.err.println("starting controller");
			RpcServer.getInstance().startController(cred);
			//System.err.println("started controller");
			setConcurrentCopyLimit(config);

			// start gui
			// System.out.println("start gui");
			if (argMap.containsKey("gui")) {
				// Start the gui
				GuiMain.getInstance(cred, InetAddress.getLocalHost());
			}
			// listThreads();
			// PrintStream p = new PrintStream("err.log");
			// System.setErr(p);

		} catch (IOException e) {
			System.out.println("config file (" + configFile
					+ ") not found, use --config <path>");
		}
		
		// this is to fix the strange os x swt crap
		if (System.getProperty("os.name").contains("Mac OS X")
				&& System.getProperty("os.version").contains("10.5")) {
			while(GuiMain.running){
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	private static void handleHttpProxy() {
		if (Main.getConfig(Constants.HTTP_PROXY_HOST) != null
				&& Main.getConfig(Constants.HTTP_PROXY_PORT) != null) {
			int port = Integer.parseInt(Main
					.getConfig(Constants.HTTP_PROXY_PORT));
			String hostname = Main.getConfig(Constants.HTTP_PROXY_HOST);
			String username = Main.getConfig(Constants.HTTP_PROXY_USERNAME);
			// String password =
			// Base64.encode(Main.getConfig(Constants.HTTP_PROXY_PASSWORD).getBytes());
			String password = Main.getConfig(Constants.HTTP_PROXY_PASSWORD);

			// don't use the proxy for local host
			System.getProperties().setProperty("http.nonProxyHosts",
					"localhost|127.0.0.1");

			// if username AND password is specified
			if (username != null && password != null) {

				// set the proxy properties
				System.getProperties().setProperty("http.proxySet", "true");
				System.getProperties().setProperty("http.proxyHost ", hostname);
				System.getProperties()
						.setProperty("http.proxyPort ", "" + port);

				System.getProperties().setProperty("http.proxyUser ", username);
				System.getProperties().setProperty("http.proxyPassword",
						password);

				// and for https
				System.getProperties().setProperty("https.proxySet", "true");
				System.getProperties()
						.setProperty("https.proxyHost ", hostname);
				System.getProperties().setProperty("https.proxyPort ",
						"" + port);

				System.getProperties()
						.setProperty("https.proxyUser ", username);
				System.getProperties().setProperty("https.proxyPassword",
						password);

				System.out
						.println("xml rpc connect with http proxy and auth, host="
								+ hostname
								+ " port="
								+ port
								+ "user="
								+ username);
			} else {
				// ok, only hostname and port
				System.getProperties().setProperty("http.proxySet", "true");
				System.getProperties().setProperty("http.proxyHost ", hostname);
				System.getProperties()
						.setProperty("http.proxyPort ", "" + port);

				// and for https
				System.getProperties().setProperty("https.proxySet", "true");
				System.getProperties()
						.setProperty("https.proxyHost ", hostname);
				System.getProperties().setProperty("https.proxyPort ",
						"" + port);

				System.out.println("xml rpc connect with http proxy, host="
						+ hostname + " port=" + port);
			}
		}
	}

	private static void setConcurrentCopyLimit(Map<String, String> config) {
		// check if we should change the number of concurrent copy threads
		if (config.containsKey("ConcurrentCopyLimit")) {
			String value = "";
			try {
				value = config.get("ConcurrentCopyLimit");
				int newLimit = Integer.parseInt(value);
				RpcServer.getInstance().increaseConcurrentCopyLimit(newLimit);
			} catch (NumberFormatException e) {
				System.out.println("ConcurrentCopyLimit: parse error value='"
						+ value + "'");
				RpcServer.getInstance().increaseConcurrentCopyLimit(
						DEFAULT_CONCURRENT_COPY_LIMIT);
			}
		} else {
			RpcServer.getInstance().increaseConcurrentCopyLimit(
					DEFAULT_CONCURRENT_COPY_LIMIT);
		}
	}

	/**
	 * Create a map of the command line arguments
	 * 
	 * @param args
	 *            the command line arguments
	 * @return Map of the command line arguments
	 */

	public static Map<String, String> parseArgs(String[] args) {
		HashMap<String, String> map = new HashMap<String, String>();

		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("--config")) {
				if (i + 1 < args.length) {
					map.put("config", args[i + 1]);
					i++;
				}
			} else if (args[i].equals("--with-gui")) {
				map.put("gui", "true");
			}
		}
		return map;
	}

	/**
	 * Reads config from config file
	 * 
	 * @param configFile
	 * @return Credentials class with the specified credentials
	 * @throws IOException
	 */

	public static Map<String, String> getConfigFromFile(String configFile)
			throws IOException {
		if (config == null) {
			HashMap<String, String> map = new HashMap<String, String>();

			BufferedReader conf = new BufferedReader(new FileReader(configFile));
			String line = conf.readLine();
			while (line != null) {
				if (!line.startsWith("#") && line.indexOf("=") > 0) {
					String[] split = line.split("=");
					String key = split[0];
					String value = line.substring(line.indexOf("=") + 1);
					if (null == value) {
						value = "";
					}

					map.put(key, value);
				}
				line = conf.readLine();

			}

			config = map;
		}
		return config;

	}

	public static String getConfig(String key) {
		return config.get(key);
	}

	public static void listThreads() {
		// Find the root thread group
		ThreadGroup root = Thread.currentThread().getThreadGroup().getParent();
		while (root.getParent() != null) {
			root = root.getParent();
		}

		// Visit each thread group
		visit(root, 0);
	}

	// This method recursively visits all thread groups under `group'.
	public static void visit(ThreadGroup group, int level) {
		// Get threads in `group'
		int numThreads = group.activeCount();
		Thread[] threads = new Thread[numThreads * 2];
		numThreads = group.enumerate(threads, false);

		// Enumerate each thread in `group'
		for (int i = 0; i < numThreads; i++) {
			// Get thread
			Thread thread = threads[i];
			System.out.println(thread.toString());
		}

		// Get thread subgroups of `group'
		int numGroups = group.activeGroupCount();
		ThreadGroup[] groups = new ThreadGroup[numGroups * 2];
		numGroups = group.enumerate(groups, false);

		// Recursively visit each subgroup
		for (int i = 0; i < numGroups; i++) {
			visit(groups[i], level + 1);
		}

	}

	public static void prompt(Map<String, String> config) throws IOException {
		// BufferedReader input = new BufferedReader(new InputStreamReader(
		// System.in));
		for (String key : config.keySet()) {
			if (config.get(key).equals("prompt")) {
				String text = ("Please supply the value for '" + key + "'");
				String password = readPassword(text);

				config.put(key, password);
			}
		}

	}

	public static String readPassword(String prompt) {
		EraserThread et = instance.new EraserThread(prompt);
		Thread mask = new Thread(et);
		mask.start();

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String password = "";

		try {
			password = in.readLine();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		// stop masking
		et.stopMasking();
		// return the password entered by the user
		return password;
	}

	public static boolean update() {
		String jarUrl = "http://www.cs.washington.edu/homes/isdal/plman/PlMan.jar";
		try {
			URLConnection conn = new URL(jarUrl).openConnection();
			int available = conn.getContentLength();
			byte[] byteBuffer = new byte[available];
			InputStream in = conn.getInputStream();
			int totalRead = 0;
			int currRead = in.read(byteBuffer, 0, available);
			totalRead += currRead;
			while (totalRead < available && currRead > -1) {
				currRead = in
						.read(byteBuffer, totalRead, available - totalRead);
				totalRead += currRead;
				double done = Math.round(((double) totalRead
						/ (double) available * 100.0));
				System.out.println("downloading update: " + done + "% done");
			}
			if (totalRead == available) {
				String remoteMd5 = getRemoteMD5();
				MD5 md5 = new MD5();
				md5.Update(byteBuffer);
				String downMd5 = md5.asHex();
				// System.out.println("downl_: " + downMd5);
				if (remoteMd5.equals(downMd5)) {
					System.out.println("md5 check of download successful");

					FileOutputStream newFile = (new FileOutputStream(
							"PlMan.jar"));
					newFile.write(byteBuffer);
					newFile.close();
					System.out.println("Update successful");

					return true;
				} else {
					System.out.println("md5 check of download failed");
				}
			} else {
				System.out.println("aborted after " + totalRead + " of "
						+ available + " bytes");
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	private static String getRemoteMD5() throws MalformedURLException,
			IOException {
		if (remoteMD5 == null) {
			String md5Url = "http://www.cs.washington.edu/homes/isdal/plman/PlMan.jar.md5";
			remoteMD5 = (String) new BufferedReader(new InputStreamReader(
					new URL(md5Url).openStream())).readLine();
		}

		return remoteMD5;
	}

	public static boolean checkForUpdates() {
		boolean newVersion = false;
		try {
			String remoteMd5 = getRemoteMD5();

			System.out.println("remote: " + remoteMd5);

			String localMd5 = MD5.asHex(MD5.getHash(new File("PlMan.jar")));
			System.out.println("local_: " + localMd5);
			newVersion = !localMd5.equals(remoteMd5);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return newVersion;
	}

	private class EraserThread implements Runnable {
		private boolean stop;

		/**
		 * @param The
		 *            prompt displayed to the user
		 */
		public EraserThread(String prompt) {
			System.out.println(prompt);
			// System.out.print("");
		}

		/**
		 * Begin masking...display asterisks (*)
		 */
		public void run() {
			stop = true;
			while (stop) {

				try {
					Thread.sleep(1);
				} catch (InterruptedException ie) {
					ie.printStackTrace();
				}
				System.out.print("\010 ");
			}
		}

		/**
		 * Instruct the thread to stop masking
		 */
		public void stopMasking() {
			this.stop = false;
		}
	}

}
