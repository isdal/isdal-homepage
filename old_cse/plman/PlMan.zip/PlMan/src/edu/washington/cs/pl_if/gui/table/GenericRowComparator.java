package edu.washington.cs.pl_if.gui.table;

public class GenericRowComparator<Type extends TableRow> implements
		RowComparator<Type> {

	private int column;

	private int direction;

	public GenericRowComparator() {

	}

	public int compare(Type r1, Type r2) {
		// System.out.println("generic compare");
		int rc = 0;

		String[] row1 = r1.toStringArray();
		String[] row2 = r2.toStringArray();
		if (column >= 0 && column < row1.length) {
			// System.out.println(row1[column] + ":" + row2[column]);
			rc = row1[column].toLowerCase().compareTo(
					row2[column].toLowerCase());
		}

		if (direction == RowComparator.DESCENDING) {
			rc = -rc;
		}
		return rc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.RowComparator#reverseDirection()
	 */
	public void reverseDirection() {
		direction = 1 - direction;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.RowComparator#setColumn(int)
	 */
	public void setColumn(int column) {
		this.column = column;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.RowComparator#setDirection(int)
	 */
	public void setDirection(int direction) {
		this.direction = direction;
	}
}