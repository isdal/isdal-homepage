package edu.washington.cs.pl_if.gui;


import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Text;

import swing2swt.layout.BorderLayout;
import edu.washington.cs.pl_if.gui.table.DataTable;
import edu.washington.cs.pl_if.gui.table.command.CommandRowComparator;
import edu.washington.cs.pl_if.gui.table.command.CommandTableRow;
import edu.washington.cs.pl_if.gui.table.command.CommandTableUpdateThread;
import edu.washington.cs.pl_if.gui.table.host.HostRowComparator;
import edu.washington.cs.pl_if.gui.table.host.HostTableRow;
import edu.washington.cs.pl_if.gui.table.host.HostTableUpdateThread;
import edu.washington.cs.pl_if.rpc.client.RpcClient;

public class GuiHostOverview extends Composite implements RequiresUpdates {

	private static final long MAX_UPLOAD_RATE = 100;

	private long lastUpdate = 0;

	private String typedCommand;

	private int currentCommandIndex = 1;

	private Text text;

	private DataTable<CommandTableRow> guiCommandStatus;

	// private GuiHostStatus guiHostStatus;
	private DataTable<HostTableRow> guiHostStatus;

	/**
	 * Create the composite
	 * 
	 * @param parent
	 * @param style
	 */
	public GuiHostOverview(Composite parent, int style) {
		super(parent, style);

		createComposite();
		//
	}

	@Override
	public void dispose() {
		super.dispose();
	}

	public int getSelectedHostIndex() {
		if (guiHostStatus.getSelectedIds().length > 0) {
			return guiHostStatus.getSelectedIds()[0];
		} else {
			return -1;
		}
	}

	public int getSelectedCommandIndex() {
		if (guiCommandStatus.getSelectedIds().length > 0) {
			return guiCommandStatus.getSelectedIds()[0];
		} else {
			return -1;
		}
	}

	public void updateGui() {
		this.lastUpdate = System.currentTimeMillis();
		RequiresUpdates[] elements = new RequiresUpdates[] { guiCommandStatus,
				guiHostStatus };
		for (int i = 0; i < elements.length; i++) {
			RequiresUpdates element = elements[i];
			if (element.isVisible() && element.shouldUpdate()) {
				element.updateGui();
			}
		}
	}

	private void createComposite() {
		setLayout(new BorderLayout(0, 0));

		final SashForm sashForm = new SashForm(this, SWT.NONE);

		createTableHost(sashForm);

		createTableCommand(sashForm);
		sashForm.setOrientation(SWT.VERTICAL);
		sashForm.setLayoutData(BorderLayout.CENTER);

		sashForm.setWeights(new int[] { 3, 1 });

		final Composite composite = new Composite(this, SWT.NONE);
		composite.setLayout(new BorderLayout(0, 0));
		composite.setLayoutData(BorderLayout.SOUTH);

		text = new Text(composite, SWT.BORDER);
		text.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				// check to return key

				synchronized (text) {
					String oldText = text.getText();
					if (13 == e.keyCode) {
						// System.out.println("new line: " + text.getText());
						RpcClient.getInstance().queueCommand(text.getText());
						text.setText("");
						updateGui();

						currentCommandIndex = RpcClient.getInstance()
								.totalCommandNum();
					} else if (SWT.ARROW_UP == e.keyCode) {
						if (oldText != null) {
							text.setText(handleUpArrow(oldText));
						}
					} else if (SWT.ARROW_DOWN == e.keyCode) {
						if (oldText != null) {
							String newText = handleDownArrow(oldText);
							if (newText != null) {
								text.setText(newText);
							}
						}
					}
				}
			}
		});
		text.setLayoutData(BorderLayout.CENTER);

		final Button executeButton = new Button(composite, SWT.NONE);
		executeButton.addMouseListener(new MouseAdapter() {
			public void mouseUp(MouseEvent arg0) {
				RpcClient.getInstance().queueCommand(text.getText());
				updateGui();
				text.setText("");
			}
		});
		executeButton.setText("Execute");
		executeButton.setLayoutData(BorderLayout.EAST);

		// final int num = 10;
		// final Button addButton = new Button(composite, SWT.NONE);
		// addButton.addMouseListener(new MouseAdapter() {
		// public void mouseUp(MouseEvent arg0) {
		// RpcClient.getInstance().addRandomSitesFromPLC(num);
		// }
		// });
		// addButton.setText("Add " + num + " sites");
		// addButton.setLayoutData(BorderLayout.EAST);
	}

	private void createTableCommand(final SashForm sashForm) {
		final String[] columns = { "#", "Command", "Exit status",
				"Completed hosts" };
		final int[] columnWidths = { 30, 200, 100, 50 };
		final int growColNum = 3;
		final int updateRate = 500;
		final int progressBarPos = 3;

		guiCommandStatus = new DataTable<CommandTableRow>(sashForm, SWT.SINGLE,
				columns, columnWidths, new CommandRowComparator());

		guiCommandStatus.setRowDoubleClickedListener(new Listener() {
			public void handleEvent(Event event) {
				int index = getSelectedCommandIndex();
				if (index >= 0) {
					GuiMain.getInstance().addCommandTab(
							getSelectedCommandIndex());
				}
			}
		});

		Menu menu = new Menu(this.getShell(), SWT.POP_UP);
		// System.out.println("adding menu to command table");
		guiCommandStatus.addMenu(menu);
		MenuItem item = new MenuItem(menu, SWT.PUSH);
		item.setText("kill command");
		item.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				int commandId = getSelectedCommandIndex();
				RpcClient.getInstance().kill(commandId);
			}
		});

		guiCommandStatus.setResizePolicy(growColNum);

		guiCommandStatus.setProgressBarCol(progressBarPos);
		guiCommandStatus.setUpdateThread(new CommandTableUpdateThread(
				guiCommandStatus, updateRate), "command_status");
		guiCommandStatus.setLayoutData(BorderLayout.CENTER);
	}

	private void createTableHost(final SashForm sashForm) {
		final String[] columns = { "Site", "Hostname", "Exec command",
				"Exit status", "Time", "Progress", "Last line" };
		final int[] columnWidths = { 100, 200, 100, 75, 50, 75, 50 };
		final int growColNum = 6;
		final int updateRate = 1000;
		final int progressBarPos = 5;
		guiHostStatus = new DataTable<HostTableRow>(sashForm, SWT.SINGLE,
				columns, columnWidths, new HostRowComparator());

		guiHostStatus.setRowDoubleClickedListener(new Listener() {
			public void handleEvent(Event event) {
				int index = getSelectedHostIndex();
				if (index >= 0) {
					GuiMain.getInstance().addShowTab(index);
				}
			}
		});

		guiHostStatus.setResizePolicy(growColNum);

		guiHostStatus.setProgressBarCol(progressBarPos);
		guiHostStatus.setUpdateThread(new HostTableUpdateThread(guiHostStatus,
				updateRate), "host_status");
		guiHostStatus.setLayoutData(BorderLayout.CENTER);
	}

	private String handleDownArrow(String currentText) {
		int totalCommandNum = RpcClient.getInstance().totalCommandNum();

		// check if we were standing on or below the currently inputed (but not
		// executed) row, save it and return an empty row
		if (currentCommandIndex >= totalCommandNum) {
			// if nothing is typed, no reason to save it... or to go down
			if (currentText.equals("")) {
				return "";
			} else {
				// ok, save this (overwriting the previous if any)
				typedCommand = currentText;
				// and move down one
				currentCommandIndex = totalCommandNum + 1;
				// return an empty row
				return "";
			}
		}
		if (currentCommandIndex + 1 < totalCommandNum) {
			// System.out.println(currentCommandIndex + ":" + totalCommandNum);
			// if there are any later commands
			String nextCommand = RpcClient.getInstance().getCommand(
					currentCommandIndex + 1);
			currentCommandIndex++;
			if (nextCommand != null) {
				return nextCommand;
			}
			return "";
		}
		currentCommandIndex++;
		return typedCommand;
	}

	// handle up arrow pressed events
	private String handleUpArrow(String currentText) {
		int totalCommandNum = RpcClient.getInstance().totalCommandNum();

		// we are "below" the current command, going up
		if (currentCommandIndex > totalCommandNum) {
			currentCommandIndex = totalCommandNum;
			// return the saved command
			return typedCommand;

		}
		// check if we were standing on the currently inputed (but executed)
		// row
		if (currentCommandIndex == totalCommandNum) {
			// save the current command for future use
			typedCommand = currentText;

		}
		// If there are previous commands
		if (currentCommandIndex > 0) {
			// fecth the command
			String prevCommand = RpcClient.getInstance().getCommand(
					currentCommandIndex - 1);
			// decrement current command
			currentCommandIndex--;
			return prevCommand;
		}

		// we are at the top, stop here
		return currentText;
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	public boolean shouldUpdate() {
		return System.currentTimeMillis() > lastUpdate + MAX_UPLOAD_RATE;

	}

}
