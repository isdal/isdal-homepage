package edu.washington.cs.pl_if.gui.table.host;

import edu.washington.cs.pl_if.gui.table.GenericRowComparator;
import edu.washington.cs.pl_if.gui.table.RowComparator;

/**
 * This class does the comparisons for sorting Host row objects.
 */
public class HostRowComparator implements RowComparator<HostTableRow> {

	private int column;

	private int direction;

	private RowComparator<HostTableRow> genericComparator = new GenericRowComparator<HostTableRow>();

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#compare(edu.washington.cs.pl_if.gui.table.host.HostTableRow,
	 *      edu.washington.cs.pl_if.gui.table.host.HostTableRow)
	 */
	public int compare(HostTableRow r1, HostTableRow r2) {
		int rc = 0;
		final int RUNTIME = 4;
		final int PROGRESS = 5;
		// Determine which field to sort on, then sort
		// on that field
		switch (column) {
		case RUNTIME:
			Double d1 = r1.getTime();
			Double d2 = r2.getTime();
			rc = d1.compareTo(d2);
			break;
		case PROGRESS:
			d1 = r1.getProgress();
			d2 = r2.getProgress();
			rc = d1.compareTo(d2);
			break;
		default:
			return genericComparator.compare(r1, r2);
		}

		// Check the direction for sort and flip the sign
		// if appropriate
		if (direction == DESCENDING) {
			rc = -rc;
		}
		return rc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#reverseDirection()
	 */
	public void reverseDirection() {
		direction = 1 - direction;
		genericComparator.setDirection(direction);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#setColumn(int)
	 */
	public void setColumn(int column) {
		this.column = column;
		genericComparator.setColumn(column);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#setDirection(int)
	 */
	public void setDirection(int direction) {
		this.direction = direction;
		genericComparator.setDirection(direction);
	}
}