package edu.washington.cs.pl_if.gui.table.command;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

import edu.washington.cs.pl_if.gui.table.TableRow;

public class CommandTableRow implements TableRow {

	private int commandId;

	private String command;

	private String exitCodes;

	private double progress;

	@SuppressWarnings("unchecked")
	public CommandTableRow(Map map, int commandId) {
		this.commandId = commandId;
		this.command = (String) map.get("command");

		this.exitCodes = exitCodesToString((Map) map.get("exit_code_counts"));

		this.progress = (Double) map.get("percent_completed");
	}

	private String exitCodesToString(Map<Integer, Integer> codeCounts) {
		StringBuffer buf = new StringBuffer();

		ArrayList<Integer> keys = new ArrayList<Integer>(codeCounts.keySet());

		// sort the list (so the exit codes show up in increasing order
		Collections.sort(keys);

		for (int i = 0; i < keys.size(); i++) {

			buf.append(keys.get(i) + ":" + codeCounts.get(keys.get(i)) + ", ");

		}
		return buf.toString();
	}

	public int getRowId() {
		return this.getCommandId();
	}

	public boolean isVisible() {
		return true;
	}

	public String[] toStringArray() {
		String[] ret = { "" + commandId, command, exitCodes, "" + progress };

		return ret;
	}

	public String getCommand() {
		return command;
	}

	public int getCommandId() {
		return commandId;
	}

	public String getExitCodes() {
		return exitCodes;
	}

	public double getProgress() {
		return progress;
	}

	public boolean isChecked() {
		return false;
	}

	public void setChecked(boolean checked) {
		// TODO Auto-generated method stub
		
	}

}
