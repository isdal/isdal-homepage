package edu.washington.cs.pl_if.plc.comon;

import java.util.Map;

import edu.washington.cs.pl_if.plc.PLCentralController;

public class CoMonStat {

	private Map<String, String> data;

	public CoMonStat() {

	}

	public CoMonStat(Map<String, String> map) {
		this.data = map;
	}

	public String getHostname() {
		return data.get(CoMonManager.HOSTNAME);
	}

	public double getResponseTime() {
		String s = data.get(CoMonManager.RESPTIME);
		double d = this.parseDouble(s);

		// looks like comon marks querytime as 0 if failing
		if (d == 0) {
			return Double.NaN;
		}
		return d;
	}

	public double getLoadAverage() {
		String s = data.get(CoMonManager.LOAD_AVERAGE_5);
		return this.parseDouble(s);
	}

	public double getMemFree() {
		String s = data.get(CoMonManager.MEM_FREE);
		return this.parseDouble(s);
	}

	public double getMemTotal() {
		String s = data.get(CoMonManager.MEM_TOTAL);
		return this.parseDouble(s);
	}

	private double parseDouble(String string) {

		try {
			if (string != null) {
				double resptime = Double.parseDouble(string);
				return resptime;
			}
		} catch (NumberFormatException e) {
			// ignore, there was an error
			// System.err.println("comon: " + this.hostname
			// + " parse error double: '" + string + "'");
		}
		return Double.NaN;
	}
}
