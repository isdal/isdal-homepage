package edu.washington.cs.pl_if.gui;

public interface RequiresUpdates {
	public void updateGui();

	public boolean isVisible();

	public boolean shouldUpdate();
}
