package edu.washington.cs.pl_if.gui.table;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import swing2swt.layout.BorderLayout;
import edu.washington.cs.pl_if.gui.GuiMain;
import edu.washington.cs.pl_if.gui.RequiresUpdates;

public class DataTable<T extends TableRow> extends Composite implements
		RequiresUpdates {

	public static final int PROGRESS_BAR_LENGTH = 10000;

	private HashMap<Integer, Boolean> checks = new HashMap<Integer, Boolean>();

	private final String[] columns;

	private final int[] columnWidth;

	private final RowComparator<T> comparator;

	private long lastRefresh;

	private int progressBarPos = -1;

	private int checkBoxPos = -1;

	private Vector<ProgressBar> progressBars = new Vector<ProgressBar>();;

	private Vector<Button> checkBoxes = new Vector<Button>();

	private Menu rightClickMenu;

	private Listener rowSelectedListener;

	private Table table;

	private List<T> tableData = new Vector<T>();

	private UpdateThread updateThread;

	private static int style;

	/**
	 * Create the composite
	 * 
	 * @param parent
	 * @param style
	 */
	// public DataTable(Composite parent, int style, String[] columnHeaders,
	// int[] columnWidths) {
	// this(parent, style, columnHeaders, columnWidths, null);
	// }
	public DataTable(Composite parent, int style, String[] columnHeaders,
			int[] columnWidths, RowComparator<T> comp) {
		super(parent, style);
		this.columns = columnHeaders;
		this.columnWidth = columnWidths;
		// this.parent = parent;
		if (comp != null) {
			this.comparator = comp;
		} else {
			this.comparator = new GenericRowComparator<T>();
		}
		this.lastRefresh = System.currentTimeMillis();
		this.style = style;
		this.open();

	}

	public void addMenu(Menu menu) {
		this.rightClickMenu = menu;
		this.table.setMenu(this.rightClickMenu);
		// System.out.println("added menu");
	}

	@Override
	public void dispose() {
		this.updateThread.halt();
		super.dispose();
	}

	public int[] getSelectedIds() {
		synchronized (table) {
			TableItem[] items = table.getSelection();
			int[] selectedRows = new int[items.length];
			for (int i = 0; i < items.length; i++) {

				Integer connId = (Integer) items[i].getData("row_id");
				if (connId != null) {
					selectedRows[i] = connId;
				} else {
					selectedRows[i] = -1;
				}
			}
			return selectedRows;
		}
	}

	public T getTableData(int rowId) {
		synchronized (tableData) {
			for (int i = 0; i < tableData.size(); i++) {
				T tableRow = tableData.get(i);
				if (tableRow.getRowId() == rowId) {
					return tableRow;
				}
			}
		}
		return null;
	}

	public Integer[] getCheckedIds() {
		ArrayList<Integer> checked = new ArrayList<Integer>();

		for (Iterator iter = checks.keySet().iterator(); iter.hasNext();) {
			Integer id = (Integer) iter.next();
			if (checks.get(id)) {
				checked.add(id);
			}
		}

		return checked.toArray(new Integer[checked.size()]);
	}

	/**
	 * tries to figure out if we are visible, but allows other threads to query.
	 * We are visible if we are updating frequently
	 * 
	 */
	public boolean isCurrentlyVisible() {
		if (System.currentTimeMillis() - lastRefresh > 2 * GuiMain.OVERVIEW_UPDATE_LIMIT) {
			return false;
		}
		return true;
	}

	public void setProgressBarCol(int col) {
		this.progressBarPos = col;

	}

	public void setCheckBoxCol(int col) {
		this.checkBoxPos = col;

	}

	public void toggleChecked(int id) {
		if (!checks.containsKey(id)) {
			checks.put(id, true);
		} else {
			checks.put(id, !checks.get(id));
		}

		for (T item : tableData) {
			if (item.getRowId() == id) {
				item.setChecked(checks.get(id));
			}
		}
		this.updateGui();
	}

	public List<T> getAllRows() {
		return tableData;
	}

	public void setResizePolicy(int colNum) {
		TableResizeControlAdapter tableColumnResizer = new TableResizeControlAdapter(
				this, table, colNum);
		table.addControlListener(tableColumnResizer);
	}

	public void setRowDoubleClickedListener(Listener listener) {
		this.rowSelectedListener = listener;
		table.addListener(SWT.MouseDoubleClick, rowSelectedListener);
		for (ProgressBar bar : progressBars) {
			bar.dispose();
			bar.addListener(SWT.MouseDoubleClick, listener);
		}
	}

	public void setMouseListener(MouseListener listener) {
		table.addMouseListener(listener);
		for (ProgressBar bar : progressBars) {
			bar.dispose();
			bar.addMouseListener(listener);
		}
	}

	public void setKeyListener(KeyAdapter listener) {
		table.addKeyListener(listener);
	}

	public void setTableData(List<T> newData) {
		this.sortTableData(newData);
		synchronized (tableData) {
			this.tableData = newData;
		}

	}

	public void setUpdateThread(UpdateThread updateThread, String name) {
		if (this.updateThread == null) {
			this.updateThread = updateThread;
			Thread t = new Thread(updateThread);
			t.setPriority(Thread.NORM_PRIORITY - 2);
			t.setName("TableUpdater-" + name);
			t.setDaemon(true);
			t.start();
		}
	}

	public void sortTableData(List<T> data) {
		Collections.sort(data, comparator);
	}

	public boolean isChecked(int rowId) {
		if (checks.containsKey(rowId)) {
			return checks.get(rowId);
		}
		return false;
	}

	public void updateGui() {
		if (!table.isDisposed()) {
			table.getDisplay().asyncExec(new Runnable() {
				public void run() {
					updateTable();
					lastRefresh = System.currentTimeMillis();
				}
			});
		}
	}

	private void addProgressBar(final TableItem item) {
		if (progressBarPos >= 0) {
			ProgressBar bar = new ProgressBar(table, SWT.SMOOTH);
			bar.setMinimum(0);
			bar.setMaximum(PROGRESS_BAR_LENGTH);
			bar.setSelection(0);
			// Store bar for later updates
			progressBars.add(bar);

			TableEditor editor = new TableEditor(table);
			editor.grabHorizontal = editor.grabVertical = true;
			editor.setEditor(bar, item, this.progressBarPos);
			bar.addListener(SWT.MouseDown, new Listener() {
				public void handleEvent(Event event) {
					table.setSelection(item);
				}
			});
			if (rowSelectedListener != null) {
				bar.addListener(SWT.MouseDoubleClick, rowSelectedListener);
			}
		}

	}

	private void addCheckBox(final TableItem item) {
		if (checkBoxPos >= 0) {
			final Button checkButton = new Button(table, SWT.CHECK);
			checkButton.pack();
			checkBoxes.add(checkButton);

			TableEditor editor = new TableEditor(table);
			editor.minimumWidth = checkButton.getSize().x;
			editor.horizontalAlignment = SWT.CENTER;
			editor.verticalAlignment = SWT.CENTER;
			editor.setEditor(checkButton, item, this.checkBoxPos);
			checkButton.addListener(SWT.MouseUp, new Listener() {
				public void handleEvent(Event event) {
					// item.setData("checked", checkButton.getSelection());
					table.setSelection(item);
					int selectedId = getSelectedIds()[0];
					checks.put(selectedId, checkButton.getSelection());
					for (T tableRow : tableData) {
						if (tableRow.getRowId() == selectedId) {
							tableRow.setChecked(checkButton.getSelection());
						}
					}
				}
			});
		}
	}

	private void addTableRow() {
		final TableItem item = new TableItem(table, SWT.NONE);
		String[] text = new String[columns.length];
		for (int i = 0; i < text.length; i++) {
			text[i] = "";
		}
		item.setText(text);

		this.addProgressBar(item);
		this.addCheckBox(item);
	}

	private void open() {
		setLayout(new BorderLayout(0, 0));

		table = new Table(this, SWT.FULL_SELECTION | style | SWT.BORDER);

		table.setLayoutData(BorderLayout.CENTER);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);

		for (int i = 0; i < columns.length; i++) {
			String colHeader = columns[i];
			final TableColumn col = new TableColumn(table, SWT.NONE);
			col.setData("col_num", i);
			col.setWidth(columnWidth[i]);
			col.setText(colHeader);
			col.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent event) {
					int colNum = (Integer) col.getData("col_num");
					setSortCol(colNum);
					updateGui();
				}
			});
		}

		if (rowSelectedListener != null) {
			table.addListener(SWT.MouseDoubleClick, rowSelectedListener);
		}
		// System.out.println("datatable crated");
	}

	public void setSortCol(int colNum) {
		comparator.setColumn(colNum);
		comparator.reverseDirection();
		sortTableData(tableData);
	}

	private void removeAllProgressBars() {
		for (ProgressBar bar : progressBars) {
			bar.dispose();
		}
		progressBars.clear();
	}

	private void removeAllCheckBoxes() {
		for (Button checkBox : checkBoxes) {
			checkBox.dispose();
		}
		checkBoxes.clear();
	}

	private void updateTable() {
		if (!table.isDisposed()) {
			synchronized (table) {

				// handle selection
				int[] selectedItemId = this.getSelectedIds();

				// turn of drawing of the table
				table.setRedraw(false);

				// System.out.println("tabledata" + tableData.size());

				synchronized (tableData) {
					// System.out.println(tableData.size());
					boolean showDisconnected = GuiMain.getInstance()
							.isShowDisconnected();

					int tableSize = 0;
					for (TableRow row : tableData) {
						if (row.isVisible() || showDisconnected) {
							tableSize++;
						}
					}
					if (table.getItemCount() > tableSize) {
						table.removeAll();
						this.removeAllProgressBars();
					}
					while (table.getItemCount() < tableSize) {
						this.addTableRow();
					}
					// System.err.println("show: " + showDisconnected
					// + ", tablesize: " + tableSize + "/"
					// + table.getItemCount());
					int currentRow = 0;
					for (int i = 0; i < tableData.size(); i++) {

						TableRow row = tableData.get(i);

						if (row.isVisible() || showDisconnected) {
							// System.out.println(currentRow + ":" +
							// row.toString());
							table.getItem(currentRow).setText(
									row.toStringArray());
							table.getItem(currentRow).setData("row_id",
									row.getRowId());
							// if (row.getRowId() == selectedItemId) {
							// // table.setSelection(currentRow);
							// }
							if (progressBarPos >= 0) {
								ProgressBar bar = progressBars.get(currentRow);
								int prog = (int) Math
										.round(Double
												.parseDouble(row
														.toStringArray()[progressBarPos])
												* PROGRESS_BAR_LENGTH);
								bar.setSelection(prog);
							}

							if (checkBoxPos >= 0) {
								Button checkBox = checkBoxes.get(currentRow);

								if (checks.containsKey(row.getRowId())
										&& checks.get(row.getRowId())) {

									checkBox.setSelection(true);

								} else {
									checkBox.setSelection(false);
								}
							}
							currentRow++;
						}

						// System.out.println("update: " + row.getHostname());
					}
				}

				table.setRedraw(true);
			}
		}
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	public boolean shouldUpdate() {
		return true;
	}

}
