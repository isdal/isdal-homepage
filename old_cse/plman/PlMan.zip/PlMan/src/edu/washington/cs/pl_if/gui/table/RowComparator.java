package edu.washington.cs.pl_if.gui.table;

import java.util.Comparator;

public interface RowComparator<T extends TableRow> extends Comparator<T>{
	/** Constant for ascending */
	public static final int ASCENDING = 0;

	/** Constant for descending */
	public static final int DESCENDING = 1;
	
	public int compare(T r1, T r2);

	/**
	 * Reverses the direction
	 */
	public void reverseDirection();

	/**
	 * Sets the column for sorting
	 * 
	 * @param column
	 *            the column
	 */
	public void setColumn(int column);

	/**
	 * Sets the direction for sorting
	 * 
	 * @param direction
	 *            the direction
	 */
	public void setDirection(int direction);

}