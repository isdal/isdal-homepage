package edu.washington.cs.pl_if.gui.table.command;

import java.util.Map;
import java.util.Vector;

import edu.washington.cs.pl_if.gui.table.DataTable;
import edu.washington.cs.pl_if.gui.table.UpdateThread;
import edu.washington.cs.pl_if.rpc.client.RpcClient;

public class CommandTableUpdateThread implements UpdateThread<CommandTableRow> {
	private volatile boolean quit = false;

	final DataTable<CommandTableRow> parent;

	final int maxSleepTime;

	public CommandTableUpdateThread(DataTable<CommandTableRow> parent,
			int maxSleepTime) {
		this.parent = parent;
		this.maxSleepTime = maxSleepTime;
	}

	public void halt() {
		this.quit = true;
	}

	public void run() {
		try {

			while (!quit) {
				Thread.sleep(50);

				if (parent.isCurrentlyVisible()) {

					Object[] rowData = RpcClient.getInstance().getCommandStatusOverview();
					
					Vector<CommandTableRow> newData = new Vector<CommandTableRow>(
							rowData.length);

					for (int i = 0; i < rowData.length; i++) {
						newData.add(new CommandTableRow((Map) rowData[i], i));
					}

					parent.setTableData(newData);
					parent.updateGui();
					Thread.sleep(maxSleepTime);
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}