package edu.washington.cs.pl_if.gui.table;

public interface TableRow {

	public String[] toStringArray();

	public boolean isVisible();

	public int getRowId();

	public void setChecked(boolean checked);
}
