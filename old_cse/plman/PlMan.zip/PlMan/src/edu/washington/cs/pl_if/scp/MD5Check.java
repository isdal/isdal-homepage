package edu.washington.cs.pl_if.scp;

public interface MD5Check extends Runnable {

	
	public void checkFile(FileInfo file);
	
	public boolean wasSuccess();
}
