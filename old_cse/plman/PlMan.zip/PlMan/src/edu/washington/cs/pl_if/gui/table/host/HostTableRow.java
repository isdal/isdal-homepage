package edu.washington.cs.pl_if.gui.table.host;

import java.util.Map;

import edu.washington.cs.pl_if.gui.table.TableRow;

public class HostTableRow implements TableRow {

	private boolean connected;

	private String planetlabSite;

	private int connectionId;

	private String hostname;

	private String command;

	private String exitStatus;

	private double executionTime;

	private String lastLine;

	private double progress;

	public HostTableRow(Map map, int totalCommandNum) {
		this.connectionId = (Integer) map.get("connection_id");
		this.hostname = (String) map.get("hostname");
		this.exitStatus = (String) map.get("exit_stats_string");
		this.command = (String) map.get("command");
		this.executionTime = (Double) map.get("execution_time");
		this.lastLine = (String) map.get("last_line");
		this.planetlabSite = (String) map.get("site");
		this.connected = (Boolean) map.get("connected");
		// int currentCommandNum = (Integer) map.get("current_command_num");
		int completedCommandNum = (Integer) map.get("completed_command_num");

		this.progress = ((double) completedCommandNum)
				/ ((double) totalCommandNum);
	}

	public String getCommand() {
		return command;
	}

	public int getConnectionId() {
		return connectionId;
	}

	public double getExecutionTime() {
		return executionTime;
	}

	public String getExitStatus() {
		return exitStatus;
	}

	public String getHostname() {
		return hostname;
	}

	public String getLastLine() {
		return lastLine;
	}

	public String getPlanetlabSite() {
		return planetlabSite;
	}

	public double getProgress() {
		return progress;
	}

	public double getTime() {
		return executionTime;
	}

	public boolean isConnected() {
		return connected;
	}

	public String toString() {
		return hostname + ": " + connected;
	}

	public String[] toStringArray() {

		String time = ""
				+ ((double) Math.round(this.executionTime * 10.0) / 10.0);
		String[] s = { planetlabSite, hostname, command, exitStatus, time,
				progress + "", lastLine };
		return s;
	}

	public int getRowId() {
		return this.getConnectionId();
	}

	public boolean isVisible() {
		return this.isConnected();
	}

	public boolean isChecked() {
		return false;
	}

	public void setChecked(boolean checked) {
		// TODO Auto-generated method stub
		
	}

}
