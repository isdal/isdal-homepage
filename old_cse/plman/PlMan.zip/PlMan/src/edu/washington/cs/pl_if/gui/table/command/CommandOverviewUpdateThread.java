package edu.washington.cs.pl_if.gui.table.command;

import java.util.Map;
import java.util.Vector;

import edu.washington.cs.pl_if.gui.table.DataTable;
import edu.washington.cs.pl_if.gui.table.UpdateThread;
import edu.washington.cs.pl_if.rpc.client.RpcClient;

public class CommandOverviewUpdateThread implements UpdateThread<CommandOverviewRow> {
	private volatile boolean quit = false;

	final DataTable<CommandOverviewRow> parent;

	final int maxSleepTime;
	final int commandId;

	public CommandOverviewUpdateThread(DataTable<CommandOverviewRow> parent,
			int maxSleepTime, int commandId) {
		this.parent = parent;
		this.maxSleepTime = maxSleepTime;
		this.commandId = commandId;
	}

	public void halt() {
		this.quit = true;
	}

	public void run() {
		try {
			//System.out.println("starting updateThread");
			while (!quit) {
				Thread.sleep(50);

				//if (parent.isCurrentlyVisible()) {
					//System.out.println("running update");
					Object[] rowData = RpcClient.getInstance().getCommandOverview(commandId);
					
					Vector<CommandOverviewRow> newData = new Vector<CommandOverviewRow>(
							rowData.length);

					for (int i = 0; i < rowData.length; i++) {
						//System.out.println((String)((Map)rowData[i]).get("hostname"));
						newData.add(new CommandOverviewRow((Map) rowData[i]));
					}

					parent.setTableData(newData);
					parent.updateGui();
					Thread.sleep(maxSleepTime);
				//}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}