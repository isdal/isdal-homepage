package edu.washington.cs.pl_if.gui.table.command;

import java.util.Map;

import edu.washington.cs.pl_if.gui.table.TableRow;

public class CommandOverviewRow implements TableRow {

	private final String hostname;

	private final int connectionId;

	private final String command;

	private final int exitCode;

	private final String exitCodeString;

	private final int outputRows;

	private final String lastLine;

	private final boolean connected;

	private final String site;

	private final double execTime;

	@SuppressWarnings("unchecked")
	public CommandOverviewRow(Map map) {
		this.site = (String) map.get("site");

		this.hostname = (String) map.get("hostname");
		this.connectionId = (Integer) map.get("connection_id");
		this.command = (String) map.get("command");

		this.exitCode = (Integer) map.get("exit_code");
		this.exitCodeString = (String) map.get("exit_code_string");
		this.outputRows = (Integer) map.get("output_rows");
		this.lastLine = (String) map.get("last_line");
		this.connected = (Boolean) map.get("connected");
		this.execTime = (Math.round((Double) map.get("exec_time") * 10.0) / 10.0);
	}

	public int getRowId() {
		return this.getConnectionId();
	}

	public boolean isVisible() {
		return this.isConnected();
	}

	public String[] toStringArray() {
		String[] ret = { site, hostname, command, exitCodeString,
				"" + execTime, "" + outputRows, lastLine };
		return ret;
	}

	public String getCommand() {
		return command;
	}

	public int getConnectionId() {
		return connectionId;
	}

	public int getExitCode() {
		return exitCode;
	}

	public String getExitCodeString() {
		return exitCodeString;
	}

	public String getHostname() {
		return hostname;
	}

	public String getLastLine() {
		return lastLine;
	}

	public int getOutputRows() {
		return outputRows;
	}

	public boolean isConnected() {
		return connected;
	}

	public String getSite() {
		return site;
	}

	public double getExecTime() {
		return execTime;
	}
	
	public String toString(){
		return "command " + hostname;
	}

	public boolean isChecked() {
		return false;
	}

	public void setChecked(boolean checked) {
		
	}

}
