package edu.washington.cs.pl_if.plc.comon;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import edu.washington.cs.pl_if.plc.PlanetLabHost;

public class CoMonManager implements Runnable {
	public final static String RESPTIME = "resptime";
	public final static String HOSTNAME = "name";

	public final static String LOAD_AVERAGE_5 = "5minload";

	// private final static String CPU_SPEED = "cpuspeed";

	public final static String MEM_TOTAL = "memsize";

	public final static String MEM_FREE = "freemem";

	public final static String[] REQUIRED_FIELDS = { RESPTIME, HOSTNAME,
			LOAD_AVERAGE_5, MEM_TOTAL, MEM_FREE };
	// private hosts;

	private int totalBytes = 0;

	private volatile double progress = 0;

	private static final String COMON_URL = "http://comon.cs.princeton.edu/status/tabulator.cgi?"
			+ "table=table_nodeviewshort&format=formatcsv&dumpcols='"
			+ arrayToCommaSeparated(REQUIRED_FIELDS) + "'";

	public static final int COMON_NUM_FIELDS = 55;

	private HashMap<String, PlanetLabHost> plHostMap;

	public static void main(String[] args) {
		Thread t = new Thread(new CoMonManager(new PlanetLabHost[0]));
		t.start();
	}

	private static String arrayToCommaSeparated(String[] requiredFields) {
		StringBuilder b = new StringBuilder();
		for (int i = 0; i < requiredFields.length; i++) {
			b.append(requiredFields[i]);
			if (i + 1 < requiredFields.length) {
				b.append(",");
			}
		}

		return b.toString();
	}

	public CoMonManager(PlanetLabHost[] hosts) {
		plHostMap = new HashMap<String, PlanetLabHost>();

		for (int i = 0; i < hosts.length; i++) {
			plHostMap.put(hosts[i].getHostname(), hosts[i]);
		}
	}

	public void run() {
		// TODO Auto-generated method stub
		totalBytes = 0;
		progress = 0;
		try {
			URL url = new URL(COMON_URL);

			// HttpURLConnection connection = (HttpURLConnection) url
			// .openConnection();

			// ok, this IS an ugly hack :-)
			totalBytes = 240717;// connection.getContentLength();

			BufferedReader in = new BufferedReader(new InputStreamReader(url
					.openStream()));

			String titleLine = in.readLine();
			int downloadedBytes = titleLine.length();

			String[] headers = getHeaders(titleLine);

			try {
				checkHeaders(headers);
			} catch (Exception e) {
				System.err.println(e.getMessage());
				System.err
						.println("got some errors when parsing comon data, doing my best anyway");
			}
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				CoMonStat statEntry = new CoMonStat(parseComonData(headers,
						inputLine));
				String hostname = statEntry.getHostname();
				if (plHostMap.containsKey(hostname)) {
					PlanetLabHost plHost = plHostMap.get(hostname);
					plHost.setCoMonStat(statEntry);
					// System.out.println(plHost.getComMonStat().getHostname()
					// + ": "
					// + plHost.getComMonStat().getResponseTime());
				}
				downloadedBytes += inputLine.length();

				progress = ((double) downloadedBytes) / (double) totalBytes;
				// System.out.println(progress);
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		progress = 1.0;
	}

	private String[] getHeaders(String comonTitleLine) {
		if (comonTitleLine == null) {
			return new String[0];
		}
		// System.out.println(comonTitleLine);
		String[] split = comonTitleLine.split(", ");
		return split;
	}

	private static void checkHeaders(String[] headers) throws Exception {
		for (String requiredHeader : REQUIRED_FIELDS) {
			boolean found = false;
			for (String h : headers) {
				if (h.equals(requiredHeader)) {
					found = true;
				}
			}
			if (!found) {
				throw new Exception("Comon Error, unable to get field: "
						+ requiredHeader + "\nNew comon format?");
			}
		}
	}

	private Map<String, String> parseComonData(String[] headers, String line) {
		String[] values = line.split(", ");
		HashMap<String, String> map = new HashMap<String, String>();
		for (int i = 0; i < values.length; i++) {
			map.put(headers[i], values[i]);
			// System.out.println(headers[i] + "->" + values[i]);
		}
		return map;
	}

	public double getProgress() {
		return progress;
	}

}
