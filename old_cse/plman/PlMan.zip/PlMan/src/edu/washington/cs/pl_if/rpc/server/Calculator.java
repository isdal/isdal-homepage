package edu.washington.cs.pl_if.rpc.server;

public class Calculator {

	public int add(int i1, int i2) {
		return i1 + i2;
	}

	public int subtract(int i1, int i2) {
		return i1 - i2;
	}

}
