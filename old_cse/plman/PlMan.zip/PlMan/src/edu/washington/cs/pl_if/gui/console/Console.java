package edu.washington.cs.pl_if.gui.console;

import java.util.Map;
import java.util.concurrent.Semaphore;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.custom.StyledTextContent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import swing2swt.layout.BorderLayout;
import edu.washington.cs.pl_if.gui.table.TableResizeControlAdapter;
import edu.washington.cs.pl_if.rpc.client.RpcClient;
import edu.washington.cs.pl_if.ssh.OutputLine;

public class Console extends Composite {

	private Semaphore updateSemaphore = new Semaphore(1);

	private Table table;

	private StyledText styledText;

	// the id of the ssh connection
	private int hostIndex;

	// integer that holds how many rows we have read so far
	private int currentPos;

	// private Vector<Map> commands = new Vector<Map>();

	private boolean autoscroll = true;

	private boolean firstUpdate = true;

	final Composite tableComp;

	// private Integer commandId = -1;

	/**
	 * Create the composite
	 * 
	 * @param parent
	 * @param style
	 */
	public Console(Composite parent, int style, int hostIndex_) {
		super(parent, style);

		parent.setLayout(new BorderLayout(0, 0));

		this.hostIndex = hostIndex_;

		setLayout(new BorderLayout(0, 0));
		final SashForm sashForm = new SashForm(this, SWT.VERTICAL);
		 sashForm.setLayoutData(BorderLayout.CENTER);

		tableComp = new Composite(sashForm, SWT.NULL);

		tableComp.setLayout(new FillLayout(SWT.HORIZONTAL));
		//tableComp.setLayoutData(BorderLayout.CENTER);

		table = new Table(tableComp, SWT.PUSH | SWT.FULL_SELECTION);
		//table.setLayoutData(BorderLayout.NORTH);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);

		final TableColumn newColumnTableColumn_2 = new TableColumn(table,
				SWT.NONE);
		newColumnTableColumn_2.setWidth(100);
		newColumnTableColumn_2.setText("Exec command");

		final TableColumn newColumnTableColumn_4 = new TableColumn(table,
				SWT.NONE);
		newColumnTableColumn_4.setWidth(100);
		newColumnTableColumn_4.setText("Exit status");

		final TableColumn newColumnTableColumn_3 = new TableColumn(table,
				SWT.NONE);
		newColumnTableColumn_3.setWidth(50);
		newColumnTableColumn_3.setText("Time");

		table
				.addControlListener(new TableResizeControlAdapter(tableComp,
						table, 0));

		styledText = new StyledText(sashForm, SWT.V_SCROLL | SWT.H_SCROLL);
		styledText.setEditable(false);

		sashForm.setWeights(new int[] { 1, 3 });
		this.updateGuiData();
		//
	}

	@Override
	public void dispose() {
		super.dispose();
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	@Override
	public void update() {
		// System.out.println(tableComp.getBounds().height + "/"
		//				+ table.getBounds().height);
		try {
			if (isVisible()) {
				updateSemaphore.acquire();

				updateGuiData();

				updateSemaphore.release();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println(hostIndex + ": update");
		super.update();

	}

	private void updateGuiData() {

		Object[] consoleOutput = RpcClient.getInstance().readConsole(hostIndex,
				currentPos);
		Object[] tableData = RpcClient.getInstance().getCommandStats(hostIndex);
		table.setRedraw(false);

		// update table with command stats
		this.updateTableObject(tableData);

		// only start from the beginning once, after that it is enough to only
		// add new lines;

		// System.out.println("GUI> reading from: " + currentPos + " to "
		// + (currentPos + consoleOutput.length));
		for (int i = 0; i < consoleOutput.length; i++) {
			Map line = (Map) consoleOutput[i];

			String type = (String) line.get("type");

			if (type.equals(OutputLine.TYPE_COMMAND)) {
				styledText.append(">");
			}
			styledText.append(line.get("line") + "\n");

			// check if we have moved away from autoscroll mode
			ScrollBar bar = styledText.getVerticalBar();

			if (bar != null) {
				if (firstUpdate) {
					bar.setSelection(bar.getMaximum());
					firstUpdate = false;
				}
				double barMax = bar.getMaximum();
				double barCurrent = bar.getSelection() + bar.getThumb();

				// System.out.println("" + barMax + "," + barCurrent + ",");

				double scrollPercent = barCurrent / barMax;
				if (scrollPercent < 0.90) {
					autoscroll = false;
				} else {
					autoscroll = true;
				}

			}
			// set focus on the last line, if in autoscroll mode
			if (autoscroll) {
				StyledTextContent doc = styledText.getContent();
				int docLength = doc.getCharCount();
				if (docLength > 0) {
					styledText.setCaretOffset(docLength);
					styledText.showSelection();
				}
			}

			// check if we want to use other colors
			// default with white
			Color lineColor = new Color(this.getDisplay(), 255, 255, 255);
			if (type.equals(OutputLine.TYPE_STDERR)) {
				// some light red
				lineColor = new Color(this.getDisplay(), 255, 200, 200);
			} else if (type.equals(OutputLine.TYPE_COMMAND)) {
				// some light blue
				lineColor = new Color(this.getDisplay(), 240, 240, 255);
			} else if (type.equals(OutputLine.TYPE_CONTROLL)) {
				// some light green
				lineColor = new Color(this.getDisplay(), 240, 255, 240);
			} else if (type.equals(OutputLine.TYPE_CONTROLL_ERR)) {
				// bam, orange
				lineColor = new Color(this.getDisplay(), 255, 69, 0);
			}

			styledText.setLineBackground(styledText.getLineCount() - 2, 1,
					lineColor);
			currentPos++;
		}
		table.setRedraw(true);

	}

	private void updateTableObject(Object[] data) {
		while (table.getItemCount() < data.length) {
			this.addTableRow();
		}
		for (int i = 0; i < data.length; i++) {

			Map command = (Map) data[i];

			TableItem item = table.getItem(i);
			String commandStr = (String) command.get("command");
			String exitCode = (String) command.get("exit");

			double executeTime = (Math
					.round((Double) command.get("time") * 10.0)) / 10.0;

			String[] text = { commandStr, exitCode, executeTime + "" };
			item.setText(text);
			// System.out.println("time=" + executeTime);
		}

	}

	private void addTableRow() {

		TableItem item = new TableItem(table, SWT.NONE);
		String[] text = { "" + "", "" };
		item.setText(text);
		table.setSelection(item);
		// scroll here
		table.showSelection();
	}
}
