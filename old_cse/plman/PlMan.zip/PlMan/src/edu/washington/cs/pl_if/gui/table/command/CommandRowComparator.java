package edu.washington.cs.pl_if.gui.table.command;

import edu.washington.cs.pl_if.gui.table.GenericRowComparator;
import edu.washington.cs.pl_if.gui.table.RowComparator;

/**
 * This class does the comparisons for sorting Host row objects.
 */
public class CommandRowComparator implements RowComparator<CommandTableRow> {

	private int column;

	private int direction;

	private RowComparator<CommandTableRow> genericComparator = new GenericRowComparator<CommandTableRow>();

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#compare(edu.washington.cs.pl_if.gui.table.host.HostTableRow,
	 *      edu.washington.cs.pl_if.gui.table.host.HostTableRow)
	 */
	public int compare(CommandTableRow r1, CommandTableRow r2) {
		int rc = 0;
		final int COMMAND_ID = 1;
		
		// Determine which field to sort on, then sort
		// on that field
		switch (column) {
		case COMMAND_ID:
			Integer i1 = r1.getCommandId();
			Integer i2 = r2.getCommandId();
			rc = i1.compareTo(i2);
			break;
		default:
			return genericComparator.compare(r1, r2);
		}

		// Check the direction for sort and flip the sign
		// if appropriate
		if (direction == DESCENDING) {
			rc = -rc;
		}
		return rc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#reverseDirection()
	 */
	public void reverseDirection() {
		direction = 1 - direction;
		genericComparator.setDirection(direction);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#setColumn(int)
	 */
	public void setColumn(int column) {
		this.column = column;
		genericComparator.setColumn(column);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.washington.cs.pl_if.gui.table.host.RowComparator#setDirection(int)
	 */
	public void setDirection(int direction) {
		this.direction = direction;
		genericComparator.setDirection(direction);
	}
}