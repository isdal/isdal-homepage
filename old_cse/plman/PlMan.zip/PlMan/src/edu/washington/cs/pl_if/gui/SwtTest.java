package edu.washington.cs.pl_if.gui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;

public class SwtTest {

	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell(display);
		
		 final TabFolder tabFolder =
			   new TabFolder( shell, SWT.BORDER);
			 for (int i=1; i<5; i++)
			 {
			   // create a TabItem
			   TabItem item = 
			     new TabItem( tabFolder, SWT.NULL);
			   item.setText( "TabItem " + i);
			   // create a control
			   Label label  =
			     new Label( tabFolder, SWT.BORDER);
			   label.setText( "Page " + i);
			   // add a control to the TabItem
			   item.setControl( label );
			 }
			 
		shell.pack();
		tabFolder.pack();
		shell.open();
		while (!shell.isDisposed())
			if (!display.readAndDispatch())
				display.sleep();
		display.dispose();
		tabFolder.dispose();
	}

}
