package edu.washington.cs.pl_if.gui.table.host;

import java.util.Map;
import java.util.Vector;

import edu.washington.cs.pl_if.gui.table.DataTable;
import edu.washington.cs.pl_if.gui.table.UpdateThread;
import edu.washington.cs.pl_if.rpc.client.RpcClient;

public class HostTableUpdateThread implements UpdateThread<HostTableRow> {
	private volatile boolean quit = false;

	final DataTable<HostTableRow> parent;

	final int maxSleepTime;
	public HostTableUpdateThread(DataTable<HostTableRow> parent, int maxSleepTime) {
		this.parent = parent;
		this.maxSleepTime = maxSleepTime;
	}

	public void halt() {
		this.quit = true;
	}

	public void run() {
		try {

			while (!quit) {
				Thread.sleep(50);

				if (parent.isCurrentlyVisible()) {

					int commandNum = RpcClient.getInstance()
							.totalCommandNum();

					Object[] rowData = RpcClient.getInstance()
							.getHostStatusOverview();

					Vector<HostTableRow> newData = new Vector<HostTableRow>(
							rowData.length);

					for (int i = 0; i < rowData.length; i++) {
						newData.add(new HostTableRow((Map) rowData[i],
								commandNum));
					}

					parent.setTableData(newData);
					parent.updateGui();
					Thread.sleep(maxSleepTime);
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}