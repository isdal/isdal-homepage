package edu.washington.cs.pl_if.gui.table;

public interface UpdateThread<T extends TableRow> extends Runnable {

	public void halt();
}
