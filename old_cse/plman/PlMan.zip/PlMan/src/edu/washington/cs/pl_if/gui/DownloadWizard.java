package edu.washington.cs.pl_if.gui;


import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import edu.washington.cs.pl_if.scp.download.DownloadManager;

public class DownloadWizard extends Wizard {

	private DownloadPage downloadPage;

	private final GuiMain guiMain;

	public DownloadWizard(GuiMain guiMain) {
		this.guiMain = guiMain;
		downloadPage = new DownloadPage();
		this.addPage(downloadPage);
	}

	@Override
	public boolean performFinish() {
		String remotePath = downloadPage.getRemotePath();
		String localPath = downloadPage.getLocalPath();
		if (remotePath == null || remotePath.equals("")) {
			System.err.println("invalid remote path");
			return false;
		}
		if (localPath == null || localPath.equals("")) {
			System.err.println("invaild local path");
			return false;
		}

		guiMain.downloadDir(downloadPage.getRemotePath(), downloadPage
				.getLocalPath(), downloadPage.getFilter(), downloadPage
				.getNamingType());
		return true;
	}

	private class DownloadPage extends WizardPage {

		public static final String PAGE_NAME = "Download";

		private Text localPath, remotePath, filter;

		private Combo dirType;

		public DownloadPage() {
			super(PAGE_NAME, "Download wizard", null);
		}

		public void createControl(final Composite parent) {
			// TODO Auto-generated method stub
			Composite topLevel = new Composite(parent, SWT.NONE);
			GridLayout layout = new GridLayout();
			layout.numColumns = 3;
			topLevel.setLayout(layout);

			GridData makeBig = new GridData();
			makeBig.horizontalAlignment = SWT.FILL;
			makeBig.grabExcessHorizontalSpace = true;

			// *** create the select local path row
			Label localPathLabel = new Label(topLevel, SWT.LEFT);
			localPathLabel.setText("Local target directory");
			localPath = new Text(topLevel, SWT.LEFT | SWT.BORDER);
			localPath.setLayoutData(makeBig);

			Button localBrowseButton = new Button(topLevel, SWT.PUSH);
			localBrowseButton.setText("Browse");
			localBrowseButton.addMouseListener(new MouseAdapter() {
				public void mouseUp(MouseEvent arg0) {
					DirectoryDialog dialog = new DirectoryDialog(parent
							.getShell());
					dialog.setFilterPath(".");
					localPath.setText(dialog.open());
				}
			});

			// *** create the select remote path row
			Label remotePathLabel = new Label(topLevel, SWT.LEFT);
			remotePathLabel.setText("Remote directory or file");
			remotePath = new Text(topLevel, SWT.LEFT | SWT.BORDER);
			remotePath.setLayoutData(makeBig);
			Button remoteBrowseButton = new Button(topLevel, SWT.PUSH);
			remoteBrowseButton.setText("Browse");
			remoteBrowseButton.setEnabled(false);

			// *** create the select filter
			Label filterLabel = new Label(topLevel, SWT.LEFT);
			filterLabel
					.setText("Set filter for files to download \n(leave empty for no filter)");
			filter = new Text(topLevel, SWT.LEFT | SWT.BORDER);
			filter.setLayoutData(makeBig);
			new Label(topLevel, SWT.NONE);
			// *** create the naming combo
			Label namingLabel = new Label(topLevel, SWT.LEFT);
			namingLabel.setText("Choose naming convention \n"
					+ "for files after downloaded\n"
					+ " flat=directory separators\n"
					+ "  replaced by underscore\n"
					+ " hierarchical=directory\n"
					+ "  stucture from the remote host");
			dirType = new Combo(topLevel, SWT.DROP_DOWN);
			for (int i = 0; i < DownloadManager.NAMING_TYPES.length; i++) {
				dirType.add(DownloadManager.NAMING_TYPES[i]);
			}
			dirType.select(0);
			new Label(topLevel, SWT.NONE);

			setControl(topLevel);
			setPageComplete(true);
		}

		public String getLocalPath() {
			return localPath.getText();
		}

		public String getNamingType() {
			return DownloadManager.NAMING_TYPES[dirType.getSelectionIndex()];
		}

		public String getFilter() {
			return filter.getText();
		}

		public String getRemotePath() {
			return remotePath.getText();
		}

	}
}
