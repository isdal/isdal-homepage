import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;

public class SwtTest2 implements Runnable {

	public static void main(String[] args) {
		System.out.println("running");
		new SwtTest2();
	}

	public SwtTest2() {

		Thread t = new Thread(this);
		t.setDaemon(false);
		t.start();
		
		try {
			Thread.sleep(10000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void run() {
		startShell();
	}

	private void startShell() {
		System.out.println("in startShell()");
		Display display = new Display();
		System.out.println("new Display()");
		Shell shell = new Shell(display);
		System.out.println("new Shell()");

		final TabFolder tabFolder = new TabFolder(shell, SWT.BORDER);
		for (int i = 1; i < 5; i++) {
			// create a TabItem
			TabItem item = new TabItem(tabFolder, SWT.NULL);
			item.setText("TabItem " + i);
			// create a control
			Label label = new Label(tabFolder, SWT.BORDER);
			label.setText("Page " + i);
			// add a control to the TabItem
			item.setControl(label);
		}

		shell.pack();
		tabFolder.pack();
		shell.open();
		while (!shell.isDisposed())
			if (!display.readAndDispatch())
				display.sleep();
		display.dispose();
		tabFolder.dispose();
	}
}
