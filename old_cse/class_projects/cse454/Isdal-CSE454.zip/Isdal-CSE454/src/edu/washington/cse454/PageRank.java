/* CSE454, Dept. of Computer Science and Engineering  */
/* University of Washington, 2004                     */
package edu.washington.cse454;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;

import java.io.FileOutputStream;

import java.io.RandomAccessFile;

import edu.washington.cse454support.*;

/**
 * Inplementation of
 * 
 * @author Oliver Huslid & Tomas Isdal
 */
public class PageRank implements IRanker2 {

	// variable tha controls the size of the sub dest array. this variable can
	// be changed to cope with different main memory sizes
	final int DEST_MEM_SIZE = 100000;

	// debug level
	final int debug = 0;

	// damening factor as specified in the google paper
	final double DAMPENING_FACTOR = 0.85;

	// variable that controlls what size the residual should be before the rank
	// array is considered stable
	final double MIN_RES = 0.0000001; // 1E-7

	// normalizer used to get all values beween 1.0 and 0.0 during
	// postprocessing
	double postProcessRankNormalizer = 0.0;

	// normalizer used to get all values beween 1.0 and 0.0 during
	// postprocessing
	double rankNormalizer = 0.0;

	// standard path to store temporary files
	final String filePath = "/tmp/edu.washington.cse454." + Math.random() + ".";

	private File rankFile;

	/**
	 * The constructor
	 */
	public PageRank() {
	}

	/**
	 * The initfuction calls the other functions that create the the page rank
	 * array file. This enables us to do lookups in constant time
	 */
	public void init(DocumentSetInfo2 info) {
		 File[] partitionedLinkFiles = createPartitionedLinkFile(info);
		 this.rankFile = calcPageRank(info, partitionedLinkFiles);
		// this.rankFile = new
		// File("/tmp/edu.washington.cse454/medium.rank.final");
		//this.rankFile = new File("/tmp/edu.washington.cse454.0.3728179090173235.rank.final");
		// System.out.println("Using rankfile:" + rankFile.getAbsolutePath());
		// rankNormalizer = 0.002789257327094674; // medium
		//rankNormalizer = 0.0012122776824980974; // large
		// System.out.println("Ranknormalizer = " + rankNormalizer);

	}

	/**
	 * The getRelevance function returns the pagerank for the current document.
	 * The rank is stored in the rank array which enables lookups in one disk
	 * seek. In this case with only 1M documets the rank array can fit in memory
	 * (only 4M needed) but to enable the ranker to use bigger crawls is the
	 * array stored on disk.
	 */
	public double getRelevance(String queryTerms[], Document2 doc,
			boolean bodyHit, boolean anchorHit) {
		try {
			// Open the rank file
			RandomAccessFile rankFileReader = new RandomAccessFile(rankFile,
					"r");
			// seek to the position where this documents rak is stored
			rankFileReader.seek(doc.getDocId() * 4);

			// read the rank
			double rank = rankFileReader.readFloat() / rankNormalizer;
			// update the value for the post process normalizer
			if (rank > postProcessRankNormalizer)
				postProcessRankNormalizer = rank;
			rankFileReader.close();

			return rank;
		} catch (Exception e) {

			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * The post process function only normalizes the results to that the best
	 * page gets 1.0. This is done to make weighting between rankers more easy
	 * 
	 * To cope with the very special anture of page ranks, that som get very
	 * small values, the ranks is returned in log to make the values more equal.
	 * This is done to make weighting between rankers easier
	 */
	public double postProcess(String queryStrs[], Document2 doc,
			boolean bodyHit, boolean anchorHit, StringBuffer annotation) {
		double score = 1 / (Math.abs(Math.log10(getRelevance(queryStrs, doc,
				bodyHit, anchorHit)
				/ postProcessRankNormalizer) - 1));

		return score;
	}

	/**
	 * Function that calculates page rank for a documents set
	 * 
	 * @param info
	 *            object that contains info about the crawl
	 * @param linkFiles
	 *            array of files in which the binary representation of the link
	 *            graph is stored
	 * @return
	 */
	private File calcPageRank(DocumentSetInfo2 info, File[] linkFiles) {

		double residual = 1.0;
		int fileId = 0;
		File sourceFile = new File(filePath + "rank." + fileId);
		fileId++;
		File destFile = new File(filePath + "rank." + fileId);
		try {
			DataOutputStream sourceStream = new DataOutputStream(
					new BufferedOutputStream(new FileOutputStream(sourceFile)));

			// Write the initial values to the source
			for (int i = 0; i < info.numDocs(); i++) {
				sourceStream.writeFloat((float) 1.0 / (float) info.numDocs());

			}
			sourceStream.close();

			// System.out.print("1/N: " + (float) 1.0 / (float) info.numDocs());

			double[] dest;
			int destLength = 0;
			while (residual > MIN_RES) {
				// Read in the file with the ranks from the previous iteration
				DataInputStream source = new DataInputStream(
						new BufferedInputStream(new FileInputStream(sourceFile)));

				// place a mark at the beginning of the source file to enable us
				// to return there when calling reset()
				source.mark(Integer.MAX_VALUE);

				// Create a new file stream to write the new ranks to
				DataOutputStream destStream = new DataOutputStream(
						new BufferedOutputStream(new FileOutputStream(destFile)));

				for (int fileNum = 0; fileNum < linkFiles.length; fileNum++) {
					// reset the source filepointer to the beginning of the
					// file
					source.reset();
					// create a net destination array of the correct size for
					// this subset of the data
					dest = new double[DEST_MEM_SIZE];

					// create a buffered stream to make reading faster
					DataInputStream linkFile = new DataInputStream(
							new BufferedInputStream(new FileInputStream(
									linkFiles[fileNum])));

					int currentDocument = 0;
					float currentDocRank = 0;
					short outDegree = 0;
					short numOut = 0;
					int currentDest = 0;

					// loop through alll documents
					while (currentDocument < info.numDocs() - 1) {

						// read values from file
						currentDocument = linkFile.readInt();
						outDegree = linkFile.readShort();
						numOut = linkFile.readShort();
						currentDocRank = source.readFloat();

						// loop through all out links
						for (int j = 0; j < numOut; j++) {
							currentDest = linkFile.readInt();
							// update the page where the out link points rank
							dest[currentDest % DEST_MEM_SIZE] = dest[currentDest
									% DEST_MEM_SIZE]
									+ (currentDocRank / (float) outDegree);

						}

					}
					linkFile.close();
					if (fileNum != linkFiles.length - 1) {
						destLength = dest.length;
					} else {
						destLength = info.numDocs() % DEST_MEM_SIZE;
					}

					// Loop through the array with the subset of the new
					// pageranks for each rank, apply the dampening factor and
					// write to disk
					for (int j = 0; j < destLength; j++) {
						dest[j] = dest[j] * DAMPENING_FACTOR
								+ (1 - DAMPENING_FACTOR) / info.numDocs();
						destStream.writeFloat((float) dest[j]);
					}
				}
				destStream.close();

				// Calculate the residual (currently the variance)
				DataInputStream tempdest = new DataInputStream(
						new BufferedInputStream(new FileInputStream(destFile)));
				residual = 0.0;
				rankNormalizer = 0.0;
				source.reset();
				float destrank;
				// calculate the residual so we knoe when to stop
				for (int k = 0; k < info.numDocs() - 1; k++) {
					destrank = tempdest.readFloat();
					if (destrank > rankNormalizer)
						rankNormalizer = destrank;
					residual += Math.abs(source.readFloat() - destrank);
				}
				residual /= (double) info.numDocs();
				// close open files
				tempdest.close();
				source.close();

				// delete temporary files
				sourceFile.delete();
				sourceFile = destFile;
				fileId++;
				destFile = new File(filePath + "rank." + fileId);

			}
			// delete all binary file that stored the link structure. We dont
			// need them anymore since the rank file is completed
			for (int i = 0; i < linkFiles.length; i++) {
				linkFiles[i].delete();
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
		File finalRankFile = new File(filePath + "rank.final");
		sourceFile.renameTo(finalRankFile);
		return finalRankFile;
	}

	/**
	 * Creates a binary structure for fast parsing of the link structure. The
	 * structure created allows us tho use subsets of the destination array
	 * while calculating the new pagerank. This enables us to limit the memory
	 * usage
	 * 
	 * @param info
	 *            DocumentSetInfo2 document with information about the query
	 * @return File[] with list of needed files
	 */

	private File[] createPartitionedLinkFile(DocumentSetInfo2 info) {

		// Calculate how many link files we need
		int linkFilesNeeded = (info.numDocs() / DEST_MEM_SIZE) + 1;
		// System.out.println("Files needed: " + linkFilesNeeded);

		// create an array to hold all our linkfiles so we can write to them in
		// "parallel"
		DataOutputStream[] fileList = new DataOutputStream[linkFilesNeeded];
		File[] returnFiles = new File[linkFilesNeeded];
		try {
			// Loop through all files and create buffered disk writers
			for (int i = 0; i < linkFilesNeeded; i++) {
				returnFiles[i] = new File(filePath + "linkfile." + i);
				fileList[i] = (new DataOutputStream(new BufferedOutputStream(
						new FileOutputStream(returnFiles[i]))));

			}

			// loog through all documets
			for (int docId = 0; docId < info.numDocs(); docId++) {
				int[] linkCount = new int[linkFilesNeeded];
				int[] outLinks = info.getOutlinks(docId);

				// Create an array with the number of out links in this bucket
				for (int j = 0; j < outLinks.length; j++) {
					linkCount[outLinks[j] / DEST_MEM_SIZE]++;
				}

				// write the "header" for this "row" in the binary file
				for (int i = 0; i < fileList.length; i++) {
					fileList[i].writeInt(docId);
					fileList[i].writeShort(outLinks.length);
					fileList[i].writeShort(linkCount[i]);

				}
				// write the outlinks to the correct binary file, the file to
				// write to is calculated by link/DEST_MEM_SIZE
				for (int i = 0; i < outLinks.length; i++) {
					fileList[outLinks[i] / DEST_MEM_SIZE].writeInt(outLinks[i]);

				}

			}

			for (int i = 0; i < fileList.length; i++) {
				fileList[i].close();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

		return returnFiles;
	}
}
