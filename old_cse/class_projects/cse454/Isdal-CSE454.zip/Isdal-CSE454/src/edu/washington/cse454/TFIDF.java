package edu.washington.cse454;

import edu.washington.cse454support.Document2;
import edu.washington.cse454support.DocumentSetInfo2;

/**
 * Class that calcualtes the TF-IDF value of a document and search terms
 * 
 * @author isdal,
 * 
 */
public class TFIDF {

	protected Document2 doc;

	private String queryTerms[];

	private DocumentSetInfo2 info;

	/**
	 * Constructor, creates a new TFIDF object
	 * 
	 * @param queryTerms
	 *            String array with all terms in the query
	 * @param doc
	 *            document use when calculating TF-IDF
	 * @param info
	 *            DocumentSetInfo containing various data needed
	 */
	public TFIDF(String[] queryTerms, Document2 doc, DocumentSetInfo2 info) {
		this.doc = doc;
		this.queryTerms = queryTerms;
		this.info = info;

	}

	/**
	 * Calculates how similar the documents are
	 * 
	 * @param queryWeights
	 *            array of query weights
	 * @return the weighted similarity
	 */
	public double getSimilarity(double[] queryWeights, boolean anchor) {
		double simi = 0.0;

		for (int k = 0; k < queryTerms.length; k++) {
			simi += calcNormTermTFIDF(queryTerms[k], anchor) * queryWeights[k];
		}
		return simi;
	}

	/**
	 * Calculates the TF-IDF value given a search term
	 * 
	 * @param term
	 *            the search term for which to calculate the TF-IDF value
	 * 
	 * @return TF-IDF value for the term
	 */
	public double calcNormTermTFIDF(String term, boolean anchor) {

		// The frequence of the search term in the document
		// returns different values for body or anchor
		double tf = getTermFrequency(doc, term, anchor);

		// Total number of documents containing the term
		int n;
		if (anchor) {
			// If we are calculating the TFIDF for the anchortext
			n = info.numTermOccurrencesInAnchorText(term);
		} else {
			// If we are calculating the TFIDF for the body
			n = info.numDocsContainingTermInBody(term);
		}

		// Total number of documents
		int N = info.numDocs();
		// IDF value calculated using the 10 logarithm
		double idf = Math.log10((double) N / (double) n);
		// TF-IDF value normalized using the normalize value provided by the
		// document class
		double tfidf = tf * idf / doc.bodyNormalizer();

		return tfidf;
	}

	/**
	 * Returns the term frequency of a given term in a given document. This
	 * method is a hook methods to enable sublcasses to change the term
	 * frequency count method.
	 * 
	 * @param doc
	 *            the document to look at.
	 * @param term
	 *            the term to look for.
	 * @return the term frequency of a given term in a given document.
	 */
	protected double getTermFrequency(Document2 doc, String term, boolean anchor) {
		if (anchor) {
			return doc.incomingAnchortextFreq(term);
		}
		return doc.bodyFreq(term);
	}

}
