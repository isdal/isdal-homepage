package edu.washington.cse454;

import edu.washington.cse454support.Document2;

/**
 * A modification of the TFIDFRanker which makes sure that documents where (one
 * of) the query terms extremely often does not get a very high relevance.
 * For a more detailed description of of the algorithm, see CappedTFIDF class. 
 * 
 * @author Henrik Jernevad & Tomas Isdal
 */
public class CappedTFIDFRanker extends TFIDFRanker {

	/* (non-Javadoc)
	 * @see edu.washington.cse454.TFIDFRanker#createTFIDF(java.lang.String[], edu.washington.cse454support.Document)
	 */
	@Override
	protected TFIDF createTFIDF(String[] queryTerms, Document2 doc) {
		return new CappedTFIDF(queryTerms, doc, info);
	}
}
