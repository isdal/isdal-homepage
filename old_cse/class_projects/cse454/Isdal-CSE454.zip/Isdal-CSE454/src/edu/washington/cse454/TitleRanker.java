package edu.washington.cse454;

import edu.washington.cse454support.Document2;

/**
 * A ranker which looks for how many times the query terms appear within the 
 * page's title. Based on the FeatureRanker. 
 * 
 * @author Henrik Jernevad
 */
public class TitleRanker extends FeatureRanker {

	// characters you typically use to separate words with in a document title
	private static final String TITLE_DIVIDERS = " |\\.|/|\\?|_|-";

	/* (non-Javadoc)
	 * @see edu.washington.cse454.FeatureRanker#getFeatureParts(edu.washington.cse454support.Document)
	 * Divides the title using all characters you typically use to separate 
	 * words with in a title.
	 */
	@Override
	protected String[] getFeatureParts(Document2 doc) {
		return doc.getTitle().toLowerCase().split(TITLE_DIVIDERS);
	}

}
