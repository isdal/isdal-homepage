package edu.washington.cse454;

import edu.washington.cse454support.Document2;
import edu.washington.cse454support.DocumentSetInfo2;

/**
 * A variation of the TFIDF algorithm which puts a cap on the number of 
 * occurrences of a query term that actually contribute to the relevance. This
 * is done in order to reduce the relevance of documents which contain certain
 * words an unproportional number of times since they usually aren't very 
 * useful documents. The term frequency cap is expressed as a fraction of the 
 * total document length.
 * 
 * An interesting effect here is that since we cannot modify the normalization
 * factor (we don't have all information needed to calculate it), the relevance
 * scores gets somewhat screwed. More interesting is that it actually turns out
 * that since we are lowering the TF score, but not lowering the normalizer 
 * proportionally, we actually end up punishing documents with extreme term 
 * frequecies - which might very well be a good thing to do. 
 * 
 * The fact that we cannot modify the normalization factor also obvoiusly means 
 * that our relevancy scores are not actually properly normalized. We'll have
 * to live with that though.
 * 
 * @author Henrik Jernevad & Tomas Isdal
 */
public class CappedTFIDF extends TFIDF {

	/**
	 * How many occurrences of a query term that will actually contribute to 
	 * the relevance score, expressed as a fraction of the total document 
	 * length.
	 */
	private static final double FREQUENCY_CAP_FRACTION = 0.01;

	/**
	 * Creates a new CappedTFIDF document based on the given information.
	 * @param queryTerms the query terms.
	 * @param doc the document to look in.
	 * @param info info about the corpus.
	 */
	public CappedTFIDF(String[] queryTerms, Document2 doc, DocumentSetInfo2 info) {
		super(queryTerms, doc, info);
	}
	
	/* (non-Javadoc)
	 * @see edu.washington.cse454.TFIDF#getTermFrequency(edu.washington.cse454support.Document, java.lang.String)
	 * Returns the term frequency of the given term in the given document 
	 * unless it is higher than a certain cap, in which case the cap is 
	 * returned.
	 */
	@Override
	protected double getTermFrequency(Document2 doc, String term,boolean anchor) {
		final double frequencyCap = doc.bodyLength() * FREQUENCY_CAP_FRACTION;
		return Math.min(frequencyCap, doc.bodyFreq(term));
	}

}
