/* CSE454, Dept. of Computer Science and Engineering  */
/* University of Washington, 2004                     */
package edu.washington.cse454;

import edu.washington.cse454support.Document2;
import edu.washington.cse454support.DocumentSetInfo2;
import edu.washington.cse454support.IRanker2;

/*******************************************************************************
 * DocumentRanker2 is an unfinished class you must implement for your search
 * engine to work correctly. Most of the search engine code already exists; you
 * 'only' need to write the code that ranks documents by "relevance".
 * 
 * Whenever the engine needs to find how "relevant" a page is in relation to a
 * query, it will call DocumentRanker2.getRelevance(). The hit set will then be
 * sorted according to the values that you return from the getRelevance()
 * function.
 * 
 * The engine will then take the top N hits, and call postProcess() for each
 * one. This is your opportunity to invoke more expensive and interesting
 * methods to reweight the final results. You can also annotate the result list.
 * 
 * This class *must* implement the IRanker2 interface, or else it will not work
 * with the CSE454 framework code.
 * 
 * For more info, see the course webpage at
 * http://www.cs.washington.edu/education/courses/454/
 ******************************************************************************/
public class DocumentRanker2 implements IRanker2 {

	private IRanker2 innerRanker;

	/**
	 * The constructor for your class.
	 * 
	 * NOTE: It is CRITICAL that this constructor have no arguments. Otherwise,
	 * the CSE454 framework will not be able to use your code.
	 */
	public DocumentRanker2() {
	}

	/**
	 * This is just calls the ulitmate ranker class
	 */
	public void init(DocumentSetInfo2 info) {
		// Try to load specified rankers
		UltimateRanker ultimateRanker = new UltimateRanker();
		// PageRank ultimateRanker = new PageRank();
		innerRanker = ultimateRanker;

		// Initialize the ranker(s).
		innerRanker.init(info);
	}

	/**
	 * forwards the query to the ultimate ranker class
	 */
	public double getRelevance(String queryTerms[], Document2 doc,
			boolean bodyHit, boolean anchorHit) {
		if (innerRanker == null) {
			throw new IllegalStateException("init() method not called yet.");
		}
		return innerRanker.getRelevance(queryTerms, doc, bodyHit, anchorHit);

	}

	/**
	 * forwards the query to the ultimate ranker class
	 */
	public double postProcess(String queryStrs[], Document2 doc,
			boolean bodyHit, boolean anchorHit, StringBuffer annotation) {
		if (innerRanker == null) {
			throw new IllegalStateException("init() method not called yet.");
		}
		return innerRanker.postProcess(queryStrs, doc, bodyHit, anchorHit,
				annotation);
	}
}
