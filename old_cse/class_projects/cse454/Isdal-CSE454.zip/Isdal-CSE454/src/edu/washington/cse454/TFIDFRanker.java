package edu.washington.cse454;

import edu.washington.cse454support.Document2;
import edu.washington.cse454support.DocumentSetInfo2;
import edu.washington.cse454support.IRanker2;

public class TFIDFRanker implements IRanker2 {
	protected DocumentSetInfo2 info;

	private double normalizer = 0.0;

	/**
	 * The constructor for your class.
	 * 
	 * NOTE: It is *CRITICAL* that this constructor have no arguments.
	 * Otherwise, the CSE454 framework will not be able to use your code.
	 */
	public TFIDFRanker() {
	}

	/**
	 * The init() method is called immediately after the class is created, and
	 * is called only once.
	 * 
	 * It provides your DocumentRanker instance with a DocumentSetInfo object.
	 * This object provides various statistics about the indexed documents and
	 * terms.
	 */
	public void init(DocumentSetInfo2 info) {

		this.info = info;
	}

	protected DocumentSetInfo2 getDocumentSetInfo() {
		return info;
	}

	/**
	 * getRelevance() returns a double. The higher the value returned, the more
	 * relevant the document.
	 * 
	 * This function is called once for every "hit" document found (no matter
	 * how many hits are found in a single doc). If there are no hits for your
	 * query, this method will not be called at all.
	 * 
	 * Defining this method usefully is the meat of Assignment 1.
	 */
	public double getRelevance(String queryTerms[], Document2 doc,
			boolean bodyHit, boolean anchorHit) {

		TFIDF tfidf = createTFIDF(queryTerms, doc);
		double relevance = tfidf.getSimilarity(calcQueryWeights(queryTerms,anchorHit),anchorHit);
		if (relevance > normalizer) {
			normalizer = relevance;
		}

		return relevance;
	}

	/**
	 * postProcess returns a double. The higher the value returned, the more
	 * relevant the document.
	 * 
	 * This function is called once for each of the top-N hit documents, as
	 * ranked by results from your getRelevance() function.
	 * 
	 * You can get access to the value you returned for this document in the
	 * earlier getRelevance() call by invoking IDocument2.getRelevanceScore().
	 */
	public double postProcess(String queryStrs[], Document2 doc,
			boolean bodyHit, boolean anchorHit, StringBuffer annotation) {
		double score = getRelevance(queryStrs,doc,bodyHit,anchorHit) / normalizer;
		
		return score;
	}

	/**
	 * Returns the TFIDF calculator object to use. This method is a hook for
	 * subclasses to be able to change which TFIDF algorithm to use.
	 * 
	 * @param queryTerms
	 *            the query terms.
	 * @param doc
	 *            the document to search.
	 * @return the TFIDF calculator object to use.
	 */
	protected TFIDF createTFIDF(String[] queryTerms, Document2 doc) {
		return new TFIDF(queryTerms, doc, info);
	}

	/**
	 * Calculates the weights for the query using the TF-IDF algorithm.
	 * 
	 * @param queryTerms
	 *            the query terms to calculate weights for.
	 * @return an array containing the weights for the query terms.
	 */
	public double[] calcQueryWeights(String queryTerms[], boolean anchor) {
		double[] weights = new double[queryTerms.length];
		int N = info.numDocs();

		// Get normalizer for query
		double normalizer = getNormalizer(queryTerms,anchor);

		// Calculate normalized weight for each query term
		for (int k = 0; k < queryTerms.length; k++) {

			double tf = 1; // Assume each word occurs only once in the query
			int n;
			if(anchor){
				n = info.numDocsContainingTermInAnchortext(queryTerms[k]);
			}else{
				n = info.numDocsContainingTermInBody(queryTerms[k]);
			}
			double idf = Math.log10((double) N / (double) n);
			weights[k] = tf * idf / normalizer;

		}
		return weights;
	}

	/**
	 * Returns the normalizer for a document which contains only the given query
	 * terms.
	 * 
	 * @param queryTerms
	 *            the words of query.
	 * @return the normalizer for a document which contains only the given query
	 *         terms.
	 */
	public double getNormalizer(String queryTerms[],boolean anchor) {
		double norm = 0;
		// Summarize the squares of all non-normalized weights
		for (int i = 0; i < queryTerms.length; i++) {
			double tf = 1;
			int n;
			if(anchor){
				n = info.numDocsContainingTermInAnchortext(queryTerms[i]);
			}else{
				n = info.numDocsContainingTermInBody(queryTerms[i]);
			}
			int N = info.numDocs();
			double nn = (double) N / (double) n;
			double idf = Math.log10(nn);
			norm += Math.pow(tf, 2) * Math.pow(idf, 2);
		}
		// Return square root of square-sum
		return Math.sqrt(norm);
	}
}
