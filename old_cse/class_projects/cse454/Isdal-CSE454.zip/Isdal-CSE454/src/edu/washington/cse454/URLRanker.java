package edu.washington.cse454;

import java.util.regex.Pattern;

import edu.washington.cse454support.Document2;

/**
 * A ranker which looks for how many times the query terms appear within the 
 * page's URL. Based on the FeatureRanker. 
 * 
 * @author Henrik Jernevad
 */
public class URLRanker extends FeatureRanker {

	// The characters you typically use to separate words with in a URL.
	private static final String URL_DIVIDERS = "\\.|/|\\?|_|-";

	/* (non-Javadoc)
	 * @see edu.washington.cse454.FeatureRanker#getFeatureParts(edu.washington.cse454support.Document)
	 * Divides the URL using all characters you typically use to separate words 
	 * with in  a URL.
	 */
	@Override
	protected String[] getFeatureParts(Document2 doc) {
		final String url = doc.getURL().toLowerCase();
		Pattern urlPattern = Pattern.compile(URL_DIVIDERS);
		return urlPattern.split(url);
	}
}
