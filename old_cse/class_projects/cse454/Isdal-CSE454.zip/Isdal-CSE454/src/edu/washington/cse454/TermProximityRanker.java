/**
 * 
 */
package edu.washington.cse454;

import edu.washington.cse454support.Document2;
import edu.washington.cse454support.DocumentSetInfo2;
import edu.washington.cse454support.IRanker2;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Class that calculates "proximity bonus" when multiple search terms are in
 * close proximity to each other
 * 
 * @author isdal
 * 
 */
public class TermProximityRanker implements IRanker2 {


	private static final double CLUSTERING_PERCENT = .001;
	final int PROXIMITY_DISTANCE_LIMIT = 100;

	/**
	 * Constructor, creates a new TermProximityRanker object
	 * 
	 */
	public TermProximityRanker() {

	}

	public void init(DocumentSetInfo2 info) {
	
	}

	/**
	 * Public funtion to get the proximity bonus for the current term proximity
	 * object
	 * 
	 * @param queryTerms
	 *            String array with all terms in the query
	 * @param doc
	 *            Document to calculate term proximity bonus on *
	 * @return the proximity bonus for the current document / queryterms,
	 *         normalized to a value between 0.0 and 1.0
	 */
	public double getRelevance(String queryTerms[], Document2 doc,boolean bodyHit, boolean anchorHit) {
		// If the query only contains one word, return 0
		if(queryTerms.length < 2){
			return 0.0;
		} 
		// Calculate the bonus for a proximitymatrix created with the current
		// queryterms
		double bonus = calcProximityBonus(calcProximityMatrix(queryTerms, doc));
		// calcualte the normalizer,
		double normalizer = calcProximityBonusNormalizer(queryTerms.length);
		double score = bonus / normalizer;
		// Using the code from Oliver and Harley to calculate clustering
		return clustering(queryTerms,doc);
		//return score;
	}

	/**
	 * postProcess returns the same value as getRelevance(); 
	 */
	public double postProcess(String queryStrs[], Document2 doc,
			boolean bodyHit, boolean anchorHit, StringBuffer annotation) {
		double score = getRelevance(queryStrs,doc,bodyHit,anchorHit);
		return score; 
	}
	
	/**
	 * Generates an int[][] matrix consisting of the shortest distance in the
	 * document between all term in the query
	 * 
	 * @param queryTerms
	 *            String array with all terms in the query
	 * @param doc
	 *            Document to calculate term proximity bonus on
	 * @return int[][] with the shortest distances between the search terms in
	 *         the document
	 */
	private int[][] calcProximityMatrix(String queryTerms[], Document2 doc) {
		// Create a matrix of correct size to store the position differences
		int[][] proximityMatrix = new int[queryTerms.length][queryTerms.length];

		// Create an help array to use while looping though all values
		ArrayList<int[]> allTermPositions = new ArrayList<int[]>(
				queryTerms.length);

		// Get an int[] from the document with the term position for the current
		// serach term, add it to the array contaning all position
		for (int k = 0; k < queryTerms.length; k++) {
			allTermPositions.add(k, doc.positionsInBodyText(queryTerms[k]));
		}

		// Loop through all occurances for each search term
		for (int i = 0; i < allTermPositions.size(); i++) {
			int[] currrentTermPosArray = allTermPositions.get(i);
			for (int j = 0; j < currrentTermPosArray.length; j++) {
				// Save current position and loop though all occurances again,
				// since the matrix will be symetric, only loop through those
				// fields that are neccissary
				int currentPos = currrentTermPosArray[j];
				for (int k = i /* k = i for symetric matrix */; k < allTermPositions
						.size(); k++) {
					int[] compareTermPosArray = allTermPositions.get(k);
					for (int m = 0; m < compareTermPosArray.length; m++) {
						int comparePos = compareTermPosArray[m];
						// Calculate the distance beween the current position
						// and the current word
						int distance = currentPos - comparePos;
						// If the distance is smaller than the previous shortest
						// distance, save the new distance in the proximity
						// matrix
						if (Math.abs(distance) < Math
								.abs(proximityMatrix[i][k])
								|| proximityMatrix[i][k] == 0) {
							proximityMatrix[i][k] = distance;
						}
					}
				}
			}
		}
		return proximityMatrix;
	}

	/**
	 * This function takes a matrix consisting of shortest distances between
	 * search words and calculates the bonus the document should get. The bonus
	 * is calculated in the following way: for every non zero element in the
	 * matrix, add 1/(1+(element value)^2). Since this generates very small
	 * additional bonus for large values, these are skipped. Calculating this
	 * way favors documents where the words are close to each other but the
	 * bonus rapidly decreases as the words are longer from each other
	 * 
	 * @param proximityMatrix
	 *            int[][] with the shortest distances between the search terms
	 *            in the document
	 * @return the bonus value calculated
	 */
	private double calcProximityBonus(int[][] proximityMatrix) {
		// Start with a bonus of 0.0
		double bonus = 0.0;
		// For all elements in the matrix that contain values
		for (int i = 0; i < proximityMatrix.length; i++) {
			for (int j = i; j < proximityMatrix.length; j++) {
				// If this is a non zero value, smaller than the minimum
				// threshold
				if (Math.abs(proximityMatrix[i][j]) <= PROXIMITY_DISTANCE_LIMIT
						&& proximityMatrix[i][j] != 0) {
					// Add the value to bonus
					bonus += 1.0 / (1+(Math.pow(proximityMatrix[i][j], 2)));
				}
			}
		}
		return bonus;
	}

	/**
	 * Calculates the best value bonus value possible to get with the current
	 * calcProximityBonus function. This is to make use that the bonus always is
	 * between 0 and 1
	 * 
	 * @param numQueryTerms
	 *            Number of terms in the search query
	 * @return maximum amount of bonus that the calcProximityBonus function will
	 *         return
	 */
	private double calcProximityBonusNormalizer(int numQueryTerms) {
		// create a new matrix of correct size
		int[][] normalizerMatrix = new int[numQueryTerms][numQueryTerms];
		// for every element, fill it with the smallest values possible to get
		// when
		// calculating term proximity
		for (int i = 0; i < normalizerMatrix.length; i++) {
			for (int j = i; j < normalizerMatrix.length; j++) {
				normalizerMatrix[i][j] = j - i;

			}
		}
		// calculate the bonus the matrix would get and return it
		return calcProximityBonus(normalizerMatrix);
	}

	/**
	 * Function provided for debug purposes, prints out the proximity matrix in
	 * a human readable format to standard out
	 * 
	 * @param proximityMatrix
	 *            int[][] with the shortest distances between the search terms
	 *            in the document
	 * @param lowerBonusLimit
	 *            to reduce the amount of print outs, it is posible to only
	 *            print a matrix if it got a bonus value higher that this value
	 * @param queryTerms
	 *            String array with all terms in the query
	 * @param doc
	 *            The current document
	 */
	private void printProximityMatrix(int[][] proximityMatrix,
			double lowerBonusLimit, String[] queryTerms, Document2 doc) {

		double bonus = calcProximityBonus(proximityMatrix);
		if (lowerBonusLimit <= bonus) {
			System.out.println("Document URL:" + doc.getURL());
			System.out.println("Document bonus:" + bonus);
			// print headers
			StringBuffer matrixText = new StringBuffer();
			matrixText.append("\t\t");
			for (int i = 0; i < queryTerms.length; i++) {
				matrixText.append(queryTerms[i] + "\t");
			}
			for (int i = 0; i < proximityMatrix.length; i++) {
				matrixText.append("\n" + queryTerms[i] + "\t");
				if (queryTerms[i].length() < 8) {
					matrixText.append("\t");
				}
				for (int j = 0; j < proximityMatrix.length; j++) {
					if (queryTerms[j].length() >= 8) {
						matrixText.append("\t");
					}
					matrixText.append(proximityMatrix[i][j] + "\t");
				}

			}
			System.out.println(matrixText.toString() + "\n");
		}
	}
	
	private double clustering(String[] queryTerms, Document2 doc){
		
		int termOccurences = 0;
		for (int i = 0; i < queryTerms.length; i++){
			termOccurences += doc.bodyFreq(queryTerms[i]);
		}
		int[] allterms = new int[termOccurences];
		int countTerm = 0;
		
		//NOTE: this loop copies all the seperate occurence lists to a single occurence list
		for (int i = 0; i < queryTerms.length; i++){
			int[] thisterm = new int[doc.bodyFreq(queryTerms[i])];
			for (int j = 0; j < thisterm.length; j++){
				allterms[countTerm] = thisterm[j];
			}
		}
		//NOTE: We now have almost sorted array of ints of every occurrence of the any term in the document (allterms)
		Arrays.sort(allterms);
		
		int clustered = 0;
		int clusterDistance = (int)(doc.bodyLength()*CLUSTERING_PERCENT);
		
		if(clusterDistance < 3){
		    // if the cluster distance is set to small (possibly 1 or less if the document is small enough), set it to three
		    clusterDistance = 3;
		}
		
		for (int i = 0 ; i + 1 < allterms.length; i++){
			if((allterms[i+1] - allterms[i]) < clusterDistance){
				clustered++;
			}
		}
		
		double clusteredPercentage = (double)clustered/ (double)termOccurences;
		
	
		return Math.sqrt(clusteredPercentage);
	}
}
