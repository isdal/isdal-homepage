package edu.washington.cse454;

import edu.washington.cse454support.Document2;
import edu.washington.cse454support.DocumentSetInfo2;
import edu.washington.cse454support.IRanker2;

/**
 * Represents a ranker which looks for the query terms in a specific feature 
 * (part of the document) given by the implementing subclasses. The more times
 * the query terms occur within the feature, the higher relevance score it
 * returns.
 * 
 * @author Henrik Jernevad & Tomas Isdal
 */
public abstract class FeatureRanker implements IRanker2 {

	/* (non-Javadoc)
	 * @see edu.washington.cse454support.IRanker#init(edu.washington.cse454support.DocumentSetInfo)
	 * Does not use the info given on initialization.
	 */
	public void init(DocumentSetInfo2 info) {
	}

	/* (non-Javadoc)
	 * @see edu.washington.cse454support.IRanker#getRelevance(java.lang.String[], edu.washington.cse454support.Document)
	 * Returns a relevance score between 0 and 1 which is relative to how many
	 * times the query terms occur in the given document's feature (exact 
	 * feature is specified by implementing subclass).
	 *  
	 * Note: Given a multi-word query, it gives higher relevance to a document 
	 * where many query terms occur a few times in the feature than when a few 
	 * query terms occur many times. 
	 */
	public double getRelevance(String[] queryTerms, Document2 doc, boolean bodyHit, boolean anchorHit) {
		final int termCount = queryTerms.length;
		final String[] featureParts = getFeatureParts(doc);
		double[] termRelevance = new double[termCount];
		// Goes through all terms...
		for (int termIndex = 0; termIndex < termCount; termIndex++) {
			final String term = queryTerms[termIndex];
			termRelevance[termIndex] = 0;
			// ...and all feature parts...
			for (String part : featureParts) {
				// ...and improves the score for the given term if it occurs 
				// in the current part.
				if (part.startsWith(term)) {
					termRelevance[termIndex] += 0.5;
				}
				if (part.endsWith(term)) {
					termRelevance[termIndex] += 0.5;
				}
			}
		}
		// Makes sure that the first few occurrences of each term matters most
		double invertedUrlRelevance = 0;
		for (int t = 0; t < termCount; t++) {
			invertedUrlRelevance += Math.pow(0.15, termRelevance[t]);
		}
		return 1 - (invertedUrlRelevance / termCount);
	}
	
	/**
	 * postProcess returns a double. The higher the value returned, the more
	 * relevant the document.
	 * 
	 * This function is called once for each of the top-N hit documents, as
	 * ranked by results from your getRelevance() function.
	 * 
	 * You can get access to the value you returned for this document in the
	 * earlier getRelevance() call by invoking
	 * IDocument2.getRelevanceScore().
	 */
	public double postProcess(String queryStrs[], Document2 doc,
			boolean bodyHit, boolean anchorHit, StringBuffer annotation) {
		return getRelevance(queryStrs,doc,bodyHit,anchorHit);
	}


	/**
	 * Returns the parts (words/terms) of the specific feature of the given
	 * document which the subclass is interested in.
	 * @param doc the document to rank.
	 * @return the parts of the feature to rank based on.
	 */
	protected abstract String[] getFeatureParts(Document2 doc);

}
