package edu.washington.cse454;

import java.util.Hashtable;
import java.util.Iterator;

import edu.washington.cse454support.Document2;
import edu.washington.cse454support.DocumentSetInfo2;
import edu.washington.cse454support.IRanker2;

/**
 * This ranker combines the other rankers used to maximize the relevance of the
 * returned results, by using weights to balance between the other rankers
 * 
 * @author Oliver Huslid & Tomas Isdal
 */
public class UltimateRanker implements IRanker2 {

	// hashtable to store the weight in, mainly to be clear about what weight
	// thats used for what ranker
	private Hashtable<String, Double> weights = new Hashtable<String, Double>();

	// a ranker that is used for TFIDF calculations on the document body text.
	// The reason for using a capped ranker is to avoud bogus resluts
	private CappedTFIDFRanker cappedRanker = new CappedTFIDFRanker();

	// a ranker that is used for TFIDF calculation on the incoming anchortext,
	// no cap needed in the case
	private TFIDFRanker tfidfRanker = new TFIDFRanker();

	// a ranker that gives a bonus to pages where the search terms are close to
	// each other
	private TermProximityRanker proximityRanker = new TermProximityRanker();

	// a ranker that is called during post processing to add extra rank to pages
	// with one or more of the search terms in the title
	private TitleRanker titleRanker = new TitleRanker();

	// a ranker that is called during post processing to add extra rank to pages
	// with one or more of the search terms in the url
	private URLRanker urlRanker = new URLRanker();

	// the main page rank algorithm
	private PageRank pageRanker = new PageRank();

	private double maxRelevance = 0.0;

	/**
	 * Creates a new ultimate ranker.
	 */
	public UltimateRanker() {
		// Create all the weights
		weights.put("proximity", 1.0);
		weights.put("bodyTFIDF", 2.0);
		weights.put("anchorTFIDF", 2.0);
		weights.put("pagerank", 2.0);
		weights.put("title", 0.5);
		weights.put("url", 0.5);

		for (Iterator iter = weights.values().iterator(); iter.hasNext();) {
			Double weight = (Double) iter.next();
			maxRelevance += weight;
		}
	}

	/**
	 * The init() method is called immediately after the class is created, and
	 * is called only once.
	 * 
	 * It provides your DocumentRanker instance with a DocumentSetInfo object.
	 * This object provides various statistics about the indexed documents and
	 * terms.
	 */
	public void init(DocumentSetInfo2 info) {
		// initiate all rankers
		cappedRanker.init(info);
		tfidfRanker.init(info);
		proximityRanker.init(info);
		titleRanker.init(info);
		urlRanker.init(info);
		pageRanker.init(info);
	}

	/**
	 * getRelevance() returns a double. The higher the value returned, the more
	 * relevant the document.
	 * 
	 * This functions calls the getRelevance() functions in the supporting
	 * rankers and merges their results
	 */
	public double getRelevance(String[] queryTerms, Document2 doc,
			boolean bodyHit, boolean anchorHit) {
		// get the pagerank
		final double pageRank = pageRanker.getRelevance(queryTerms, doc,
				bodyHit, anchorHit);
		// Use capped TFIDF for hits in body
		double bodyTFIDF = 0;
		if (bodyHit) {
			bodyTFIDF = cappedRanker.getRelevance(queryTerms, doc, true, false);
		}
		// Use normal TFIDF in anchortext
		double anchorTFIDF = 0;
		if (anchorHit) {
			anchorTFIDF = tfidfRanker
					.getRelevance(queryTerms, doc, false, true);
		}
		// get the termproximity
		final double proximity = proximityRanker.getRelevance(queryTerms, doc,
				bodyHit, anchorHit);

		// Get relevance from capped body TFIDF, anchor TFIDF, term proximity
		// and pagerank, weighted

		final double relevance = bodyTFIDF * weights.get("bodyTFIDF")
				+ anchorTFIDF * weights.get("anchorTFIDF") + proximity
				* weights.get("proximity") + pageRank * weights.get("pagerank");

		return relevance;
	}

	/**
	 * postProcess returns a double. The higher the value returned, the more
	 * relevant the document.
	 * 
	 * Since this function only is called for a very limited amount of
	 * documents, we use title and url text to inprove results
	 */
	public double postProcess(String queryStrs[], Document2 doc,
			boolean bodyHit, boolean anchorHit, StringBuffer annotation) {

		// Get the post process info from the other documents
		final double pageRank = pageRanker.postProcess(queryStrs, doc, bodyHit,
				anchorHit, annotation);
		// Use capped TFIDF for hits in body
		double bodyTFIDF = 0;
		if (bodyHit) {
			bodyTFIDF = cappedRanker.postProcess(queryStrs, doc, true, false,
					annotation);
		}
		// Use normal TFIDF in anchortext
		double anchorTFIDF = 0;
		if (anchorHit) {
			anchorTFIDF = tfidfRanker.postProcess(queryStrs, doc, false, true,
					annotation);
		}
		// get the termproximity score
		final double proximity = proximityRanker.postProcess(queryStrs, doc,
				bodyHit, anchorHit, annotation);
		// get the title score
		final double title = titleRanker.postProcess(queryStrs, doc, bodyHit,
				anchorHit, annotation);
		// get the url score
		final double url = urlRanker.postProcess(queryStrs, doc, bodyHit,
				anchorHit, annotation);
		// merge all scores with weights
		final double postRelevance = bodyTFIDF * weights.get("bodyTFIDF")
				+ anchorTFIDF * weights.get("anchorTFIDF") + proximity
				* weights.get("proximity") + pageRank * weights.get("pagerank")
				+ url * weights.get("url") + title * weights.get("title");

//		 System.out.println(doc.getDocId() + "\t" + anchorTFIDF + "\t"
//		 + bodyTFIDF + "\t" + proximity + "\t" + pageRank + "\t" + url
//		 + "\t" + title + "\t" + doc.getURL());
		return postRelevance;

	}

}
