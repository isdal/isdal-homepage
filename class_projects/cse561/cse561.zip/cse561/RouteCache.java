import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

public class RouteCache implements CSE561_Settings {

	private Hashtable<Byte, NetworkRoute> routeCache;

	private Byte myAddr;

	public RouteCache(Byte myAddr) {
		if(myAddr == -1){
			return;
		}
		routeCache = new Hashtable<Byte, NetworkRoute>();
		this.myAddr = myAddr;
		RoutePath rp = new RoutePath();
		rp.add(myAddr);
		addPath(rp);
		rp = new RoutePath();

//		rp.add((byte) 8);
//		rp.add((byte) myAddr);
//		rp.add((byte) 7);
////		addPath(rp);
//////		rp = new RoutePath();
////
//		rp.add((byte) 9);
//		rp.add((byte) myAddr);
//		rp.add((byte) 10);
//		rp.add((byte) 11);
//		rp.add((byte) 12);
//		rp.add((byte) 13);
//		addPath(rp);
	}

	public void addPath(RoutePath[] paths) {
		for (int i = 0; i < paths.length; i++) {
			addPath(paths[i]);
		}
	}

	public void addPath(RoutePath path) {
		if (path.size() == 0) {
			return;
		}
		System.out.print("RC: \n" + toString());
		// System.out.print("RC: Trying to add: " + path.toString());
		// System.out.println("RC: Target is: " + path.getTarget()
		// + " my addr is " + myAddr);
		if ((path.getTarget() == myAddr)) {
			// System.out.println("RC: Invert!!!");
			path = path.invertPath();
			// System.out.print("RC: New path: " + path.toString());
		}
		// handle special case when myaddr is in path

		if (path.containsInPath(myAddr)) {
			addPath(path.split(myAddr));

		} else if (path.getSource() == myAddr) {

			if (routeCache.containsKey(path.getTarget())) {
//				System.out.print("RC: Target exists, adding path: "
//						+ path.toString());
				routeCache.get(path.getTarget()).addPath(path);
				if(USE_GUI)GUI_CrappyGui.getInstance().updateRouteCache(this);
			} else {
//				System.out.print("RC: New target, adding path: "
//						+ path.toString());
				NetworkRoute route = new NetworkRoute(myAddr);
				route.addPath(path);
				routeCache.put(path.getTarget(), route);
				if(USE_GUI)GUI_CrappyGui.getInstance().updateRouteCache(this);
			}
			addPath(path.getSubPath());

		} else {
			System.err.println("RC: Self (" + myAddr + ") not in route");
		}

	}

	public Byte nextHop(int destint) {
		Byte dest = (byte) destint;
		// System.out.print(routeCache.toString());
		if (routeCache.containsKey(dest)) {
			return routeCache.get(dest).getNextHop(dest);
		}
		return (byte) -1;
	}
	
	public RoutePath getNodePath(int destint){
		Byte dest = (byte) destint;
		if (routeCache.containsKey(dest)) {
			return routeCache.get(dest).getNodePath(dest);
		}
		return null;
	}

	public void flushLink(int node1, int node2) {
		for (Iterator path = routeCache.values().iterator(); path.hasNext();) {
			NetworkRoute route = (NetworkRoute) path.next();
			route.flushLink((byte) node1, (byte) node2);
		}
		if(USE_GUI)GUI_CrappyGui.getInstance().updateRouteCache(this);
	}

	public String toString() {
		StringBuffer str = new StringBuffer();
		str.append("Currently in routecache for node: " + myAddr + "\n");
		for (Iterator iter = routeCache.keySet().iterator(); iter.hasNext();) {
			Byte key = (Byte) iter.next();
			str.append("Routes to node: " + key + "\n");
			str.append(routeCache.get(key).toString());
		}
		return str.toString();
	}

	public String getNextHops() {
		StringBuffer str = new StringBuffer();
		str.append("Nexthops for node: " + myAddr + "\n");
		for (Iterator iter = routeCache.keySet().iterator(); iter.hasNext();) {
			Byte key = (Byte) iter.next();
			str.append("Nexthop to node: " + key + " = ");
			str.append(nextHop((int) key) + "\n");
		}
		return str.toString();
	}

	public Hashtable<Byte, NetworkRoute> getRoutes() {
		return routeCache;
	}
	
	public int getMyAddr(){
		return (int)myAddr;
	}

}
