
public class ApplicationLayerData {
	private int dest;
	private BitArray data;
	
	public ApplicationLayerData(int dest,BitArray data) {
		this.data=data;
		this.dest=dest;
	}
	public int getDest(){
		return dest;
	}
	public BitArray getData(){
		return data;
	}

}
