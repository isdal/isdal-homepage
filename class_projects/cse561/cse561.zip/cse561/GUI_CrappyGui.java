import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Calendar;
import java.util.HashMap;
import java.util.TimeZone;

import javax.swing.JFrame;
import javax.swing.JSplitPane;

@SuppressWarnings("serial")
public class GUI_CrappyGui extends JFrame {

	public static GUI_CrappyGui mySingleton = new GUI_CrappyGui("LessCrappyGui");

	private static int myAddr;

	private static ApplicationLayer applicationLayer;

	private GUI_GraphPanel graphPanel;

	private GUI_ChatPanel chatPanel;

	private GUI_DebugMessagePanel debugMessagePanel;

	private HashMap<Integer, Integer> linkSpeeds = new HashMap<Integer, Integer>();;

	private GUI_CrappyGui(String title) {
		super.setTitle(title);
	}

	public static GUI_CrappyGui getInstance() {
		return mySingleton;
	}

	public static GUI_CrappyGui getInstance(int addr, ApplicationLayer al) {
		applicationLayer = al;
		myAddr = addr;
		return mySingleton;
	}

	protected void frameInit() {
		this.setPreferredSize(new Dimension(1024, 768));
		super.frameInit();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(new GridLayout(1, 1));

		// Add the message panel
		chatPanel = new GUI_ChatPanel();

		// Add the graph panel
		graphPanel = new GUI_GraphPanel();

		// Create the Chat/Graph scroll pane
		JSplitPane chatGraphPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				chatPanel, graphPanel);

		chatGraphPane.setDividerLocation(1.0 / 4.0);
		chatGraphPane.setResizeWeight(1.0 / 4.0);

		debugMessagePanel = new GUI_DebugMessagePanel();

		// Create the Chat/Graph/message split pane
		JSplitPane allSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				chatGraphPane, debugMessagePanel);

		allSplitPane.setDividerLocation(3.0 / 4.0);
		allSplitPane.setResizeWeight(3.0 / 4.0);

		add(allSplitPane);

		// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		this.pack();
		this.setVisible(true);
	}

	public void setLinkSpeeds(HashMap<Integer, Integer> speeds) {
		this.linkSpeeds = speeds;
		graphPanel.updateRouteCache();
	}
	

	public int getLinkSpeed(int node) {
//		switch (node) {
//		case 7:
//			return 0;
//		case 8:
//			return 1;
//		case 9:
//			return 2;
//		}

		if (linkSpeeds.get(node) != null) {
			System.err.println(" speed: " + linkSpeeds.get(node));
			return linkSpeeds.get(node);
		}
		// System.err.println(" speed: " + 0);
		return -1;
	}

	public void send(int addr, byte[] data) {
		applicationLayer.send(addr, new BitArray(data));
	}

	public void updateRouteCache(RouteCache rc) {
		graphPanel.updateRouteCache(rc);
	}

	public void printPhyMessage(String message) {
		if (message.indexOf("\n") != -1) {
			debugMessagePanel.printPhyMessage(message.substring(0, message
					.indexOf("\n")));
			debugMessagePanel.printPhyMessage("\n" + getTime());
			if (message.indexOf("\n") == message.length() - 1) {
				return;
			}
			printPhyMessage(message.substring(message.indexOf("\n") + 1));
		} else {
			debugMessagePanel.printPhyMessage(message);
		}

		// debugMessagePanel.repaint();
	}

	public void printMacMessage(String message) {
		debugMessagePanel.printMacMessage(getTime() + " - " + message);
	}

	public void printNetMessage(String message) {
		debugMessagePanel.printNetMessage(getTime() + " - " + message);
	}

	public void printDataMessage(String message) {
		chatPanel.printMessage(getTime() + " - " + message + "\n");
	}

	public String getTime() {

		Calendar cal = Calendar.getInstance(TimeZone.getDefault());

		String DATE_FORMAT = "HH:mm:ss";
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(
				DATE_FORMAT);
		/*
		 * * on some JDK, the default TimeZone is wrong * we must set the
		 * TimeZone manually!!! * sdf.setTimeZone(TimeZone.getTimeZone("EST"));
		 */
		sdf.setTimeZone(TimeZone.getDefault());

		return sdf.format(cal.getTime());

	}

	public void setChannelState(boolean channelIdle) {
		debugMessagePanel.setChannelState(channelIdle);
		debugMessagePanel.repaint();
	}
	
	public void setSendingState(boolean isSending) {
		debugMessagePanel.setSendingState(isSending);
		debugMessagePanel.repaint();
	}
	
	public void initializeBackoff(int c) {
		debugMessagePanel.initializeBackoff(c);
	}
	
	public void setCurrentBackoff(int c) {
		debugMessagePanel.setCurrentBackoff(c);
	}
}
