/*
 * Created on Oct 7, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author isdal
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class MacPacket implements CSE561_Settings {
    // Source and destination adress
    //private int srcAddr=0;
    //private int dstAddr=0;
  
    // Length of the data field, in bytes
    //private int dataLength=0;

    // Packet sequence number
    //private int seqNum=0;

    // Packet data
    //private byte[] data;

    // Assembled packet as a BitSet
    private BitArray packet;

    // CRC calulated using CRC16
    //private int crc;

    /**
	 * Constructor from existing data
	 * 
	 * @param srcAddr
	 *            packet source address
	 * @param dstAddr
	 *            packet destination address
	 * @param seqNum
	 *            packet sequence number
	 * @param data
	 *            packet data
	 */
    public MacPacket(int srcAddr, int dstAddr, int seqNum, byte[] data) {
        // Length of whole packet, in bytes
        // System.out.println("length: " + packetLength);
        packet = new BitArray();// (packetLength * 8));
        
        // Insert the source adress bits
        packet.add(srcAddr, ADDRESS_FIELD_BITS);
        
        // Insert the destination adress bits
        packet.add(dstAddr, ADDRESS_FIELD_BITS);
        //System.out.println("packet:" + getDataLength());

        // Insert the length bits
        //System.out.println("Data length: " + data.length);
        packet.add(data.length * 8, LENGTH_FIELD_BITS);
        //System.out.println("packet:" + getDataLength());

        // Insert the sequence number bits
        packet.add(seqNum, SEQ_FIELD_BITS);
        //System.out.println("packet:" + getDataLength());

        // Insert the data bits
        packet.add(data);
        //System.out.println("packet:" + getDataLength());
        addCRC(packet);
   }
    
    public MacPacket(int srcAddr, int dstAddr, int seqNum, BitArray data) {
        // Length of whole packet, in bytes
        // System.out.println("length: " + packetLength);
        packet = new BitArray();// (packetLength * 8));
        
        // Insert the source adress bits
        packet.add(srcAddr, ADDRESS_FIELD_BITS);
        
        // Insert the destination adress bits
        packet.add(dstAddr, ADDRESS_FIELD_BITS);
        //System.out.println("packet:" + getDataLength());

        // Insert the length bits
        //System.out.println("Data length: " + data.size / 8);
        packet.add(data.length(), LENGTH_FIELD_BITS);
        

        // Insert the sequence number bits
        packet.add(seqNum, SEQ_FIELD_BITS);
        //System.out.println("packet:" + getDataLength());
        
        // Insert the data bits
        packet.add(data);
        //System.out.println("packet:" + getDataLength());
        addCRC(packet);
        //System.out.println("packet:" + getDataLength());
   }
    
    //for receiver
    public MacPacket(int srcAddr, int dstAddr, int seqNum, byte[] data, int CRC) {
        // Length of whole packet, in bytes
        // System.out.println("length: " + packetLength);
        packet = new BitArray();// (packetLength * 8));
        
        // Insert the source adress bits
        packet.add(srcAddr, ADDRESS_FIELD_BITS);
        // System.out.println("packet:" + packet.toString());

        // Insert the destination adress bits
        packet.add(dstAddr, ADDRESS_FIELD_BITS);
        // System.out.println("packet:" + packet.toString());

        // Insert the length bits
        packet.add(data.length * 8, LENGTH_FIELD_BITS);
        // System.out.println("packet:" + packet.toString());

        // Insert the sequence number bits
        packet.add(seqNum, SEQ_FIELD_BITS);
        // System.out.println("packet:" + packet.toString());

        // Insert the data bits
        packet.add(data);
        // System.out.println("packet:" + packet.toString());
        packet.add(CRC, CRC_FIELD_BITS);
        // System.out.println("packet:" + packet.toString());
    }
    
    /**
	 * Constructor: create a new empty packet
	 */
    public MacPacket(){
    	packet = new BitArray();
    }
 	
	/**
	 * Append a bit the the end of the packet
	 * 
	 * @param bit
	 *            value of the bit to append
	 */
	public void addBit(boolean bit){
		packet.add(bit);
	}

	private void addCRC(BitArray pkt){
		int crc = (int)CRC8.calc(pkt.toByteArray(),pkt.toByteArray().length);
		pkt.add(crc,CRC_FIELD_BITS);
	}

	public boolean checkCRC(){
		byte[] packetData = packet.getByteArray(0,packet.length()-CRC_FIELD_BITS);
		byte packetCRC = packet.getLastByte();
		// System.out.println("packet crc" + packetCRC);
		byte packetDataCRC = CRC8.calc(packetData,packetData.length);
		// System.out.println("packet data crc" + packetDataCRC);
		return (packetCRC == packetDataCRC);
	}

	/**
	 * Set data length
	 * 
	 */
	
	
	
	public boolean headerSent(){
		return (packet.length() >= HEADER_LENGTH);
	}

	/**
	 * 
	 * @return true if it is an ACK packet, false otherwise
	 */
	public boolean isACK(){
		return getDataLength() == 0;
	}

	/**
	 * 
	 * @return total length of packet, including header and crc
	 */
	public int length(){
		return packet.length();
	}

	/**
	 * Get packet payload as byte[] 
	 * 
	 */
    public byte[] getData(){
    	return packet.getByteArray(HEADER_LENGTH,packet.length()-HEADER_LENGTH-CRC_FIELD_BITS);
    	
    }
    /**
     * Returns the packet payload as an BitArray
     * @return packet payload
     */
    public BitArray getPayload(){
    	return packet.getBitArray(HEADER_LENGTH,packet.length()-CRC_FIELD_BITS);
    }
    /**
	 * Data length access function
	 * 
	 */
    public int getDataLength(){
    	if(headerSent()){
    		return packet.getInt(2*ADDRESS_FIELD_BITS,LENGTH_FIELD_BITS);
    	} 
    	return -1;
    }
    
    /**
	 * Get the value of a bit at specified position.
	 * 
	 * @param index
	 *            position
	 * @return value of bit at specified position
	 */
    public boolean getBit(int index){
    	    	return packet.get(index);
    }
    /**
     * 
     * @return returns the source address from the packet
     */
    public int getSourceAddr()
    {
    	if(headerSent()){
    		 return packet.getInt(0,ADDRESS_FIELD_BITS);
    	} 
    	return -1;
    }
    
    /**
     * 
     * @return returns the destination address from the packet
     */
    public int getDestAddr()
    {if(headerSent()){
    	return packet.getInt(ADDRESS_FIELD_BITS,ADDRESS_FIELD_BITS);
	} 
	return -1;
    	
    }
    
    public int getSeqNumber()
    {
    	return packet.getInt(2*ADDRESS_FIELD_BITS+LENGTH_FIELD_BITS,SEQ_FIELD_BITS);
    }

    

   
    
    
    public void printPacket() {
    	System.out.println("srcAddr "+getSourceAddr());
    	System.out.println("dstAddr "+getDestAddr());
    	System.out.println("dataLength "+getDataLength());
    	System.out.println("seqNum "+getSeqNumber());
    	
    	byte data[] = getData();
    	if (data != null) {
    		System.out.println("data ");
    		for (int i=0;i<getDataLength();i++)
    			System.out.println(toStringRep(data[i]));
    	}
    	else
    		System.out.println("data null");
    	System.out.println("packet "+packet.toString());
    	
    }
    
    private String toStringRep(byte numm) {/* after toString then byte number change what type of string?*/ 
        byte binBit = 1;
        int bz = 0;
        String bitStr = "";

        for (; bz < 8; bz++) {
            if ((numm & binBit) != 0) // how does num AND with binBit?.
             {
                bitStr = "1" + bitStr; /* what it is mean by Prepend the String "1" to bitStr?*/
            } else {
                bitStr = "0" + bitStr;
            }

            binBit <<= 1; // why Shift Bit left 1?
        }

        return bitStr; // return the String
    }
    
    public String toString(){
    	return packet.toString();
    }

}


