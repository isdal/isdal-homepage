
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;

@SuppressWarnings("serial")
class GUI_DebugMessagePanel extends JPanel {

	
	private Color darkGreen = new Color(0,64,0);
	private Color lightGreen = new Color(0,128,0);
	private Color green = Color.GREEN;
	private Color darkRed = new Color(64,0,0);
	private Color lightRed = new Color(128,0,0);
	private Color red = Color.RED;
	
	private JTextArea phyMessages = new JTextArea();

	private JTextArea macMessages = new JTextArea();

	private JTextArea netMessages = new JTextArea();

	private JDrawingPanel channelStatus = new JDrawingPanel();
	private JBackoffPanel backoffState = new JBackoffPanel();
	
	public GUI_DebugMessagePanel() {

		setLayout(new GridLayout(1, 1));
		Dimension minimumSize = new Dimension(100, 20);

		JPanel phyPanel = new JPanel();
		JPanel macPanel = new JPanel();
		JPanel netPanel = new JPanel();

		channelStatus.setBackground(Color.WHITE);

		phyPanel.setLayout(new BorderLayout());
		macPanel.setLayout(new BorderLayout());
		netPanel.setLayout(new BorderLayout());
		
		phyMessages.setEditable(false);
		macMessages.setEditable(false);
		netMessages.setEditable(false);

		JScrollPane phyScroll = new JScrollPane(phyMessages);
		JScrollPane macScroll = new JScrollPane(macMessages);
		JScrollPane netScroll = new JScrollPane(netMessages);

		phyPanel.add(new JLabel("Physical Layer Messages"), BorderLayout.NORTH);
		phyPanel.add(channelStatus, BorderLayout.SOUTH);
		macPanel.add(new JLabel("Mac Layer Messages"), BorderLayout.NORTH);
		
		macPanel.add(backoffState, BorderLayout.SOUTH);
		netPanel.add(new JLabel("Network Layer Messages"), BorderLayout.NORTH);

		phyPanel.add(phyScroll,BorderLayout.CENTER);
		macPanel.add(macScroll,BorderLayout.CENTER);
		netPanel.add(netScroll,BorderLayout.CENTER);

		JSplitPane phyMacPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				macPanel, phyPanel);
		JSplitPane netRestPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				netPanel, phyMacPane);

		phyMacPane.setOneTouchExpandable(true);
		netRestPane.setOneTouchExpandable(true);
		phyMacPane.setDividerLocation(0.5);
		netRestPane.setDividerLocation(2.0 / 3.0);

		phyMacPane.setResizeWeight(0.5);
		netRestPane.setResizeWeight(1.0 / 3.0);

		// Provide minimum sizes for the two components in the split pane.
		phyScroll.setMinimumSize(minimumSize);
		macScroll.setMinimumSize(minimumSize);
		netScroll.setMinimumSize(minimumSize);
		// Provide a preferred size for the split pane.
		// phyMacPane.setPreferredSize(new Dimension(400, 200));
		// netRestPane.setPreferredSize(new Dimension(400, 200));

		add(netRestPane);
	}

	public void printPhyMessage(String message) {
		
		phyMessages.append(message);
		phyMessages.setCaretPosition(phyMessages.getDocument().getLength());

	}

	public void printMacMessage(String message) {
		macMessages.append(message);
		macMessages.setCaretPosition(macMessages.getDocument().getLength());

	}

	public void printNetMessage(String message) {
		netMessages.append(message);
		netMessages.setCaretPosition(netMessages.getDocument().getLength());

	}

	public void setChannelState(boolean channelIdle) {
		if (channelIdle) {
			channelStatus.col1 = darkGreen;
			channelStatus.col2 = lightGreen;
			// channelStatus.setBackground(Color.GRAY);
			// channelStatus.setText("Idle");
		} else {
			channelStatus.col1 = lightGreen;
			channelStatus.col2 = green;
			// channelStatus.setBackground(Color.GREEN);
			// channelStatus.setForeground(Color.GREEN);
			// channelStatus.setText("Busy");
		}

		channelStatus.repaint();
	}


	class JDrawingPanel extends JPanel {
		Color col1 = darkGreen;
		Color col2 = lightGreen;
		Color sendCol1 = darkRed;
		Color sendCol2 = lightRed;
		
		int p1 = 4, p2 = 12;
		int q1 = 16, q2 = 24;
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2d = (Graphics2D)g;	
//			g2d.drawRect(0, 0, 8, 8);
			GradientPaint gradient = new GradientPaint(p1,0,col1, (p1+p2)/2,0, col2, true);
			g2d.setPaint(gradient);
			g2d.fillRect(p1, 0, p2-p1, 8);

			gradient = new GradientPaint(q1,0,sendCol1, (q1+q2)/2,0, sendCol2, true);
			g2d.setPaint(gradient);
			g2d.fillRect(q1, 0, q2-q1, 8);
		}
		
	}

	class JBackoffPanel extends JPanel {
		Color c1 = green;//lightRed;
		Color c2 = red;//lightGreen;
		
		int initialBackoffCounter = 8;
		int currentBackoff = 0;
		
		public void paintComponent(Graphics g)
		{
			Graphics2D g2d = (Graphics2D)g;
			g.setColor(Color.black);
			g.clearRect(0,0,400,12);
			g.fillRect(2,0,160,10);
			g.drawString("Backoff: " + currentBackoff, 165, 10);
			g.setColor(Color.white);
			g.fillRect(4,2,156,6);
			
			GradientPaint gradient = new GradientPaint(
					2,0,c1,162,0,c2);
			g2d.setPaint(gradient);
			g2d.fillRect(4,2,156*currentBackoff/initialBackoffCounter,6);
		}
	}
	
	public void initializeBackoff(int c)
	{
		backoffState.initialBackoffCounter = c;
		backoffState.repaint();
	}
	
	public void setCurrentBackoff(int c)
	{
		backoffState.currentBackoff = c;
		backoffState.repaint();
	}
	
	public void setSendingState(boolean isSending) {
		if( isSending )
		{
			channelStatus.sendCol1 = lightRed;
			channelStatus.sendCol2 = red;
		}
		else
		{
			channelStatus.sendCol1 = darkRed;
			channelStatus.sendCol2 = lightRed;
		}
		channelStatus.repaint();
	}
}