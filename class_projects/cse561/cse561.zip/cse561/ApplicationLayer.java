import java.util.concurrent.LinkedBlockingQueue;

public class ApplicationLayer implements CSE561_Settings {
	NetworkLayer network;

	private LinkedBlockingQueue<ApplicationLayerData> sendBuffer = new LinkedBlockingQueue<ApplicationLayerData>();

	private LinkedBlockingQueue<ApplicationLayerData> receiveBuffer = new LinkedBlockingQueue<ApplicationLayerData>();
	
	private int myAddr;

	public void setAddr(int myAddr) {
		this.myAddr = myAddr;
		network = new NetworkLayer(myAddr, this);

	}
	
	public int getMyAddr(){
		return myAddr;
	}

	public void send(int dest, BitArray data) {
		if (data.length() > MAX_PACKET_SIZE + 40) {
			System.err.println("Big packet, splitting");
			send(dest, data.getBitArray(0, MAX_PACKET_SIZE));
			send(dest, data.getBitArray(MAX_PACKET_SIZE, data.length()));
		} else {
			// receiveBuffer.add(data);
			sendBuffer.add(new ApplicationLayerData(dest, data));
		}

	}
	
	public ApplicationLayerData getData() throws InterruptedException {
		return sendBuffer.take();
	}

	public void putData(ApplicationLayerData data) {
		receiveBuffer.add(data);
	}

	public ApplicationLayerData receive() throws InterruptedException {
		return receive(new ApplicationLayerData(-1,new BitArray()));

	}

	private ApplicationLayerData receive(ApplicationLayerData data) throws InterruptedException {
		ApplicationLayerData nextData = receiveBuffer.take();
		data.getData().add(nextData.getData());
		if (nextData.getData().length() == MAX_PACKET_SIZE) {
			System.err.println("Received splitted packet, mergeing");
			return receive(data);
		}
		return data;
	}

}
