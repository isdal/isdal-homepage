import java.io.*;
import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.TargetDataLine;

public class Receiver extends Thread implements CSE561_Settings {

	/**
	 * Local class variables
	 */

	// audio
	private TargetDataLine m_line;

	private boolean workCompleted = false;

	private AudioInputStream m_audioInputStream;

	private BufferedInputStream m_bufferedAIS;
	
	private Channel channel_data;

	// synchronization variables
	private int current_clock = -1;

	private int signal_count = 0;

	private int nosignal_count = 0;

	private boolean no_signal = true;

	private final int LIMIT = (int) Math.round(Math.floor(NUM_SAMPLES / 4));

	private final int[] transition_incomplete = new int[NUM_CHANNELS];

	private int sync_count = 0;

	private boolean just_saw_sync = false;

	// this is the offset into the buffer from which point we start the fft
	// it should be useful to adjust sync so as to get only a single wave
	// in the fft duration, and avoid boundaries
	private int offset = 0;

	// Integer linked list with received data
	// private LinkedList received_data = new LinkedList();
	private LinkedBlockingQueue<Integer> received_data = new LinkedBlockingQueue<Integer>();

	// output arrays, contain bits to pass up the stack
	Integer out[] = new Integer[NUM_CHANNELS];

	Integer f_out[] = new Integer[NUM_CHANNELS];

	// Mac Layer Variables
	private boolean channelIdle = true;

	private MacLayer macLayer;

	// Averaging Histories
	private LinkedList noise_history;

	private LinkedList peak_history;

	private LinkedList clock_history;

	private double NOISE_HISTORY = 1;

	private double PEAK_HISTORY = NUM_SAMPLES;

	private double CLOCK_HISTORY = NUM_SAMPLES;

	private int average_count = 0;

	private int average_offset = 0;

	// debugging => file output if debug=5
	// Beware: lots of file I/O
	// For each channel (C) prints out resulting fft values
	// File "chC_0.txt" for frequency 0
	// File "chC_1.txt" for frequency 1
	private PrintStream[][] prout = new PrintStream[NUM_CHANNELS][2];

	private PrintStream[][] prout1 = new PrintStream[NUM_CHANNELS][2];

	// debugging output file
	private PrintStream output_file;

	private PrintStream output_file1;

	/**
	 * Access Function
	 */
	public boolean isBitAvailable() {
		if (received_data.isEmpty())
			return false;
		else
			return true;
	}

	/**
	 * Access Function
	 * 
	 * @throws InterruptedException
	 */
	public Integer getBit() throws InterruptedException {
		Integer bit;
		bit = received_data.take();
		return bit;

	}

	/**
	 * Constructor Used to initialize local class variables when the class is
	 * declared
	 */
	public Receiver(MacLayer macLayer) {
		this.setPriority(10);
		this.macLayer = macLayer;
		AudioFormat audioFormat = new AudioFormat(
				AudioFormat.Encoding.PCM_SIGNED, RECV_SAMPLE_RATE,
				RECV_SAMPLE_SIZE_IN_BITS, RECV_CHANNELS, RECV_FRAME_SIZE,
				RECV_FRAME_RATE, ENDIAN_STYLE);

		/*
		 * Now, we are trying to get a TargetDataLine. The TargetDataLine is
		 * used later to read audio data from it. If requesting the line was
		 * successful, we are opening it (important!).
		 */
		DataLine.Info info = new DataLine.Info(TargetDataLine.class,
				audioFormat);

		try {
			m_line = (TargetDataLine) AudioSystem.getLine(info);
			m_line.open(audioFormat, (int) (RECV_SAMPLE_RATE / SEND_BAUD_RATE));
		} catch (LineUnavailableException e) {
			System.out.println("unable to get a recording line");
			e.printStackTrace();
			System.exit(1);
		}
		
		channel_data = new Channel();

		for (int i = 0; i < NUM_CHANNELS; i++)
			transition_incomplete[i] = 0;

		m_audioInputStream = new AudioInputStream(m_line);
		m_bufferedAIS = new BufferedInputStream(m_audioInputStream);

		for (int i = 0; i < NUM_CHANNELS; i++)
			f_out[i] = null;

		noise_history = new LinkedList();
		peak_history = new LinkedList();
		clock_history = new LinkedList();

		// debugging output
		try {
			output_file = new PrintStream(new FileOutputStream("output.txt"));
			output_file1 = new PrintStream(new FileOutputStream("output1.txt"));
		} catch (Exception e) {
			System.out.println("Error opening an output file.");
			System.exit(-1);
		}
		// debugging output
		if (debug >= 4) {
			try {
				// create files
				for (int i = 0; i < NUM_CHANNELS; i++)
					for (int j = 0; j <= 1; j++) {
						prout[i][j] = new PrintStream(new FileOutputStream("ch"
								+ i + "_" + j + ".txt"));
						prout1[i][j] = new PrintStream(new FileOutputStream(
								"chav" + i + "_" + j + ".txt"));
					}
			} catch (Exception e) {
				System.out.println("Error opening a debugging file.");
				System.exit(-1);
			}
		}

	}

	/**
	 * Starts the recording. To accomplish this, (i) the line is started and
	 * (ii) the thread is started.
	 */
	public void start() {
		/* Starting the TargetDataLine. */
		if (m_line != null)
			m_line.start();
		else {
			System.out.println("Line object does not exist");
			System.exit(-1);
		}

		workCompleted = false;

		/* Starting the thread. Calls run() */
		super.start();
	}

	/** Stops the recording. */
	public void stopRecording() {
		workCompleted = true;
		m_line.stop();
		m_line.close();
		output_file.close();
		output_file1.close();
		// debugging
		if (debug >= 4) {
			for (int i = 0; i < NUM_CHANNELS; i++) {
				// close files
				prout[i][0].close();
				prout[i][1].close();
				prout1[i][0].close();
				prout1[i][1].close();
			}
		}
	}

	/**
	 * Main working method. We are processing samples of audio data read from
	 * the speaker, FFT_LENGTH bytes at a time. We are expecting the following
	 * channels: Channel 0: SYNC channel (one frequency FREQS[0][0]) Channel 1:
	 * CLOCK channel (two frequencies, FREQS[1][0] and FREQS[1][1]) Channel 2
	 * through i: DATA channels (FREQS[i][] and FREQS[i][1])
	 * 
	 * For each sample we are watching the for clock transitions to tell us that
	 * we can read a new bit from the data channels.
	 */
	public void run() {

		int numBytesRead;

		while (!workCompleted) {

			try {

				// Prepare a byte array for reading in raw data
				byte[] data = new byte[FFT_LENGTH];

				// Read the next chunk of data from the TargetDataLine.
				numBytesRead = m_bufferedAIS.read(data, 0, FFT_LENGTH);

				// prepare a doubles array for amplitude values
				double[] amps = new double[FFT_LENGTH];

				// Corner Case: when we stop the recording,
				// the last set may not get the full buffer
				if (offset + amps.length > numBytesRead) {
					System.out.println("Bytes Read = " + numBytesRead
							+ " offset = " + offset + " length = "
							+ amps.length);
					continue;
				}

				// Convert bytes array to amplitude values
				for (int i = offset; i < offset + amps.length; i++) {
					amps[i] = (double) data[i];
				}

				// Apply a hamming window
				hamming(amps);

				// Prepare data for FFT
				double[] realout = new double[amps.length];
				double[] imgout = new double[amps.length];
				double[] angleout = new double[amps.length];
				double[] magnitude = new double[amps.length];

				// Perform FFT Transformation
				Transform.fft(amps, realout, imgout, angleout, magnitude);

				// Create an array to hold the values of frequency extraction
				// Each value represents a signal extracted for a particular
				// channel
				int[] channels = new int[NUM_CHANNELS];
				int clock = extractClock(magnitude);
				extractFreqs(magnitude, channels);

				// Determine if the clock transitioned
				int transition = detect_transition(clock);

				// Determine if we're ready to average
				boolean needAvg = needToAverage(transition);

				analyze_fft_results(channels, needAvg);

				// set f_out
				for (int j = 0; j < NUM_CHANNELS; j++) {
					if (out[j].intValue() != -1)
						f_out[j] = out[j];

					if (j >= 2) {
						if (out[1].intValue() != -1) {
							if (out[j].intValue() == -1) {
								output_file.print("x");
								output_file1.print("" + j);
							}
						}
					}

				}

				if (needAvg) {
					// up the stack
					// sync channel
					if (f_out[0] != null) {
						output_file.print(f_out[0].toString());
						// received_data.add(f_out[0]); // ready to go up the
						received_data.put(f_out[0]);
						// stack
					}
					// data channels
					else {
						for (int channel = 2; channel < NUM_CHANNELS; channel++) {
							if (f_out[channel] != null) {
								output_file.print(f_out[channel].toString());
								output_file1.print("" + channel);
								// received_data.add(f_out[channel]); // ready
								// to
								received_data.put(f_out[channel]); // go up the
								// stack
							}
							else {
								received_data.put(-1);
							}
						}
					}
					for (int i = 0; i < NUM_CHANNELS; i++) {
						f_out[i] = null;
					}
				}
			} catch (Exception e) {
				System.out.println("Receiver Input Exception");
				e.printStackTrace();
				System.exit(-1);
			}
		} // end while(work_not_completed)
	} // end run()

	/** Hamming Window */
	private void hamming(double[] time_data) {
		for (int i = 0; i < time_data.length; i++) {
			time_data[i] *= (0.54 - 0.46 * Math.cos(2 * Math.PI * i
					/ (time_data.length - 1)));
		}
	}

	private boolean needToAverage(int transition) {

		boolean compute_average = false;
		average_offset = 0;

		if (transition == 1) {
			if (average_count <= 0)
				average_count = NUM_SAMPLES / 2;
			else {
				compute_average = true;
				average_offset = NUM_SAMPLES / 2 - average_count + 1;
				average_count = NUM_SAMPLES / 2;
			}
		} else {
			average_count--;
			if (average_count > 0) {
				compute_average = false;
			} else if (average_count == 0) {
				compute_average = true;
				average_offset = 1;
			} else if (average_count < 0) {
				compute_average = false;
			}

		}

		return compute_average;
	}

	/** Analyze FFT Results in channels array */
	void analyze_fft_results(int[] channels, boolean needAvg) {

		for (int i = 0; i < NUM_CHANNELS; i++) {

			out[i] = new Integer(-1);

			if (needAvg) {

				channels[i] = getAvgResult(i);

				// debug
				if (debug >= 4) {
					prout[i][0].print("\n*\t");
					prout[i][1].print("\n*\t");
					prout1[i][0].print("\n*\t");
					prout1[i][1].print("\n*\t");
				}
				// SYNC CHANNEL
				if (i == 0) {
					if (channels[0] == 0) {
						sync_count++;
						if (debug >= 3)
							System.err.print("2");
					} else {
						just_saw_sync = false;
						sync_count = 0;
					}

					if (sync_count == 2) {
						out[0] = new Integer(2);
						just_saw_sync = true;
					}

					if (sync_count > 2 && just_saw_sync == true) {
						out[0] = new Integer(2);
					}
				}
				// DATA CHANNELS
				else if (i >= 2) {
					out[i] = new Integer(channels[i]);
					if (debug >= 3)
						if (out[i] == -1) {
							System.err.print("x");
						} else {
							System.err.print(out[i]);
						}
				}
			} else {
				// debug
				if (debug >= 4) {
					prout[i][0].print("\n\t");
					prout[i][1].print("\n\t");
					prout1[i][0].print("\n\t");
					prout1[i][1].print("\n\t");
				}
			}
		}
	}

	/**
	 * Returns 1 if there is a transition Returns 0 if there is no transition
	 * Relys on current_clock, saw_count and LIMIT class variables Assumes clock
	 * is on channel 1
	 */
	int detect_transition(int clock) {
		int result = 0;
		if (clock == 0) {
			if (current_clock != 0) {
				no_signal = false;
				if (signal_count >= LIMIT) {
					current_clock = 0;
					signal_count = 0;
					result = 1;
				} else
					signal_count++;
			}
		} else if (clock == 1) {
			if (current_clock != 1) {
				no_signal = false;
				if (signal_count >= LIMIT) {
					current_clock = 1;
					signal_count = 0;
					result = 1;
				} else
					signal_count++;
			}
		} else if (clock == -1) {
			nosignal_count++;
			if (nosignal_count >= NUM_SAMPLES)
				current_clock = -11;
		}
		return result;
	}

	// returns 0 or 1 depending on clock state
	public int extractClock(double[] data) {

		double[][] peaks = new double[NUM_CHANNELS][2];
		double[][] avg = new double[NUM_CHANNELS][2];
		double[] newData = new double[data.length];
		newData = data.clone();

		// do this only for the clock channe
		normalize(newData);

		int channel = 1;
		int result = -1;
		for (int bit = 0; bit <= 1; bit++) {
			// calculate power in the band
			peaks[channel][bit] = getPowerBand(newData, channel_data.getFreq(channel,bit),
					channel_data.getFFTBand(channel, bit));

			if (debug >= 4 && channel == 1)
				prout[channel][bit].print(peaks[channel][bit]);

			avg[channel][bit] = calcAvgClock(channel, bit, 0);

			if (debug >= 4 && channel == 1)
				prout1[channel][bit].print(avg[channel][bit]);

			result = detectSignal(channel, result, avg);

			// notify mac layer if there is no clock signal
			// that means that the medium is ready for send at this host
			// then if there is data to send, this is a good time
			notifyMacLayer(result);
		}

		if (clock_history.size() >= CLOCK_HISTORY && CLOCK_HISTORY != 0)
			clock_history.removeFirst();
		clock_history.addLast(peaks);

		return result;
	}

	/** Calculate average signal in a band */
	private double calcAvgClock(int channel, int bit, int offset) {
		double result = 0;
		if (!clock_history.isEmpty() && clock_history.size() >= 2 + offset) {
			for (int i = clock_history.size() - 2 - offset; i < clock_history
					.size()
					- offset; i++) {
				double[][] record = new double[NUM_CHANNELS][2];
				record = (double[][]) clock_history.get(i);

				result += record[channel][bit];
			}
			// return result/peak_history.size();
			return result;
		} else
			return 0;

	}

	/**
	 * For each channel, there is a pair defined frequencies in
	 * CSE561_Settings.java (one to represent "0", another "1") Channels array
	 * will hold the following values: -1 = Signal Not Found 1 = Signal is "1" 0 =
	 * Signal is "0"
	 */
	public void extractFreqs(double[] data, int[] result) {

		double[][] peaks = new double[NUM_CHANNELS][2];
		double[] newData = new double[data.length];
		newData = data.clone();

		// do this only for data channels only
		for (int channel = 0; channel < NUM_CHANNELS; channel++) {

			result[channel] = -1;
			if (channel != 1) {

				for (int bit = 0; bit <= 1; bit++) {
					// calculate power in the band
					peaks[channel][bit] = getPowerBand(newData, channel_data.getFreq(channel,bit),
							channel_data.getFFTBand(channel, bit));
					if (debug >= 4)
						prout[channel][bit].print(peaks[channel][bit]);
					//peaks[0][1] = 0; // special case
				}

				result[channel] = detectSignal(channel, result[channel], peaks);
			}
		}

		if (peak_history.size() >= PEAK_HISTORY && PEAK_HISTORY != 0)
			peak_history.removeFirst();
		peak_history.addLast(peaks);

	}

	public int getAvgResult(int channel) {
		double[][] avg = new double[NUM_CHANNELS][2];
		int result = -1;

		result = -1;
		if (channel != 1) {

			for (int bit = 0; bit <= 1; bit++) {
				// calculate power in the band
				avg[channel][bit] = calcAvgSignal(channel, bit, average_offset);
				if (debug >= 4)
					prout1[channel][bit].print(avg[channel][bit]);
				// peaks[0][1]=0; //special case
			}

			result = detectSignal(channel, result, avg);
		}

		return result;
	}

	/** Calculate average signal in a band */
	private double calcAvgSignal(int channel, int bit, int offset) {
		double result = 0;
		if (!peak_history.isEmpty()) {
			for (int i = 0 + peak_history.size() / 2 - offset; i < peak_history
					.size()
					- offset; i++) {
				double[][] record = new double[NUM_CHANNELS][2];
				record = (double[][]) peak_history.get(i);

				result += record[channel][bit];
			}
			// return result/peak_history.size();
			return result;
		} else
			return 0;

	}

	private int detectSignal(int channel, int result, double[][] peaks) {
		for (int bit = 0; bit <= 1; bit++) {
			if (peaks[channel][bit] > channel_data.getThreshold(channel,bit)) {
				if (result == -1) {
					result = bit;
				} else {
					double p_diff = Math.abs(peaks[channel][0]
							- peaks[channel][1])
							/ Math.max(peaks[channel][0], peaks[channel][1]);
					if (p_diff > DIFF_THRESHOLD) {
						if (peaks[channel][0] > peaks[channel][1])
							result = 0;
						else
							result = 1;
					} else
						result = -1;
				}
			}
		}

		return result;
	}

	/** Calculates power in a band around the frequency */
	private double getPowerBand(double data[], double freq, int band) {
		double power = 0;
		int bin = (int) (Math.round(Math.floor(freq
				/ (RECV_SAMPLE_RATE / FFT_LENGTH))));
		for (int i = -band; i <= band; i++)
			if (bin + i >= 0 && bin + i < data.length)
				power += data[bin + i];
		// return power/(band*2+1);
		return power;
	}

	/** notifies mac layer if result == -1) * */
	private void notifyMacLayer(int result) {
		if (result == -1) {
			if (!channelIdle) {
				// System.out.println("We got a change!!!, we are now idle");
				channelIdle = true;
				macLayer.notifyRadioStatusChanged(channelIdle);
			}
		} else {
			if (channelIdle) {
				// System.out.println("We got a change!!!, we are now
				// receiving");
				channelIdle = false;
				macLayer.notifyRadioStatusChanged(channelIdle);
			}
		}
	}

	/** Normalize the spectrum */
	private void normalize(double[] data) {
		// find max
		double max = getPowerBand(data, channel_data.getNoiseFreq(), 
				channel_data.getNoiseFFTBand()); //noise
		double value = -1;
		for (int channel = 0; channel < NUM_CHANNELS; channel++) {
			for (int bit = 0; bit < 2; bit++) {
				value = getPowerBand(data, channel_data.getFreq(channel,bit),
						channel_data.getFFTBand(channel, bit));
				// value = getPowerBand(data, FREQS[channel][bit], 1);
				if (value > max)
					max = value;
			}

		}
		// normalize
		for (int i = 0; i < data.length; i++)
			data[i] = data[i] / max;
	}

	/* Test functions */

	/** Senses channel noise and calculates thresholds */
	private void senseNoise(double[] data) {
		double[][] peaks = new double[NUM_CHANNELS][2];
		for (int channel = 0; channel < NUM_CHANNELS; channel++) {
			for (int bit = 0; bit <= 1; bit++) {
				peaks[channel][bit] = getPowerBand(data, channel_data.getFreq(channel,bit),
						channel_data.getFFTBand(channel, bit));
				if (noise_history.size() >= NOISE_HISTORY) {
					// THRESHOLD[channel][bit] = 5*calcMaxNoise(channel,bit);
					// System.out.println("Th"+channel+""+bit+":
					// "+THRESHOLD[channel][bit]);
				}
			}
		}
		noise_history.addLast(peaks);
	}

	/** Calculate avg noise in a band */
	private double calcAvgNoise(int channel, int bit) {
		double result = 0;
		if (!noise_history.isEmpty()) {
			for (int i = 0; i < noise_history.size(); i++) {
				double[][] record = new double[NUM_CHANNELS][2];
				record = (double[][]) noise_history.get(i);
				result += record[channel][bit];
			}
			return result / noise_history.size();
		} else
			return 0;
	}

	/** Detect signal by comparing the the frequency band to a total band */
	private double detectSignal(double local, double total, double normal,
			double threshold) {

		if (local / total > normal * threshold)
			return local / total;
		else
			return 0;

	}

}