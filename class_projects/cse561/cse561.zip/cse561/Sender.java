import java.io.*;

import java.nio.*;

import java.util.*;

/*
 * Created on Oct 3, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author isdal
 *
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
import javax.sound.sampled.*;

public class Sender extends Thread implements Runnable, CSE561_Settings {
	private volatile Thread sendThread = null;

	// The following are general instance variables
	// used to create a SourceDataLine object.
	private LinkedList<Integer> sendBuffer;

	AudioFormat audioFormat;

	AudioInputStream audioInputStream;

	SourceDataLine sourceDataLine;

	Channel channel_data;

	// The following are audio format parameters.
	// They may be modified by the signal generator
	// at runtime. Values allowed by Java
	// SDK 1.4.1 are shown in comments.
	int baud = SEND_BAUD_RATE;

	float sampleRate = SEND_SAMPLE_RATE;

	int sampleSizeInBits = SEND_SAMPLE_SIZE_IN_BITS;

	int channels = SEND_CHANNELS;

	boolean signed = SEND_SIGNED;

	boolean bigEndian = SEND_BIG_ENDIAN;

	private int num_data_channels = NUM_CHANNELS - 2;

	// Allowable 0,1
	public int clock_bit;

	public double clock_freq;

	// A buffer to hold audio data
	byte[] audioData = new byte[((int) ((sampleRate * 2) / baud))];

	private Channel data_channel;

	// debug file output
	private PrintStream output_file;
	
	private int speedIndex = 0;
	
	private double amplitude = 1;

	private MacLayer macLayer;

	public Sender(MacLayer macLayer) {
		this.setPriority(10);
		this.macLayer = macLayer;
		sendBuffer = new LinkedList<Integer>();
		clock_bit = 0;

		// Get the required audio format
		audioFormat = new AudioFormat(sampleRate, sampleSizeInBits, channels,
				signed, bigEndian);

		data_channel = new Channel();

		// debug
		try {
			output_file = new PrintStream(new FileOutputStream("input.txt"));
		} catch (Exception e) {
			System.out.println("Error opening an output file.");
			System.exit(-1);
		}
	}

	public void start() {
		if (sendThread == null) {
			sendThread = new Thread(this, "Send");
			sendThread.start();
			System.out.println("Starting Sender");
			if(USE_GUI)GUI_CrappyGui.getInstance().printPhyMessage("\nStarting Sender\n");
			
		}
	}

	public void stopSending() {
		sendThread = null;

		// Block and wait for internal buffer of the
		// SourceDataLine to become empty.
		sourceDataLine.drain();

		// Finish with the SourceDataLine
		sourceDataLine.stop();
		sourceDataLine.close();
		output_file.close();
	}

	public void run() {
		try {
			// Get info on the required data line
			DataLine.Info dataLineInfo = new DataLine.Info(
					SourceDataLine.class, audioFormat);

			// Get a SourceDataLine object
			sourceDataLine = (SourceDataLine) AudioSystem.getLine(dataLineInfo);

			// Open and start the SourceDataLine
			sourceDataLine.open(audioFormat);
			// use only left speaker
			// Mixer mixer = AudioSystem.getMixer(null);
			// Port speaker = (Port)mixer.getLine(Port.Info.HEADPHONE);
			// FloatControl balCtrl = (FloatControl)
			// speaker.getControl(FloatControl.Type.BALANCE);
			// balCtrl.setValue((float)-1);
			sourceDataLine.start();

			Thread myThread = Thread.currentThread();

			boolean flush_buffer = false;
			// boolean firstSync = true;
			while (sendThread == myThread) {
				if (sendBuffer.size() > 0) {
					flush_buffer = true;
					// if there are bits in the queue, send the first one
					if (debug >= 5) {
						System.out.println("Bits in buffer: "
								+ sendBuffer.size());
					}

					BitArray sendBucket = new BitArray();
					// Create a bucket that stores the number of bits that can
					// be transmitted in parallel

					while (sendBucket.length() < num_data_channels
							&& sendBuffer.size() != 0) {
						if (debug >= 50) {
							System.out.println("Bits in bucket: "
									+ (sendBucket.length() + 1));
						}
						// Take the first bit from queue
						int sendbit = sendBuffer.removeFirst();
						// If we see a sync signal
						if (sendbit == 2) {
							// send the bits in the current buffer
							sendBits(sendBucket);
							// flush the sendBucket
							sendBucket = new BitArray();
							// Send the syncsignal
							sendBit(2);
						} else {
							// Add the current bit to the send bucket
							if (debug >= 50) {
								System.out.println("adding " + (sendbit == 1)
										+ "");
							}
							sendBucket.add(sendbit == 1);
						}
					}
					// Send the bucket
					if (debug >= 50) {
						System.out.println("sending a bucket");
					}
					sendBits(sendBucket);
					sendBucket = new BitArray();

				} else {
					// do this once after size gets to 0
					if (flush_buffer == true) {
						sourceDataLine.drain();
						sourceDataLine.flush();
						flush_buffer = false;
					}
					// Do some sleeping before trying again
					Thread.sleep(20);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

	public boolean queueBit(int bit) {

		if ((bit == 0) || (bit == 1) || (bit == 2)) {
			sendBuffer.add(new Integer(bit));

			if (debug >= 5) {
				System.out.println("Adding " + bit + " to send buffer");
			}

			return true;
		}

		return false;
	}

	public boolean queueBit(boolean bit) {
		if (bit)
			return queueBit(1);
		else
			return queueBit(0);

	}

	public void queuePacket(MacPacket packet) {
		for (int i = 0; i < (num_data_channels) * 2; i++) {
			queueBit(i % 2);
		}
		queueBit(2);
		queueBit(2);
		for (int i = 0; i < packet.length(); i++) {
			queueBit(packet.getBit(i));
			output_file.print(booleanToStr(packet.getBit(i)));
		}
		for (int i = 0; i < (num_data_channels) * 2; i++) {
			queueBit(i % 2);
		}
	}

	// Function used to clear the send buffer
	public void clearBuffer() {
		if (debug >= 5) {
			System.out.println("Clearing send buffer");
		}

		sendBuffer.clear();

	}

	private void sendBits(BitArray data) {
		// if there is no data, do nothing
		if (data.length() == 0) {
			return;
		}
		if (debug >= 10) {
			System.out.println("Sending bit: " + data);
		}

		// determines previous clock
		// from global variable clock_bit
		clock_freq = 0;

		if (clock_bit == 0) {
			clock_freq = data_channel.getFreq(1, 0);
			clock_bit = 1;
		} else if (clock_bit == 1) {
			clock_freq = data_channel.getFreq(1, 1);
			clock_bit = 0;
		} else {
			System.out.println("Clock exception");
			System.out.println("Clock: " + clock_bit);
			System.exit(-1);
		}

		new SynGen().getSyntheticData(audioData, data);
		playOrFileData();

	}

	private void sendBit(int data) {
		if (debug >= 10) {
			System.out.println("Sending bit: " + data);
		}

		// determines previous clock
		// from global variable clock_bit
		clock_freq = 0;

		if (clock_bit == 0) {
			clock_freq = data_channel.getFreq(1, 0);
			clock_bit = 1;
		} else if (clock_bit == 1) {
			clock_freq = data_channel.getFreq(1, 1);
			clock_bit = 0;
		} else {
			System.out.println("Clock exception");
			System.out.println("Clock: " + clock_bit);
			System.exit(-1);
		}

		new SynGen().getSyntheticData(audioData, data);
		playOrFileData();
	}

	private String booleanToStr(boolean value) {

		String str = "";

		if (value == true)
			str = "1";
		else
			str = "0";

		return str;
	}

	public synchronized int decreaseNumChannels() {
		speedIndex++;
		speedIndex = Math.min(SEND_SPEEDS.length-1,speedIndex);
		System.err.print("Changing speed (baud/channels) from (" + baud + "/"
				+ num_data_channels + ")");
		baud = SEND_SPEEDS[speedIndex][0];
		num_data_channels = SEND_SPEEDS[speedIndex][1];
		System.err.println(" to (" + baud + "/" + num_data_channels + ")");
		//		
		// System.err.print("Decreasing number of channels from "
		// + num_data_channels);
		// num_data_channels = Math.max(1, num_data_channels / 2);
		// System.err.println(" to " + num_data_channels);
		audioData = new byte[((int) ((sampleRate * 2) / baud))];
		return num_data_channels + 2;
	}
	
	public synchronized int setSpeed(int i){
		speedIndex = i-1;
		return decreaseNumChannels();
		
	}
	
	public void setAmp(double amp)
	{
		amplitude = amp;
	}
	
	public synchronized int resetNumChannels() {
		speedIndex = 0;
		System.err.print("resetting speed (baud/channels) from (" + baud + "/"
				+ num_data_channels + ")");
		baud = SEND_SPEEDS[speedIndex][0];
		num_data_channels = SEND_SPEEDS[speedIndex][1];
		System.err.println(" to (" + baud + "/" + num_data_channels + ")");
		audioData = new byte[((int) ((sampleRate * 2) / baud))];
		return num_data_channels + 2;
	}

	// This method plays or files the synthetic
	// audio data that has been generated and saved
	// in an array in memory.
	private void playOrFileData() {
		try {
			// Get an input stream on the byte array
			// containing the data
			InputStream byteArrayInputStream = new ByteArrayInputStream(
					audioData);

			// Get an audio input stream from the
			// ByteArrayInputStream
			audioInputStream = new AudioInputStream(byteArrayInputStream,
					audioFormat, audioData.length / audioFormat.getFrameSize());

			// Create a thread to play back the data and
			// start it running. It will run until all
			// the data has been played back
			// new ListenThread().start();
			byte[] playBuffer = new byte[16384];

			int cnt;

			// Get beginning of elapsed time for
			// playback
			// long startTime = new Date().getTime();

			// Transfer the audio data to the speakers
			if(USE_GUI_CHANNEL_STATE)GUI_CrappyGui.getInstance().setSendingState(true);
			while ((cnt = audioInputStream.read(playBuffer, 0,
					playBuffer.length)) != -1) {
				// Keep looping until the input read
				// method returns -1 for empty stream.
				if (cnt > 0) {
					// Write data to the internal buffer of
					// the data line where it will be
					// delivered to the speakers in real
					// time
					sourceDataLine.write(playBuffer, 0, cnt);
				} // end if
			} // end while
			if(USE_GUI_CHANNEL_STATE)GUI_CrappyGui.getInstance().setSendingState(false);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		} // end catch
	} // end playOrFileData

	// =============================================//
	// =============================================//
	// Inner signal generator class.
	// An object of this class can be used to
	// generate a variety of different synthetic
	// audio signals. Each time the getSyntheticData
	// method is called on an object of this class,
	// the method will fill the incoming array with
	// the samples for a synthetic signal.
	class SynGen {
		private static final double CLOCK_MAGNIFICATION = 2.0;

		// Note: Because this class uses a ByteBuffer
		// asShortBuffer to handle the data, it can
		// only be used to generate signed 16-bit
		// data.
		ByteBuffer byteBuffer;

		ShortBuffer shortBuffer;

		int byteLength;

		// The old send function, sends one bit at the time
		void getSyntheticData(byte[] synDataBuffer, int data) {

			// Prepare the ByteBuffer and the shortBuffer
			// for use
			byteBuffer = ByteBuffer.wrap(synDataBuffer);
			shortBuffer = byteBuffer.asShortBuffer();

			byteLength = synDataBuffer.length;

			// channels = 1; //Java allows 1 or 2
			// Each channel requires two 8-bit bytes per
			// 16-bit sample.
			int bytesPerSamp = (int) (SEND_SAMPLE_SIZE_IN_BITS / 8);
			sampleRate = SEND_SAMPLE_RATE;

			// Allowable 8000,11025,16000,22050,44100
			int sampLength = byteLength / bytesPerSamp;

			for (int cnt = 0; cnt < sampLength; cnt++) {
				double time = cnt / sampleRate;
				double freq;

				// TODO: convert to handle multiple data channels
				if (data == 2) {
					freq = data_channel.getFreq(0, 0); // synch freq
				} else if (data == 1) {
					freq = data_channel.getFreq(2, 1); // first data channel
					// freq 1
				} else {
					freq = data_channel.getFreq(2, 0); // first data channel
					// freq 2
				}

				// double sinValue = (Math.sin(2 * Math.PI * freq * time));

				double sinValue = (Math.sin(2 * Math.PI * clock_freq * time) + Math
						.sin(2 * Math.PI * freq * time)) / 2.0;
				//                
				/*
				 * double sinValue = (Math.sin(2 * Math.PI * freq * time) +
				 * Math.sin(2 * Math.PI * (freq / 1.8) * time) + Math.sin(2 *
				 * Math.PI * (freq / 1.5) * time)) / 3.0;
				 */
				double amp;
				amp = USE_AMP?amplitude:1;
				shortBuffer.put((short) (16000 * amp * sinValue));
			} // end for loop
		} // end getSyntheticData method

		// The new send function, sends many bits at the time
		void getSyntheticData(byte[] synDataBuffer, BitArray data) {

			// Prepare the ByteBuffer and the shortBuffer
			// for use
			byteBuffer = ByteBuffer.wrap(synDataBuffer);
			shortBuffer = byteBuffer.asShortBuffer();

			byteLength = synDataBuffer.length;

			// channels = 1; //Java allows 1 or 2
			// Each channel requires two 8-bit bytes per
			// 16-bit sample.
			int bytesPerSamp = (int) (SEND_SAMPLE_SIZE_IN_BITS / 8);
			sampleRate = SEND_SAMPLE_RATE;

			// Allowable 8000,11025,16000,22050,44100
			int sampLength = byteLength / bytesPerSamp;

			for (int cnt = 0; cnt < sampLength; cnt++) {
				double time = cnt / sampleRate;
				double freq;
				double sinValue = 0;
				// Add the clock signal
				sinValue += Math.sin(2 * Math.PI * clock_freq * time);
				sinValue += Math.sin(2 * Math.PI * data_channel.getFreq(0, 1)
						* time)
						/ CLOCK_MAGNIFICATION;
				// Loop through the array of incoming bits
				for (int i = 0; i < data.length(); i++) {
					// if the bit at the current position is 1
					if (data.get(i)) {
						// set freq to the freq for 1
						freq = data_channel.getFreq(2 + i, 1); // data channel
						// i freq 1
					} else {
						// set it for the value for 0
						freq = data_channel.getFreq(2 + i, 0); // data channel
						// i freq 0
					}

					sinValue += Math.sin(2 * Math.PI * freq * time)
							/ CLOCK_MAGNIFICATION;
				}

				sinValue = sinValue / (data.length() + 2);
				shortBuffer.put((short) (16000 * sinValue));
			} // end for loop
		} // end getSyntheticData method

		// -------------------------------------------//
	} // end SynGen class

	// =============================================//
}
