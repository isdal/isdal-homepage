import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * 
 */

@SuppressWarnings("serial")
/**
 * 
 */
class GUI_ChatPanel extends JPanel implements ActionListener, FocusListener {
	private JTextArea outputArea;

	JTextField inputField;
	private String DEST_TEXT = "Destination";
	private String MESSAGE_TEXT = "Write Here";

	JTextField destField;

	public GUI_ChatPanel() {
		setLayout(new BorderLayout());

		inputField = new JTextField();

		destField = new JTextField(DEST_TEXT);
		destField.addFocusListener(this);

		inputField.setText(MESSAGE_TEXT);
		inputField.addFocusListener(this);

		JButton sendButton = new JButton("Send");
		sendButton.setMnemonic(KeyEvent.VK_S);
		sendButton.setActionCommand("send");
		sendButton.addActionListener(this);
		outputArea = new JTextArea();
		outputArea.setEditable(false);
		Font oldFont = outputArea.getFont();
		Font newFont = new Font(oldFont.getName(),Font.BOLD,16);
		outputArea.setFont(newFont);
		
		JScrollPane outputScroll = new JScrollPane(outputArea);
		outputScroll.setPreferredSize(new Dimension(100, 50));

		JPanel sendPanel = new JPanel();

		sendPanel.setLayout(new BorderLayout());
		sendPanel.add(destField, BorderLayout.WEST);
		sendPanel.add(inputField, BorderLayout.CENTER);
		sendPanel.add(sendButton, BorderLayout.EAST);

		add(outputScroll, BorderLayout.CENTER);
		add(sendPanel, BorderLayout.SOUTH);
	}

	public void actionPerformed(ActionEvent e) {
		if ("send".equals(e.getActionCommand())) {
			try {
				int dest = Integer.parseInt(destField.getText());
				GUI_CrappyGui.getInstance().send(dest,
						inputField.getText().getBytes());
				GUI_CrappyGui.getInstance().printDataMessage(
						"Me: " + inputField.getText());
				inputField.setText("");
				destField.setText("");
				// TODO Fix timestamp!!!
			} catch (Exception ex) {
				ex.printStackTrace();

			}
		}
	}

	public void focusGained(FocusEvent e) {
		 if (e.getSource().equals(destField)
				&& destField.getText().equals(DEST_TEXT)) {
			destField.setText("");
		}
		if (e.getSource().equals(inputField)
				&& inputField.getText().equals(MESSAGE_TEXT)) {
			inputField.setText("");
		}
	}

	public void focusLost(FocusEvent e) {
		if (e.getSource().equals(destField)
				&& destField.getText().equals("")) {
			destField.setText(DEST_TEXT);
		}
		if (e.getSource().equals(inputField)
				&& inputField.getText().equals("")) {
			inputField.setText(MESSAGE_TEXT);
		}

	}

	public void printMessage(String message) {
		outputArea.append(message);
	}
}