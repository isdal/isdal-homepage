import java.util.Iterator;
import java.util.Vector;

public class NetworkRoute implements CSE561_Settings {
	private Vector<RoutePath> paths;

	private byte myAddr;

	public NetworkRoute(byte myAddr) {
		this.myAddr = myAddr;
		paths = new Vector<RoutePath>();

	}

	public void addPath(RoutePath path) {
		if (path.getSource() == myAddr) {
			if (!contains(path)) {
				paths.add(path);

			} else {
				System.out.print("NR: Path already in route cache: "
						+ path.toString());
			}
		} else {
			System.out.println("Something is strange!!! source is: " + path.getSource());
		}
	}

	public Byte getNextHop(Byte dest) {
		int shortestPath = Byte.MAX_VALUE;
		Byte bestNextHop = -1;

		for (int i = 0; i < paths.size(); i++) {
			RoutePath path = paths.get(i);
			if (shortestPath > path.size()) {
				shortestPath = path.size();
				bestNextHop = path.getNextHop();
			}
		}

		return bestNextHop;
	}
	
	public RoutePath getNodePath(Byte dest) {
		int shortestPath = Byte.MAX_VALUE;
		RoutePath bestPath = null;

		for (int i = 0; i < paths.size(); i++) {
			RoutePath path = paths.get(i);
			if (shortestPath > path.size()) {
				shortestPath = path.size();
				bestPath = path;
			}
		}

		return bestPath;
	}

	public void flushLink(Byte node1, Byte node2) {

		for (Iterator iter = paths.iterator(); iter.hasNext();) {
			RoutePath path = (RoutePath) iter.next();
			if (path.contains(node1, node2))
				iter.remove();
		}
	}

	public String toString() {
		StringBuffer str = new StringBuffer();
		for (int i = 0; i < paths.size(); i++) {
			str.append(paths.get(i).toString());
		}
		return str.toString();
	}

	public boolean contains(RoutePath comparePath) {
		for (Iterator iter = paths.iterator(); iter.hasNext();) {
			RoutePath path = (RoutePath) iter.next();
			if (path.equals(comparePath)) {
				return true;
			}
		}
		return false;
	}
	public Vector<RoutePath> getPaths(){
		return paths;
	}
}
