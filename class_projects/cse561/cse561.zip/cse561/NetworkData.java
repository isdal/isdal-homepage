
// wrapper class that is used to send info to
// the mac layer. contains the n/w packet and
// also the next hop address
public class NetworkData 
{
	NetworkLayerPacket nwPacket;
	int nextHop;
	
	public NetworkData(NetworkLayerPacket pkt, int nxtHop)
	{
		nwPacket = pkt;
		this.nextHop = nxtHop;
	}
	
	public int getNextHop()
	{
		return nextHop;
	}
	
	public NetworkLayerPacket getPacket()
	{
		return nwPacket;
	}
	
}
