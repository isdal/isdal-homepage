import java.util.concurrent.LinkedBlockingQueue;
import java.util.*;

public class NetworkLayer implements CSE561_Settings {

	

	private final int TABLE_FLUSH_INTERVAL = 10 * 1000; // TODO

	private final int RREQ_TIMEOUT = 300 * 1000;// TODO

	private LinkedBlockingQueue<NetworkData> sendToMacBuffer;

	private LinkedBlockingQueue<NetworkLayerPacket> receiveFromMacBuffer;

	private MacLayer macLayer;

	private int myAddr;

	private HashSet<RequestTableKey> requestTable = new HashSet<RequestTableKey>();

	private RouteCache cache ;

	private ApplicationLayer appLayer;

	private Timer timer = new Timer();

	private RetransmitTimer retxTimer;
	
	private NetworkReceiverThread recvThread;
	
	private NetworkSenderThread sendThread;
	
	public NetworkLayer(int myAddr, ApplicationLayer al) {
		this.myAddr = myAddr;
		this.appLayer = al;
		System.out.println("Starting NetworkLayer");
		if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Starting NetworkLayer\n");
		macLayer = new MacLayer(this, myAddr);
		receiveFromMacBuffer = new LinkedBlockingQueue<NetworkLayerPacket>();
		cache = new RouteCache((byte)myAddr);
		sendToMacBuffer = new LinkedBlockingQueue<NetworkData>();
		try{
		Thread.sleep(500);
		}catch(InterruptedException e){e.printStackTrace();}
		recvThread = new NetworkReceiverThread();
		recvThread.setPriority(1);
		sendThread = new NetworkSenderThread();
		sendThread.setPriority(1);
		
		recvThread.start();
		sendThread.start();
	}

	// this should be called from within the receiver thread
	// in the network layer.
	private NetworkLayerPacket getDataFromMac() {
		NetworkLayerPacket packet = new NetworkLayerPacket();
		try {
			packet = receiveFromMacBuffer.take();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return packet;
	}

	public void putDataForNetwork(NetworkLayerPacket data) {
		try {
			receiveFromMacBuffer.put(data);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	// TODO: need to give the next hop information to the Mac layer
	private void sendDataToMac(NetworkLayerPacket data, int nextHop) {
		try {
			System.err.println("sendDataToMac: next Hop = " + nextHop);
			sendToMacBuffer.put(new NetworkData(data, nextHop));
			// macLayer.sendData(sendBuffer.take());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public NetworkData getTopPacketFromQueue() {
		NetworkData packet = null;
		try {
			packet = (sendToMacBuffer.take());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return packet;
	}

	// TODO corner case: what if i don't know the next hop????
	// this looks up the cache and queues up the packet for the mac layer
	public void forwardDataPacket(NetworkLayerPacket packet, int dest) {
		int nextHop = cache.nextHop(dest);
		assert (nextHop != -1);
		int src = packet.getSrcAddr();
		if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Forwarding DATA packet Src: " + src + " Dest: " + dest + " NextHop: " + nextHop + "\n");
		sendDataToMac(packet, nextHop);
	}

	/**
	 * Function to create and send the route reply
	 * 
	 * @param path
	 *            The path obtained from the RREQ packet. So, if we have a path
	 *            A --> B --> C --> D, then the path obtained would be [B;C]
	 * 
	 * @param dest
	 *            The originator of the RREQ, who wants a path to me
	 */
	public void sendRREPPacket(RoutePath path, int dest) {
		// first, we reverse the path ;)
//		path.add((byte)myAddr);
		path = path.invertPath();
		int nextHop = path.getNextHop();
		System.err.println("NW: " + myAddr + ": sending RREP to " + dest + " through " + nextHop);
		if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Sending RREP packet Dest: " + dest + " NextHop: " + nextHop + "\n");
		NetworkLayerPacket packet = new NetworkLayerPacket(PACKET_TYPE_RREP,
				myAddr, dest, 0, path, new BitArray());
		// queue up the packet for mac layer with the next hop info
		sendDataToMac(packet, nextHop);
	}

	// add self to path list and then forward i.e. broadcast
	public void forwardRREQ(NetworkLayerPacket packet) {
//		packet.addHop((byte) myAddr);
		int dest = packet.getDstAddr();
		System.err.println("forwarding RREQ to final dest: " + packet.getDstAddr());
		if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Forwarding RREQ packet Dest: " + dest + " NextHop: " + BROADCAST_ADDR + "\n");
		sendDataToMac(packet, BROADCAST_ADDR);
	}

	// find the next hop to forward to and do it
	public void forwardRREP(NetworkLayerPacket packet) {
		RoutePath path = packet.getPath();
		int nextHop = path.getNextHop((byte)myAddr);
		int dest = packet.getDstAddr();
		System.err.println("forwarding RREP to final dest: " + dest);
		if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Forwarding RREP packet Dest: " + dest + " NextHop: " + nextHop + "\n");
		sendDataToMac(packet, nextHop);
	}

	public void forwardRERR(NetworkLayerPacket packet) {
		int dest = packet.getDstAddr();
		int nextHop = cache.nextHop(dest);
		assert (nextHop != -1);
		if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Forwarding RERR packet Dest: " + dest + " NextHop: " + nextHop + "\n");
		sendDataToMac(packet, nextHop);
	}

	public void sendRREQPacket(int dest) {
		System.err.println("sending RREQ to final dest: " + dest);
		// we create a RREQ packet and broadcast it
		NetworkLayerPacket packet = new NetworkLayerPacket(PACKET_TYPE_RREQ,
				myAddr, dest, 0, // TODO put meaningful seqnos
				new RoutePath(), new BitArray());
		packet.addHop((byte)myAddr);
		if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Sending RREQ packet Dest: " + dest + " NextHop: " + BROADCAST_ADDR + "\n");
		sendDataToMac(packet, BROADCAST_ADDR);
	}

	public void sendDataPacket(NetworkLayerPacket packet, int dest) {
		System.err.println("sending datapacket to final dest:" + dest);
		int nextHop = cache.nextHop(dest);
		System.err.println("cache says 'next hop is " + nextHop + "'");
		System.err.print(cache.toString());
		assert (nextHop != -1);
		if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Sending DATA packet Dest: " + dest + " NextHop: " + nextHop + "\n");
		sendDataToMac(packet, nextHop);
	}

	private void sendRERRPacket(int dest, int errorHop)
	{
		NetworkLayerPacket rerrPkt = new NetworkLayerPacket(
				PACKET_TYPE_RERR,
				myAddr,
				dest,
				0, //TODO seqNo
				new RoutePath(),
				new BitArray()
				);
		rerrPkt.addHop((byte)errorHop);
		int nextHop = cache.nextHop(dest);
		if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Sending RERR packet (" + myAddr + "->" + errorHop + ") Dest: " + dest + " NextHop: " + nextHop + "\n");
		sendDataToMac(rerrPkt, nextHop);
	}
	
	//TODO need to put separate queues for routing and data packets
	public void notifyPacketDrop(NetworkLayerPacket p)
	{
		// look at the source of the packet
		// if my next hop is down, i need to flush 
		// the cache and do some stuff like that TODO
		int src = p.getSrcAddr();
		int dst = p.getDstAddr();
		int errorHop = cache.nextHop(dst);
		cache.flushLink(myAddr, errorHop);
		if( src != myAddr)
			sendRERRPacket(src, errorHop);
	}
	
	public void addLink(int node){
		RoutePath path = new RoutePath();
		path.add((byte)myAddr);
		path.add((byte)node);
		cache.addPath(path);
	}
	/*
	 * Defines the thread in the network layer that receives data from the MAC
	 * layer. It looks at the type of packet received and takes the appropriate
	 * action.
	 */
	class NetworkReceiverThread extends Thread {
		public void run() {
			while (true) {
				// this should return a network_layer_packet
				NetworkLayerPacket packet = getDataFromMac();
				int dst = packet.getDstAddr();
				int src = packet.getSrcAddr();
				String srcDstStr = "Source: " + src + " Dest: " + dst + "\n";
				switch (packet.getType()) {
				case PACKET_TYPE_DATA:
					if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Received DATA packet " + srcDstStr);
					if (dst == myAddr) // data packet for me!!
					{
						// pass it on to the upper layers
						appLayer.putData(new ApplicationLayerData(packet.getSrcAddr(),packet.getPayload()));
					} else // i have to forward the packet
					{
						forwardDataPacket(packet, dst);
					}
					break;

				case PACKET_TYPE_RREQ:
					if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Received RREQ packet " + srcDstStr);
					// check if we've seen this RREQ already
					int seqNo = packet.getSeqNum();
					RequestTableKey rKey = new RequestTableKey(src, dst, seqNo);
					if (requestTable.contains(rKey)) {
						// ignore this packet
					} else {
						requestTable.add(rKey);
						// schedule a timer to flush the request_seen table
						timer.schedule(new TableFlushTimer(rKey),
								TABLE_FLUSH_INTERVAL);
						packet.addHop((byte)myAddr);
						RoutePath path = packet.getPath();
						
						cache.addPath(path);
						if (dst == myAddr) {
							sendRREPPacket(path, src);
						} else {
							
							// forward the RREQ, i.e. broadcast
							// after adding self to list
							if(src != myAddr)
								forwardRREQ(packet);
						}
					}
					break;

				case PACKET_TYPE_RREP:
					if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Received RREP packet " + srcDstStr);
					RoutePath path = packet.getPath();
					cache.addPath(path);
					System.out.println("RouteCache " + cache.toString());
					if (dst == myAddr) {
						// don't need to do anything ;)
						// might have to wake up the
						// thread that is meant to
						System.out.println("debug: Cancelling retx timer");
						retxTimer.cancel();
						sendThread.notifyRoute();
						
					} else {
						forwardRREP(packet);
					}
					break;

				case PACKET_TYPE_RERR:
					// when i get a route error, i need to
					// flush the paths that contain the bad
					// link from my route cache and propagate
					// the route error up the path
					if(USE_GUI)GUI_CrappyGui.getInstance().printNetMessage("Received RERR packet " + srcDstStr);
					int node1 = packet.getSrcAddr();
					// the convention is that the last hop in the path
					// will be the node that is not reachable, this will
					// allow us to identify the broken link
					int node2 = packet.getLastHop();

					cache.flushLink(node1, node2);
					if (dst == myAddr) {
						// do nothing ... may want to retransmit?? but upper
						// layer's headache
					} else {
						forwardRERR(packet);
					}

				} // end switch(type)
			} // end while(true)
		}// end run()
	}

	class NetworkSenderThread extends Thread {
		public void run() {
			while (true) {
				// this would be a blocking call and will return
				// only after getting the data packet

				// the destination should be known too
				// AppData could have 2 fields, dest and text
				ApplicationLayerData data;
				try {
					//System.err.println("debug: waiting for data from app");
					data = appLayer.getData();
					//System.err.println("debug: recd. data from app");
					int dest = data.getDest();
					NetworkLayerPacket packet = new NetworkLayerPacket(
							PACKET_TYPE_DATA, myAddr, dest, 0, // seq No
							new RoutePath(), data.getData());
					// if the route doesn't exist in the cache
					// then we need to do the route discovery
					if (cache.nextHop(dest) == -1) {
						sendRREQPacket(dest);
						retxTimer = new RetransmitTimer(dest);
						System.err.println("retx rreq timer: " + RREQ_TIMEOUT);
						timer.schedule(retxTimer, RREQ_TIMEOUT);
						while (cache.nextHop(dest) == -1) {
							waitForRoute();
							System.out.println("got rrep .. wake up!!! dest: " + dest + " nextHop: " + cache.nextHop(dest));
						}
						// now that i have the route, send the packet

						sendDataPacket(packet, dest);
					} else // next hop known
					{
						sendDataPacket(packet, dest);
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} // end while(true)
		}// end run()

		public synchronized void waitForRoute() {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		public synchronized void notifyRoute()
		{
			this.notify();
		}
	}// end Class SenderThread

	class RetransmitTimer extends TimerTask {
		int dest;

		public RetransmitTimer(int dest) {
			this.dest = dest;
		}

		public void run() {
			sendRREQPacket(dest);
			retxTimer = new RetransmitTimer(dest);
			timer.schedule(retxTimer, RREQ_TIMEOUT);
		}
	}

	class TableFlushTimer extends TimerTask {
		RequestTableKey rKey;

		public TableFlushTimer(RequestTableKey rKey) {
			this.rKey = rKey;
		}

		public void run() {
			assert (rKey != null);
			requestTable.remove(rKey);
		}
	}

	class RequestTableKey {
		int src, dest, seqNo;

		public RequestTableKey(int src, int dest, int seqNo) {
			this.src = src;
			this.dest = dest;
			this.seqNo = seqNo;
		}
	}
}