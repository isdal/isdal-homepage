
/*
 * Created on Oct 6, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author isdal
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface CSE561_Settings {
	
	// Use GUI
	final boolean USE_GUI = true;
	final boolean USE_AMP = false;
	final boolean USE_GUI_CHANNEL_STATE = true;
	final boolean USE_GUI_ICON = false;
    // Set debug level, 
    final int debug = 4;

    // ************* Packet stuff ***********************
    final int ADDRESS_FIELD_BITS = 4;
    final int LENGTH_FIELD_BITS = 10;
    final int SEQ_FIELD_BITS = 1; 
    final int CRC_FIELD_BITS = 8;
    
    //  ************* Network Packet stuff ***********************
    
    final int TYPE_FIELD_BITS = 2;
    final int PACKET_TYPE_DATA = 0;
    final int PACKET_TYPE_RREQ = 1;
    final int PACKET_TYPE_RREP = 2;
    final int PACKET_TYPE_RERR = 3;
     
    
    
    // ************* Sender stuff ***********************
    //Up to 16 baud  - at 64, NUM_SAMPLES gets too small
    final int MAX_PACKET_SIZE = 301;
    
    final int SEND_BAUD_RATE = 16;
    final int BROADCAST_SPEED = 2;
    public int[][] SEND_SPEEDS = { 
			//{32, 8 }, 
			{16, 8 }, 
			{8, 8 }, 
			{ 8, 4 }//,
			//{ 16, 2 }//, 
			//{ 8, 1 }, 
			//{ 4, 1 } 
			};


    final int HEADER_LENGTH = 2 * ADDRESS_FIELD_BITS + LENGTH_FIELD_BITS + SEQ_FIELD_BITS;
    
    // Defines senders audio format

    //  Allowable 8000,11025,16000,22050,44100,48000
    final float SEND_SAMPLE_RATE = 48000.0F;

    //  Allowable 8,16	
    int SEND_SAMPLE_SIZE_IN_BITS = 16;

    //Allowable 1,2
    int SEND_CHANNELS = 1;

    //Allowable true,false
    boolean SEND_SIGNED = true;

    //Allowable true,false
    boolean SEND_BIG_ENDIAN = true;
    
    // **************** Receiver Stuff ********************
    // FFT_LENGTH should be a power of 2
    // The divisor should be power of 2, closest to SEND_SAMPLE_RATE
    // e.g. 16384 for SEND_SAMPLE_RATE = 16000.0F
    // Value should result in NUM_SAMPLES FFT_SAMPLES per signal
    //final int FFT_LENGTH = 16384 / (SEND_BAUD_RATE*2); 
    
    // Values 256, 512, 1024
    final int FFT_LENGTH = 256;
    
    final float RECV_SAMPLE_RATE = 48000.0F;
    
    final int NUM_SAMPLES = (int) RECV_SAMPLE_RATE/(FFT_LENGTH*SEND_BAUD_RATE);
    
    final int RECV_SAMPLE_SIZE_IN_BITS = 8; // isn't this enough?
    
    // 1 for mono 2 for stereo, ...
    final int RECV_CHANNELS = 1;
    
    // frame size in bytes
    final int RECV_FRAME_SIZE = 1;
    
    final float RECV_FRAME_RATE = 48000.0F;
    
    // true for Big-Endian and false for Little-Endian
    final boolean ENDIAN_STYLE = false;
    
    final int NUM_CHANNELS = 10;
       
    //Variable frequency threshold 
    final double DIFF_THRESHOLD = 0.25;
    final int BROADCAST_ADDR = 0xf;
   
    final int NUM_BITS_BEFORE_PARITY = 8;

    /**
     * Last successful testing setup (Tanya)
     * 
     * 11/15 - Tested on Sieg Hall Harman/Kardon speakers and mike
     * 
     *     BAUD = 16
     * 	   Distance of speakers from mike = 5.5 ft
     * 	   Volume = 3/4 of max
     *     Treble = High
     *     Bass = Low
     *     Transferred: "a"
     *     
     *     BAUD = 32
     * 	   Distance of speakers from mike = 2.5 ft
     * 	   Volume = 3/4 of max
     *     Treble = High
     *     Bass = Low
     *     Transferred: "a"
     *     
     *     11/15 - Tested on Sieg Hall Altec speakers and mike
     *     note: when moving mike away from Altec speakers, 
     *           it helps to gradually start pointing it up
     * 
     *     BAUD = 16
     * 	   Distance of speakers from mike = 5.5 ft
     * 	   Volume = 2/3 of max
     *     Transferred: "a"
     *     
     *     BAUD = 32
     * 	   Distance of speakers from mike = 2.5 ft
     * 	   Volume = 2/3 of max
     *     Transferred: "a"
     *     
     */
    
    
}

