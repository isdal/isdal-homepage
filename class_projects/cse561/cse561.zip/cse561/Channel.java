
public class Channel implements CSE561_Settings{
	
    // Defines transmission frequency
	// Some freqs have more noise than others
	// Clock has to have most power,
	// for now that means it has to be the lowest set of freqs
	double FREQS_8[][];
	double FREQS_4[][];
	double FREQS_2[][];
	double FREQS_1[][];
	
	//Absolute noise threshold, one for each frequency band
	double THRESHOLD[][];
	
	int FFT_BAND[][];
	
	final double NOISE_FREQ=0;
	final int NOISE_FFT_BAND=0;
	
	
	//constructor
	public Channel () {
		
		if (NUM_CHANNELS < 3) {
			System.err.println("Cannot have less than 3 channels. Check settings file.");
			System.exit(-1);
		}
		else if (NUM_CHANNELS > 10) {
			System.err.println("Cannot have more than than 10 channels. Check settings file.");
			System.exit(-1);
		}

		FREQS_1 = new double [][]{
				{11250,11625},      //data bins 88 & 90 
				{12375,12750},      //clock bins 66 & 68
				{14062.5,14437.5}}; //data bins 75 & 77
		
		
		FREQS_2 = new double [][]{
				{11250,11625},        //data bins 68 & 70
				{12375,12750},		 //data bins 72 & 74
				{14250,14625},        //data bins 76 & 78
				{15000,15375}};		 //data bins 72 & 74
		
		FREQS_4 = new double [][]{
				{16500,16825},        //data bins 88 & 90 
				{10500,10875},        //clock bins 56 & 58
				{12750,13125},        //data bins 68 & 70
				{13500,13875},		 //data bins 72 & 74
				{14250,14625},        //data bins 76 & 78
				{15000,15375}};  	//data bins 80 & 82
			
		FREQS_8 = new double [][]{
				{16500,16825},        //data bins 88 & 90 
				{10500,10875},        //clock bins 56 & 58
				{8625,9000},            //data bins 46 & 48 
				{9750,10125},         //data bins 52 & 54
				{11250,11625},       //data bins 60 & 62
				{12000,12375},        //data bins 64 & 66
				{12750,13125},        //data bins 68 & 70
				{13500,13875},		 //data bins 72 & 74
				{14250,14625},        //data bins 76 & 78
				{15000,15375}};//,  	//data bins 80 & 82
				//{15750,16125}}; 	//data bins 84 & 86 
		
	    THRESHOLD = new double [][] {
	    						{0.125,0.125},
	    			            {0.6,0.6},
	    			            {0.125,0.125},
	    			            {0.125,0.125},
	    			            {0.125,0.125},
	    			            {0.125,0.125},
	    			            {0.125,0.125},
	    			            {0.125,0.125},
	    			            {0.125,0.125},{0.125,0.125},
	    			            {0.125,0.125}};

	    FFT_BAND = new int[][]     {
	    						   {0,0},
	    		                   {0,0},
	    		                   {0,0},
	    		                   {0,0},
	    		                   {0,0},
	    		                   {0,0},
	    		                   {0,0},
	    		                   {0,0},{0,0},
	    		                   {0,0},
	    		                   {0,0}};
	}
	
	double getFreq (int channel, int bit) {
		
		double result;
		
		if (channel <0 || bit <0 || channel>NUM_CHANNELS || bit > 1)
			result = -1;
		else {
			if (NUM_CHANNELS==3)
				result = FREQS_1[channel][bit];
			else if (NUM_CHANNELS<=4)
				result = FREQS_2[channel][bit];
			else if (NUM_CHANNELS<=6)
				result = FREQS_4[channel][bit];
			else if (NUM_CHANNELS<=10)
				result = FREQS_8[channel][bit];
		}
		
		return result;
	}
	
	double getThreshold (int channel, int bit) {
		
		double result;
		
		if (channel <0 || bit <0 || channel>=NUM_CHANNELS || bit > 1)
			result = -1;
		else
			result = THRESHOLD[channel][bit];
		
		return result;
	}
	
	int getFFTBand (int channel, int bit) {
		
		int result;
		
		if (channel <0 || bit <0 || channel>=NUM_CHANNELS || bit > 1)
			result = -1;
		else
			result = FFT_BAND[channel][bit];
		
		return result;
	}
	
	double getNoiseFreq() {
		return NOISE_FREQ;
	}
	
	int getNoiseFFTBand () {
		return NOISE_FFT_BAND;
	}

}
