import java.awt.Color;
import java.awt.GridLayout;
import java.awt.geom.Rectangle2D;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.jgraph.JGraph;
import org.jgraph.graph.CellView;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.DefaultPort;
import org.jgraph.graph.GraphConstants;
import org.jgraph.graph.GraphLayoutCache;
import org.jgraph.graph.GraphModel;

/**
 * 
 */

@SuppressWarnings("serial")
/**
 * 
 */
class GUI_GraphPanel extends JPanel implements CSE561_Settings {
	// private RouteCache routes;
	// private int myAddr;

	private JGraph graph;

	private Hashtable<Byte, NodePosition> oldNodes = new Hashtable<Byte, NodePosition>();

	private RouteCache routes = new RouteCache((byte) -1);

	public GUI_GraphPanel() {
		// this.myAddr = addr;
		setLayout(new GridLayout(1, 1));
		// Construct Model and Graph
		GraphModel model = new DefaultGraphModel();
		graph = new JGraph(model);

		// Control-drag should clone selection
		graph.setCloneable(false);

		// Enable edit without final RETURN keystroke
		graph.setInvokesStopCellEditing(true);

		// When over a cell, jump to its default port (we only
		// have one, anyway)
		graph.setJumpToDefaultPort(true);

		// Show in Frame

		add(new JScrollPane(graph));
	}

	public DefaultGraphCell createVertex(String name, double x, double y,
			double w, double h, Color bg, boolean raised) {

		// Create vertex with the given name
		DefaultGraphCell cell = new DefaultGraphCell(name);

		// Set bounds
		Rectangle2D bounds = new Rectangle2D.Double(x, y, w, h);

		GraphConstants.setBounds(cell.getAttributes(), bounds);
		// GraphConstants.setIcon(cell.getAttributes(), new ImageIcon(
		// "laptop_s.jpg"));

		if (USE_GUI_ICON) {
			GraphConstants.setIcon(cell.getAttributes(), new ImageIcon(
					"sat.jpg"));
		} else {
			// Set black border
			GraphConstants.setBorderColor(cell.getAttributes(), Color.black);

		}
		// Set fill color
		if (bg != null) {
			GraphConstants.setGradientColor(cell.getAttributes(), Color.orange);
			GraphConstants.setOpaque(cell.getAttributes(), true);
		}

		// Add a Port
		DefaultPort port = new DefaultPort();
		cell.add(port);
		port.setParent(cell);

		return cell;
	}

	public void updateRouteCache() {
		updateRouteCache(routes);
	}

	public void updateRouteCache(RouteCache routeCache) {
		routes = routeCache;
		int myAddr = routeCache.getMyAddr();
		double xdist = this.getWidth() / 12;

		double ydist = this.getWidth() / 16;
		System.out.print(("x:" + xdist) + " y:" + ydist);
		int[][] initialPositions = { { 4, 2 }, { 8, 4 }, { 6, 8 }, { 2, 6 },
				{ 7, 3 }, { 8, 6 }, { 4, 8 }, { 2, 4 }

		};

		Hashtable<Byte, NetworkRoute> routeHash = routeCache.getRoutes();
		Hashtable<Byte, NodePosition> nodes = new Hashtable<Byte, NodePosition>();
		Hashtable<int[], DefaultEdge> edges = new Hashtable<int[], DefaultEdge>();

		// Delete all deleted data
		// find deleted data (is in oldNodes but not in nodes

		graph.setGraphLayoutCache(new GraphLayoutCache());
		// graph.getGraphLayoutCache().remove(
		// graph.getGraphLayoutCache().getCells(true, true, true, true));

		int nodeNum = 0;
		for (Iterator iter = routeHash.keySet().iterator(); iter.hasNext();) {
			Byte key = (Byte) iter.next();
			NetworkRoute routes = routeHash.get(key);
			Vector<RoutePath> paths = routes.getPaths();
			for (Iterator iterator = paths.iterator(); iterator.hasNext();) {
				Vector<Byte> path = ((RoutePath) iterator.next()).getPath();
				byte previousNode = -1;
				byte node = -1;
				for (int i = 0; i < path.size(); i++) {
					node = path.get(i);

					// Add the nodes
					// System.out.println("Getting node:" + node);
					if (!nodes.containsKey(node)) {
						System.out.println("Adding node:" + node + "myaddr="
								+ myAddr);
						DefaultGraphCell vertex;
						if (oldNodes.containsKey(node)) {
							vertex = oldNodes.get(node).getCell();
							DefaultPort port = oldNodes.get(node).getPort();
							vertex.add(port);
							port.setParent(vertex);

						} else {
							if (myAddr == node) {
								// System.out.println("IT's me!!!:" + node);
								vertex = createVertex("Node: " + node,
										(int) (5 * xdist), (int) (5 * ydist),
										50, 70, null, false);
							} else {
								vertex = createVertex(
										"Node: " + node,
										initialPositions[(oldNodes.size() + nodeNum) % 7][0]
												* xdist,
										initialPositions[(oldNodes.size() + nodeNum) % 7][1]
												* ydist, 50, 70, null, false);
							}
						}

						nodes.put(node, new NodePosition(vertex,
								(DefaultPort) vertex.getChildAt(0)));
						graph.getGraphLayoutCache().insert(vertex);
						nodeNum++;
					}
					// Add the edges

					int[] edgeNodes = { node, previousNode };
					int[] edgeNodesInv = { previousNode, node };
					if (nodes.get(node) != null && previousNode != node
							&& nodes.get(previousNode) != null) {
						System.out.println("node:" + node + " previous node:"
								+ previousNode);
						if (!edges.containsKey(edgeNodes)
								&& !edges.containsKey(edgeNodesInv)) {
							int speed = -1;
							String speedText = "Unknown";
							System.out.println("nodes " + node + ":"
									+ previousNode);
							if ((node == myAddr) || (previousNode == myAddr)) {
								System.out.println("Setting speed");
								if (GUI_CrappyGui.getInstance().getLinkSpeed(
										(node)) != -1) {
									speed = GUI_CrappyGui.getInstance()
											.getLinkSpeed(((int) node));
									speedText = ""
											+ (SEND_SPEEDS[speed][0] * SEND_SPEEDS[speed][1])
											+ " bps";
								} else if (GUI_CrappyGui.getInstance()
										.getLinkSpeed((previousNode)) != -1) {
									speed = GUI_CrappyGui.getInstance()
											.getLinkSpeed(((int) previousNode));
									speedText = ""
											+ (SEND_SPEEDS[speed][0] * SEND_SPEEDS[speed][1])
											+ " bps";
								}
							}
							// Create Edge
							DefaultEdge edge = new DefaultEdge(speedText);
							// Fetch the ports from the new vertices,
							// and connect them with the edge
							// System.out.println("Getting node" + node);
							edge.setSource(nodes.get(node).getPort());
							// System.out.println("Getting node" +
							// previousNode);
							edge.setTarget(nodes.get(previousNode).getPort());

							GraphConstants.setForeground(edge.getAttributes(),
									Color.BLACK);
							if (speed != -1) {
								GraphConstants.setLineWidth(edge
										.getAttributes(), 10 - speed * 3);
								Color lineColor = Color.BLACK;
								switch (speed) {
								case 0:
									lineColor = new Color(0, 255, 0);
									break;
								case 1:
									lineColor = new Color(0, 192, 0);
									break;
								case 2:
									lineColor = new Color(0, 128, 0);
									break;
								}

								GraphConstants.setLineColor(edge
										.getAttributes(), lineColor);
							}
							// System.out.println("Adding edge:" + node + ","
							// + previousNode);
							edges.put(edgeNodes, edge);
							graph.getGraphLayoutCache().insert(edge);
							nodeNum++;
						}
					}

					previousNode = node;
				}
			}
		}

		// for (Iterator iter = nodes.keySet().iterator(); iter.hasNext();) {
		// Byte key = (Byte) iter.next();
		// DefaultGraphCell vertex = nodes.get(key);
		// cells[cellIndex] = vertex;
		// cellIndex++;

		// for (Iterator iter = edges.keySet().iterator(); iter.hasNext();) {
		// byte[] edgeNodes = (byte[]) iter.next();
		// DefaultEdge edge = edges.get(edgeNodes);
		// cells[cellIndex] = edge;
		// cellIndex++;
		// }

		// Store the existing nodes for later use
		oldNodes = nodes;

	}

	class NodePosition {
		private DefaultGraphCell cell;

		private DefaultPort port;

		private int x;

		private int y;

		private int width;

		private int height;

		public NodePosition(DefaultGraphCell cell, DefaultPort port) {
			this.cell = cell;
			this.port = port;

		}

		public NodePosition(DefaultGraphCell cell, int x, int y, int width,
				int height) {
			this.cell = cell;
			this.x = x;
			this.y = y;
			this.width = width;
			this.height = height;
		}

		public DefaultGraphCell getCell() {
			return cell;
		}

		public DefaultPort getPort() {
			return port;
		}

		public int getX() {
			return x;
		}

		public int getY() {
			return y;
		}

		public int getWidth() {
			return width;
		}

		public int getHeight() {
			return height;
		}

	}

}