import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class RoutePath {

	Vector<Byte> path;

	public RoutePath() {
		path = new Vector<Byte>();
	}

	public RoutePath(Vector<Byte> path) {
		this.path = path;
	}

	public RoutePath(List<Byte> path) {
		this.path = new Vector<Byte>(path);
	}

	public void add(Byte node) {
		path.add(node);
	}

	public Iterator iterator() {
		return path.iterator();
	}

	public int size() {
		return path.size();
	}

	public byte get(int index) {
		return path.get(index);
	}

	public byte getNextHop() {
		if (path.size() == 1) {
			return path.get(0);
		} else {
			return path.get(1);
		}
	}

	public byte getNextHop(Byte node) {
		int myIndex = path.indexOf(node);
		if (myIndex == path.size() - 1) {
			return path.get(myIndex);
		}
		return path.get(myIndex + 1);

	}

	public byte getTarget() {
		return path.get(path.size() - 1);
	}

	public byte getSource() {
		return path.get(0);
	}

	public RoutePath getSubPath() {
		if (path.size() > 0) {
			return new RoutePath(path.subList(0, path.size() - 1));
		}
		return new RoutePath();
	}
	public Vector<Byte> getPath(){
		return path;
	}

	public RoutePath clone() {
		return new RoutePath(path);
	}

	public boolean containsInPath(Byte node) {
		int index = path.indexOf(node);
		if (index > 0 && index < path.size() - 1) {
			return true;
		}
		return false;
	}

	public boolean contains(Byte node1, Byte node2) {
		int node1pos = path.indexOf(node1);
		int node2pos = path.indexOf(node2);
		if (node1pos != -1 && node2pos != -1) {
			if (Math.abs(node1pos - node2pos) == 1) {
				System.out.println("(" + node1 + "," + node2 + ") is in "
						+ path.toString());
				return true;
			}
		}
		return false;
	}

	public String toString() {
		StringBuffer str = new StringBuffer();
		str.append("(");
		for (int j = 0; j < path.size(); j++) {
			str.append("" + path.get(j) + ", ");
		}
		str.append(")\n");
		return str.toString();

	}

	public RoutePath[] split(Byte addr) {

		if (path.contains(addr)) {
			RoutePath subPath = new RoutePath(path.subList(0, path
					.indexOf(addr) + 1));
			RoutePath subPath2 = new RoutePath(path.subList(path.indexOf(addr),
					path.size()));
			subPath2 = subPath2.invertPath();
			System.out.print("RP: Slit into: ");
			System.out.print(subPath.toString());
			System.out.print("RP: and  into: ");
			System.out.print(subPath2.toString());

			RoutePath[] paths = { subPath, subPath2 };
			return paths;
		}
		RoutePath[] empty = { new RoutePath() };
		return empty;
	}

	public RoutePath invertPath() {
		Vector<Byte> invPath = new Vector<Byte>(path.size());
		for (int i = path.size() - 1; i >= 0; i--) {
			invPath.add(path.get(i));

		}
		return new RoutePath(invPath);
	}

	public boolean equals(RoutePath comparePath) {
		if (comparePath.path.equals(path)) {
			return true;
		}
		return false;
	}
	
	public byte[] toByteArray(){
		byte[] byteArray = new byte[path.size()];
		for (int i = 0; i < path.size(); i++) {
			byteArray[i] = path.get(i);
		}
		return byteArray;
	}
}
