import java.util.concurrent.LinkedBlockingQueue;
import java.util.*;

// The MAC layer has the following functionality. When it receives a packet
// from the physical layer it sends and ACK and passes the packet onto the 
// network layer
// When it receives a packet for transmission from the n/w layer, it sends it?

// Need to consider issues of backoff, synchronizing between ack/data packets, etc
public class MacLayer implements CSE561_Settings {

	private int[] seqNo = new int[16];

	private int currentBackoffValue = -1;

	private final int IDLE = 0;

	private final int WFACK = 1;

	// TODO need to decide units for cw
	private final int CW_MIN = 2;

	private final int CW_LIM = 32;

	private int cw = CW_MIN;

	private final int RETRY_LIMIT = 6;

	private final int BACKOFF_DECREMENT_INTERVAL = 1000; // decrement backoff

	// every second

	private int RETX_TIMEOUT = 11000; // milliseconds

	// we can probably do away with this and manage with
	// only the backoff or vice versa

	private int myAddr;

	private int expectingAckFrom = -1;

	private int retxCount = 0;

	private boolean channelIdle = true;

	// defines the state of the MAC layer .. possible options:
	// 0 IDLE
	// 1 WAITING FOR ACK
	// 2 BACKING OFF
	private int state;

	private int numChannels = NUM_CHANNELS;

	private Timer timer = new Timer();

	// private LinkedBlockingQueue<MacPacket> sendBuffer;

	private LinkedBlockingQueue<MacPacket> receiveBuffer;

	private PacketReceiver receiver;

	private NetworkLayer networkLayer;

	private Sender physicalLayer;

	// this is the packet that is being sent and hasn't
	// yet been ACKed
	private MacPacket bufferedPacket = null;;

	private BackoffDecrementTimer boTimer = new BackoffDecrementTimer();

	private RetxTimer retxTimer = new RetxTimer();

	private MacSenderThread macSender = new MacSenderThread();

	private MacReceiverThread macRecv = new MacReceiverThread();

	private int[] lastSeqNoSeen = new int[16];
	private double[] amps = new double[16];

	private HashMap<Integer, Integer> speeds;

	public MacLayer(NetworkLayer nl, int macAddress) {
		System.out.println("Starting MacLayer");
		if (USE_GUI)
			GUI_CrappyGui.getInstance().printMacMessage("Starting MacLayer\n");
		for (int i = 0; i < 16; i++)
		{
			lastSeqNoSeen[i] = seqNo[i] = -1;
			amps[i] = 0.2;
		}
		amps[15] = 1; // broadcast volume is always max!!

		// sendBuffer = new LinkedBlockingQueue<MacPacket>();
		speeds = new HashMap<Integer, Integer>();
		receiveBuffer = new LinkedBlockingQueue<MacPacket>();
		receiver = new PacketReceiver(this);
		networkLayer = nl;
		physicalLayer = new Sender(this);
		physicalLayer.start();
		myAddr = macAddress;
		receiver.start();
		macSender.setPriority(1);
		macRecv.setPriority(1);
		macSender.start();
		macRecv.start();

	}

	public void setSpeed(int node, int speed) {
		speed = Math.min(SEND_SPEEDS.length - 1, speed);
		speed = Math.max(0, speed);
		// System.err.println("Setting speed - node: " + node + " speed: " +
		// speed);
		speeds.put(node, speed);
		if (USE_GUI)
			GUI_CrappyGui.getInstance().setLinkSpeeds(speeds);
	}

	public int getSpeed(int node) {
		// System.err.print("Getting speed - node: " + node);
		if (node == BROADCAST_ADDR) {
			// System.err.println(" speed: " + BROADCAST_SPEED);
			return BROADCAST_SPEED;
		}
		if (speeds.get(node) != null) {
			// System.err.println(" speed: " + speeds.get(node));
			return speeds.get(node);
		}
		// System.err.println(" speed: " + 0);
		return 0;
	}

	public void increaseSpeed(int node) {
		setSpeed(node, getSpeed(node) - 1);
	}

	public void decreaseSpeed(int node) {
		setSpeed(node, getSpeed(node) + 1);
	}
	
	public void increaseAmp( int node )
	{
		amps[node] += 0.2;
		if(amps[node] > 1)
			amps[node] = 1;
	}
	// TODO
	// The sender is dumb and should not have a queue. The MAC decides
	// when to send the data and the sender sends immediately
	// public void sendData(MacPacket data) {
	// if(data.getDestAddr()==BROADCAST_ADDR){
	// physicalLayer.setSpeed(BROADCAST_SPEED);
	// }
	// physicalLayer.queuePacket(data);
	// }

	// TODO - need to handle InterruptedException in most places
	// this function is called by the physical layer when it has
	// received a packet on the radio
	public void putPacketinMacQueue(MacPacket p) {
		// System.err.println("debug: Packet put by physical layer");
		receiveBuffer.add(p);
	}

	public void setState(int state) {
		this.state = state;
	}

	public int getMacState() {
		return this.state;
	}

	public void notifyRadioStatusChanged(boolean chIdle) {
		channelIdle = chIdle;
		if(USE_GUI_CHANNEL_STATE)GUI_CrappyGui.getInstance().setChannelState(channelIdle);
		// System.out.println("Radio status: channel idle = " + channelIdle);
		macSender.wake();
	}

	// since the ack is received, the timer can be cancelled and
	// the packet can be removed from the queue
	private void processAck() {
		assert (state == WFACK);
		bufferedPacket = null;
		setState(IDLE);
		resetCW();
		macSender.wake();
		System.err.println("# transmissions required: " + retxCount);
		retxCount = 0; // reset retx counter
		// cancel the retxtimer
		retxTimer.cancel();

	}

	private void resetCW() {
		cw = CW_MIN;
		// TODO Auto-generated method stub
		
	}
	
	public void doubleCW() {
		cw *= 2;
		if(cw > CW_LIM )
			cw = CW_LIM;
	}

	private int nextSeqNo(int dest) {
		return (seqNo[dest]++) % 2;
	}

	// this is the thread that receives data from the physical layer
	// it processes the packet from the physical layer and sends it
	// to the network layer, if required after first sending an ACK
	// back to the sender
	// On receiving an ACK, it removes the sent packet from the front
	// of the queue and proceeds to the next packet

	// note: we assume that the packet is correct, i.e. CRC is fine
	class MacReceiverThread extends Thread {

		public void run() {
			MacPacket dataFromPhysical;

			try {
				while (true) {
					// System.err.println("waiting for data in receive buffer");
					// TODO: implement interruptedException
					dataFromPhysical = receiveBuffer.take();

					System.err.println("debug: " + myAddr + " packet from "
							+ dataFromPhysical.getSourceAddr() + " to "
							+ dataFromPhysical.getDestAddr() + " len: "
							+ dataFromPhysical.getDataLength() + " "
							+ dataFromPhysical.isACK());
					// // if packet is not for me .. drop it
					int dest = dataFromPhysical.getDestAddr();
					if (dest != myAddr && dest != BROADCAST_ADDR) {
						networkLayer.addLink(dataFromPhysical.getSourceAddr());
						continue;
					}

					if (dest == BROADCAST_ADDR) {
						int src = dataFromPhysical.getSourceAddr();
						if(USE_GUI)GUI_CrappyGui.getInstance().printMacMessage(
								"Received BROADCAST packet from " + src + "\n");
						System.out.println("MAC: Recd broadcast - "
								+ dataFromPhysical.toString());
						networkLayer.putDataForNetwork(new NetworkLayerPacket(
								dataFromPhysical.getPayload()));
						continue;
					}

					// if its an ACK packet, remove the packet from
					// the head of the queue
					if (dataFromPhysical.isACK()) {
						increaseSpeed(dataFromPhysical.getSourceAddr());
						System.err.println("ACK: state = " + state);
						if (state == WFACK
								&& dataFromPhysical.getSourceAddr() == expectingAckFrom) {
							System.err
									.println("Received ACK: dataFromPhysical.getSourceAddr()");
							int src = dataFromPhysical.getSourceAddr();
							if(USE_GUI)GUI_CrappyGui.getInstance().printMacMessage(
									"Received ACK from " + src + "\n");
							processAck();
						} else
							continue;
					}
					// otherwise pass it on to network layer and send an ACK
					else {
						// reply with an ACK to the sender
						System.out.println("MAC: Recd unicast - "
								+ dataFromPhysical.toString());
						int seqNo = dataFromPhysical.getSeqNumber();
						int srcAddr = dataFromPhysical.getSourceAddr();
						if(USE_GUI)GUI_CrappyGui.getInstance().printMacMessage(
								"Received UNICAST from " + srcAddr + "\n");
						sendAckPacket(srcAddr, seqNo);

						if (lastSeqNoSeen[srcAddr] != seqNo) {
							lastSeqNoSeen[srcAddr] = seqNo;
							networkLayer
									.putDataForNetwork(new NetworkLayerPacket(
											dataFromPhysical.getPayload()));
						}
					}
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		private void sendAckPacket(int destAddr, int seqNum) {
			System.err.println("MAC: sending Ack to " + destAddr);
			byte[] data = new byte[0];
			MacPacket ackPacket = new MacPacket(myAddr, destAddr, seqNum, data);
			// send the packet immediately ... hopefully this should work fine
			// force other nodes to wait for atleast 't' after seeing an idle
			// channel before backing off
			// TODO call the physical layer's send function
			if(USE_GUI)GUI_CrappyGui.getInstance().printMacMessage(
					"Sending ACK to " + destAddr + "\n");
			physicalLayer.queuePacket(ackPacket);
			// once the channel becomes idle again, i can start backing off

		}

	}

	// this class models the sender thread in the MAC layer
	// it continuously listens for data from the network layer
	// and then tries to send it. it waits if the network is
	// busy ... and once it becomes idle, it starts backingoff
	// when the backoff timer expires, it sends the packet ;)

	// when the sender waits for the channel to become idle, it is
	// woken up by the physical layer by calling notifyRadioStatusChanged()
	class MacSenderThread extends Thread {
		public void run() {
			try {
				sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			while (true) {
				if (bufferedPacket == null) {

					NetworkData temp = networkLayer.getTopPacketFromQueue();
					System.err.println("NW Pkt Size: "
							+ temp.getPacket().toBitArray().length() + " *to* "
							+ temp.getNextHop());
					System.err.println("NW Pkt: "
							+ temp.getPacket().toBitArray().toString());
					bufferedPacket = new MacPacket(myAddr, temp.getNextHop(),
							nextSeqNo(temp.getNextHop()), (temp.getPacket()).toBitArray());
					System.err.println("MAC Pkt: " + bufferedPacket.toString());
				}
				// got the top packet from the network layer
				// if channel is idle, start backoff

				if (channelIdle && getMacState() == IDLE) {
					if (currentBackoffValue <= 0) {
						currentBackoffValue = (int) Math.round(Math.random()
								* (cw));
						currentBackoffValue = (currentBackoffValue==0?1:currentBackoffValue);
						System.out.println("CW: " + cw);
						GUI_CrappyGui.getInstance().initializeBackoff(currentBackoffValue);
						System.err
								.println("MAC sender thread: debug: backoff = "
										+ currentBackoffValue);
					}
					boTimer.cancel();
					boTimer = new BackoffDecrementTimer();
					timer.schedule(boTimer, BACKOFF_DECREMENT_INTERVAL);
				}
				do {

					waitForState();
					// System.out.println("channel busy .. cancel timer (BO = "
					// + currentBackoffValue + ")");
					boTimer.cancel(); // need to cancel the backoff when the
					// channel is busy
				} while (getMacState() != IDLE || !channelIdle);
				// we wake up after notification here !!!
				// could wake up due to change in channel state
				// or because the timer ran out
				// if the timer ran out, we need to transmit (if channel idle)
				// otherwise we need to set the timer
			}

		}

		// //TODO: Notify the sendermac thread!!
		// public synchronized void notifyRadioStatusChanged(boolean chIdle)
		// {
		// channelIdle = chIdle;
		// notify();
		// }

		public synchronized void wake() {
			this.notify();
		}

		public synchronized void waitForState() {
			try {
				// we wait till channel is idle and we are idle as well
				wait();

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		// when channel is free the buffered packet is transmitted,
		// thus we have a retransmission
		public void retransmitPacket() {
			setState(IDLE);
			wake();
		}

	}

	// for the sake of fairness, we now have a backoff timer that
	// suspends when the channel becomes busy. we implement this with
	// a variable whose value is initialized when the backoff timer is
	// started. then every second, the value is decremented. if while
	// the timer is running, the channel is sensed busy, then the timer
	// is cancelled and restarted when the channel becomes idle
	class BackoffDecrementTimer extends TimerTask {
		public void run() {
			currentBackoffValue--;
			GUI_CrappyGui.getInstance().setCurrentBackoff(currentBackoffValue);
			System.out.println("Backoff value: " + currentBackoffValue);
			if (currentBackoffValue == 0) // the timer has expired!!! hurray!
			{
				// we can now transmit!!
				backoffCompleted();
			} else {
				// currentBackoffValue =
				// (int)Math.round(Math.random()*(CW_MAX-CW_MIN)+CW_MIN);
				boTimer = new BackoffDecrementTimer();
				timer.schedule(boTimer, BACKOFF_DECREMENT_INTERVAL);
			}
		}
	}

	// the run method is executed when the backoff timer expires
	// when the backoff timer expires, check the mac state and the
	// state of the channel, if both are idle and we have a packet
	// to send - send it
	public void backoffCompleted() {
		// System.err.println("Backoff completed ... mac = " + getMacState() + "
		// channelIdle = " + channelIdle);

		if (getMacState() == IDLE) {
			if (channelIdle) {
				assert (bufferedPacket != null);
				System.out.println("MAC: sending - "
						+ bufferedPacket.toString());

				physicalLayer.setSpeed(getSpeed(bufferedPacket.getDestAddr()));
				physicalLayer.setAmp(amps[(bufferedPacket.getDestAddr())]);
				//if(USE_GUI) GUI_CrappyGui.getInstance().updateLinkSpeeds();
				// GUI_CrappyGui.getInstance().printMacMessage("Backoff
				// completed: Received ACK from " + src + "\n");

				physicalLayer.queuePacket(bufferedPacket);
				// once we send the broadcast -- remove the packet .. no ack
				// expected
				int speedIndex = getSpeed(bufferedPacket.getDestAddr());
				int bps = SEND_SPEEDS[speedIndex][0] * SEND_SPEEDS[speedIndex][1];
				System.out.println("Backoff speed: " + bps);
				RETX_TIMEOUT = ((bufferedPacket.length() / bps)+5) * 1000;

				if (bufferedPacket.getDestAddr() != BROADCAST_ADDR) {
					timer.schedule(retxTimer = new RetxTimer(), RETX_TIMEOUT);
					setState(WFACK);
					expectingAckFrom = bufferedPacket.getDestAddr();
				} else
					bufferedPacket = null;
			} else {
				// channel not idle ... restart backoff
				// TODO this may cause problems!!!
				// once i transmit (successfully or unsuccessfully) i should
				// back off
				// currentBackoffValue =
				// (int)Math.round(Math.random()*(CW_MAX-CW_MIN)+CW_MIN);
				// System.err.println("MAC BoTimer thread: debug: backoff = " +
				// currentBackoffValue);
				boTimer.cancel();
				boTimer = new BackoffDecrementTimer();
				timer.schedule(boTimer, BACKOFF_DECREMENT_INTERVAL);
			}
		}
	}

	class RetxTimer extends TimerTask {
		public void run() {
			System.err.println("RetX timer expired");
			// timer expired, retransmit the data since we
			// didn't get ACK
			retxCount++; // increment retx counter
			
			decreaseSpeed(bufferedPacket.getDestAddr());
			increaseAmp(bufferedPacket.getDestAddr());
			if (retxCount > RETRY_LIMIT) {
				retxCount = 0;
				physicalLayer.resetNumChannels();
				networkLayer.notifyPacketDrop(new NetworkLayerPacket(
						bufferedPacket.getPayload()));
				nextSeqNo(bufferedPacket.getDestAddr());
				bufferedPacket = null;
				setState(IDLE);
				resetCW();
				macSender.wake();
			} else {
				// failed sending need exponential backoff
				GUI_CrappyGui.getInstance().printMacMessage("Retry # " + retxCount + "\n" );
				doubleCW();
				macSender.retransmitPacket();
			}
		}
	}

	
}