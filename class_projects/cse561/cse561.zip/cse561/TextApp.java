import java.io.InputStreamReader;
import java.io.BufferedReader;

//import java.util.ArrayList;

public class TextApp extends ApplicationLayer {
	// NetworkLayer network;

	public TextApp(int myAddr) {

		if(USE_GUI)GUI_CrappyGui.getInstance(myAddr,this);
		//GUI_CrappyGui.getInstance().printNetMessage("Hello again\n");
		

		setAddr(myAddr);
		try {
			TextAppReceiveThread receiveThread = new TextAppReceiveThread(
					network);
			receiveThread.start();
			String line;

			InputStreamReader stdin = new InputStreamReader(System.in);
			BufferedReader console = new BufferedReader(stdin);

			while (true) {
				try {
					System.out.println("Enter destination");
					int dst = 0;
					dst = Integer.parseInt(console.readLine());
					System.out
							.println("Write some text to send that, x to exit");
					line = console.readLine();
					if (line.equals("x")) {
						System.exit(0);

					} else {
						byte[] packetData = line.getBytes();
						BitArray data = new BitArray(packetData);
						send(dst, data);
						// System.out.println(data.toString());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TextApp app = new TextApp(Integer.parseInt(args[0]));

	}

	class TextAppReceiveThread implements Runnable {
		NetworkLayer network;

		private volatile Thread recieveThread = null;

		public TextAppReceiveThread(NetworkLayer network) {
			this.network = network;
		}

		public void start() {
			if (recieveThread == null) {
				recieveThread = new Thread(this, "Recieve");
				recieveThread.start();
			}
		}

		public void stop() {
			recieveThread = null;
		}

		public void run() {
			while (true) {
				System.out.println("running reciever, waiting for packet");
				ApplicationLayerData data;
				try {
					data = receive();
					System.out.println("Recieved packet: \""
							+ new String(data.getData().toByteArray()) + "\"");
					if(USE_GUI)GUI_CrappyGui.getInstance().printDataMessage(data.getDest() + ": " + new String(data.getData().toByteArray()));
					// System.out.println("Recieved packet: \""+ data.toString()
					// +
					// "\"");
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// this.start();
			}
		}
	}
}
