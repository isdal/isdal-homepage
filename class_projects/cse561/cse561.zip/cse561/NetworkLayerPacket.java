import java.util.ArrayList;

public class NetworkLayerPacket implements CSE561_Settings {

	private int type = 0;

	private int srcAddr = 0;

	private int dstAddr = 0;

	private int seqNum = 0;

	private RoutePath routeHops = new RoutePath();

	private BitArray payload;

	public NetworkLayerPacket() {
	}

	/**
	 * Constructor: create a new packet from a MAC packet payload
	 * (packet.getPayload())
	 */
	public NetworkLayerPacket(BitArray bitarray) {
		int bitArrayPos = 0;
		this.type = bitarray.getInt(bitArrayPos, TYPE_FIELD_BITS);
		bitArrayPos += TYPE_FIELD_BITS;
		this.srcAddr = bitarray.getInt(bitArrayPos, LENGTH_FIELD_BITS);
		bitArrayPos += LENGTH_FIELD_BITS;
		this.dstAddr = bitarray.getInt(bitArrayPos, LENGTH_FIELD_BITS);
		bitArrayPos += LENGTH_FIELD_BITS;
		this.seqNum = bitarray.getInt(bitArrayPos, SEQ_FIELD_BITS);
		bitArrayPos += SEQ_FIELD_BITS;
		int hopCount = bitarray.getInt(bitArrayPos, LENGTH_FIELD_BITS);
		bitArrayPos += LENGTH_FIELD_BITS;
		for (int i = 0; i < hopCount; i++) {
			routeHops.add((byte) bitarray
					.getInt(bitArrayPos, LENGTH_FIELD_BITS));
			bitArrayPos += LENGTH_FIELD_BITS;
		}
		payload = bitarray.getBitArray(bitArrayPos, bitarray.length());
	}

	/**
	 * Constructor from existing data
	 * 
	 * @param type
	 *            packet type: PACKET_TYPE_DATA, PACKET_TYPE_RREQ,
	 *            PACKET_TYPE_RREP, PACKET_TYPE_RERR
	 * @param srcAddr
	 *            packet source address
	 * @param dstAddr
	 *            packet destination address
	 * @param seqNum
	 *            packet sequence number
	 */

	public NetworkLayerPacket(int type, int srcAddr, int dstAddr, int seqNum,
			RoutePath routeHops, BitArray payload) {
		this.type = type;
		this.srcAddr = srcAddr;
		this.dstAddr = dstAddr;
		this.seqNum = seqNum;
		this.routeHops = routeHops;
		this.payload = payload;

	}

	/**
	 * Returns the type of the packet
	 * 
	 * @return packet type
	 */
	public int getType() {
		return this.type;
	}

	/**
	 * Returns the network address of the source
	 * 
	 * @return source address
	 */
	public int getSrcAddr() {
		return this.srcAddr;
	}

	/**
	 * Returns the network address of the destination
	 * 
	 * @return destination address
	 */
	public int getDstAddr() {
		return this.dstAddr;
	}

	/**
	 * returns the sequence numer of this packet
	 * 
	 * @return sequence number
	 */
	public int getSeqNum() {
		return this.seqNum;
	}

	/**
	 * Returns the packet hop count
	 * 
	 * @return hop count
	 */
	public int getHopCount() {
		return routeHops.size();
	}

	/**
	 * Returns the packet payload
	 * 
	 * @return payload
	 */
	public BitArray getPayload() {
		return this.payload;
	}

	/**
	 * Returns the total length of the packet header
	 * 
	 * @return header length
	 */
	public int headerLength() {
		return TYPE_FIELD_BITS + SEQ_FIELD_BITS + (routeHops.size() + 3)
				* LENGTH_FIELD_BITS;
	}

	/**
	 * Returns the path stored in the header as an arraylist
	 * 
	 * @return path
	 */
	public RoutePath getPath() {
		return routeHops.clone();
	}

	/**
	 * Returns the path stored in the header reversed
	 * 
	 * @return path
	 */
	public RoutePath getReversePath() {
		return routeHops.invertPath();
	}

	/**
	 * Returns the last hop ... used in RERR packets
	 * 
	 * @return The last hop in the path
	 */
	public Byte getLastHop() {
		return (routeHops.get(routeHops.size() - 1));
	}

	public void addHop(byte addr) {

		routeHops.add(new Byte(addr));
	}

	/**
	 * Returns the packet represented as an BitArray
	 * 
	 * @return packet bits
	 */
	public BitArray toBitArray() {
		BitArray bitArray = new BitArray();
		bitArray.add(getType(), TYPE_FIELD_BITS);
		bitArray.add(getSrcAddr(), LENGTH_FIELD_BITS);
		bitArray.add(getDstAddr(), LENGTH_FIELD_BITS);
		bitArray.add(getSeqNum(), SEQ_FIELD_BITS);
		bitArray.add(getHopCount(), LENGTH_FIELD_BITS);
		for (int i = 0; i < getHopCount(); i++) {
			bitArray.add(routeHops.get(i), LENGTH_FIELD_BITS);
		}
		bitArray.add(payload);
		return bitArray;
	}
	

}
