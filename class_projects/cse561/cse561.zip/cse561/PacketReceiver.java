import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.lang.InterruptedException;
import java.util.Vector;

public class PacketReceiver extends Thread implements CSE561_Settings {

	private Receiver recorder;

	private int state = -1;

	private MacLayer macLayer;

	private PrintStream output_file;

	/**
	 * Constructor
	 */
	public PacketReceiver(MacLayer macLayer) {
		this.setPriority(1);
		this.macLayer = macLayer;
		recorder = new Receiver(macLayer);
		try {
			output_file = new PrintStream(new FileOutputStream("packet.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void start() {
		System.out.println("Starting Reciever");
		recorder.start();
		super.start();
	}

	public void stopReceiving() {
		// close all objects
		recorder.stopRecording();
	}

	public void run() {

		while (true) {
			// receive packet
			MacPacket packet = receive_packet();
			if (packet != null) {

				// check CRC
				boolean crcCheckPassed = packet.checkCRC();
				// if correct
				if (crcCheckPassed) {// add to packet MAC Layer

					macLayer.putPacketinMacQueue(packet);
					System.err.println("Received packet: CRC check = Success");

				} else {// retransmit
					System.err.println("Received packet: CRC check = Failed");
				}
			} else
				System.err.println("\nReceived fragment, missing "
						+ (packet.getDataLength() * 8 + HEADER_LENGTH
								+ CRC_FIELD_BITS - packet.length()));
		}

	}

	private MacPacket receive_packet() {

		state = -1;
		// MacPacket current_packet = new MacPacket();

		MultiChannelMacPacket current_packet = new MultiChannelMacPacket();
		try {
			// wait for sync signal
			int syncbit = 0;
			do {
				syncbit = getBitFromReceiver();
			} while (syncbit != 2);
			System.err.println("Got Sync");
			// reconstruct packet
			while (true) {
				int bit = getBitFromReceiver();

				if (bit == 2) { // received fragment
					// clear state, start receiving new packet
					System.err.println("Got Sync");
					state = -1;
					System.err.println("Received fragment");
					current_packet = new MultiChannelMacPacket();

				}

				if (bit == 0 || bit == 1 || bit == -1) {
					// System.out.print("" + bit);
					if (bit == -1) {
						bit = (int) Math.round(Math.random());
					}
					current_packet.addBit(bit == 1);
					// TODO TEST CHANGE!!!!!!!!!!!!!!!!!!!!!!!!
					//output_file.println(current_packet.toString());
					if (current_packet.getPacket() != null) {
						return current_packet.getPacket();

					}
					// System.out.print(""+bit);
				}

			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// System.out.println("Length: " + b_data.length);
		// current_packet = new Packet(i_srcAddress, i_destAddress,
		// seqNum,b_data, i_CRC);
		return current_packet.getPacket();
	} // waits until a bit is available at Receiver

	// gets bit and returns it as an int
	private int getBitFromReceiver() throws InterruptedException {
		// System.out.println("Getting bit from bit reciever");

		int current_bit = current_bit = recorder.getBit();
		/*
		 * int current_bit = -1; boolean got_bit = false;
		 * 
		 * do {
		 * 
		 * if (recorder.isBitAvailable()) { current_bit =
		 * recorder.getBit().intValue(); got_bit = true; } else { try {
		 * sleep(1000); } catch (InterruptedException e) { e.printStackTrace(); } } }
		 * while (!got_bit);
		 */
		return current_bit;
	}

	class MultiChannelMacPacket {
		private Vector<MacPacket> packets;

		private int bitCount;

		public MultiChannelMacPacket() {
			bitCount = 0;
			packets = new Vector<MacPacket>();
			for (int i = 0; i <= Math.log(NUM_CHANNELS - 2) + 1; i++) {
				packets.add(new MacPacket());
			}
		}

		public void addBit(boolean bit) {
			for (int i = 0; i < packets.size(); i++) {
				if (i >= Math.log10((bitCount % (NUM_CHANNELS - 2)) + 1)
						/ Math.log10(2)) {
					// System.err.println("i+" + i + " Math.log=" +
					// Math.log(((bitCount % (NUM_CHANNELS-2))+ 1),2));
					packets.get(i).addBit(bit);
				}
			}
			bitCount++;
			// System.out.print(toString());
		}

		public MacPacket getPacket() {
			for (int i = 0; i < packets.size(); i++) {
				MacPacket current_packet = packets.get(i);
				if (current_packet.length() == current_packet.getDataLength()
						+ HEADER_LENGTH + CRC_FIELD_BITS) {
					if (current_packet.checkCRC()) {
						System.err
								.println("Returning packet. Packet sent with "
										+ ((int) Math.pow(2, i)) + " Channels");

						if (current_packet.getDestAddr() != BROADCAST_ADDR) {
							int speed = 0;

							int channels = ((int) Math.pow(2, i));
							for (int j = 0; j < SEND_SPEEDS.length; j++) {
								if (channels == SEND_SPEEDS[j][1]) {
									speed = j;
									break;
								}
							}
							macLayer.setSpeed(current_packet.getSourceAddr(),
									speed);
						}
						return current_packet;
					}
				}
			}
			return null;
		}

		public String toString() {
			StringBuffer str = new StringBuffer();
			str.append("\nCurrently in MultiChannelMacPacket\n");
			for (int i = 0; i < packets.size(); i++) {
				str.append("Packet " + i + ": " + packets.get(i).toString()
						+ "\n");
			}
			return str.toString();
		}

	}
}
