/**
 * The bit array class that functs as an array of boolean, in which each
 * elements takes one bit. The return type of matrix comparison.
 * 
 * Based on code written by Hanhua Feng - hanhua@cs.columbia.edu minor changes
 * made by the author
 * 
 * @author Tomas Isdal - isdal@cs.washington.edu
 * @version $Id: BitArray.java,v 1.14 2005/12/06 08:30:18 isdal Exp $
 */
public class BitArray implements Cloneable, CSE561_Settings {
	private static final int CELL_SIZE = 8;

	private int size;

	private byte[] barray;

	private int currentLength;

	/**
	 * Constructor creates a new bitarray of size 1
	 * 
	 */
	public BitArray() {
		currentLength = 0;
		size = 1;
		barray = new byte[(size + 7) / 8];
	}

	/**
	 * Constructor
	 * 
	 * @param n
	 *            max length of the bit array
	 */

	/**
	 * Constructor from existing integer array
	 * 
	 * @param n
	 *            length of the bit array
	 * @param a
	 *            integer array containing all bits
	 */
	private BitArray(int n, byte[] a) {
		size = n;
		barray = a;
		currentLength = n;
	}

	public BitArray(byte[] a) {
		currentLength = 0;
		size = 1;
		barray = new byte[(size + 7) / 8];

		add(a);

	}

	/**
	 * Return a new copy of the bit array
	 * 
	 * @return copy of this bit array
	 */
	public BitArray copy() {
		return new BitArray(size, (byte[]) barray.clone());
	}

	/**
	 * Implements the method in Cloneable
	 * 
	 * @return copy of this bit array as Object
	 */
	public Object clone() {
		return copy();
	}

	/**
	 * get the current max length of the bit array
	 */
	public int maxLength() {
		return size;
	}

	/**
	 * get the current length of the bit array
	 */
	public int length() {
		return currentLength;
	}

	/**
	 * Set one bit in the bit array
	 * 
	 * @param bit
	 *            index of this bit
	 * @param value
	 *            boolean value
	 */
	public void set(int bit, boolean value) {
		currentLength = Math.max(currentLength, bit + 1);
		checkSize(bit);

		if (value) {
			barray[bit / 8] |= (1 << (bit % 8));
		} else {
			barray[bit / 8] &= ~(1 << (bit % 8));
		}
	}

	/**
	 * Set up to 32 bits in the bit array
	 * 
	 * @param pos
	 *            position to start from
	 * @param value
	 *            values
	 * @param count
	 *            number of bits to set
	 */
	public void set(int pos, int value, int count) {
		int compareInt;

		for (int i = count - 1; i >= 0; i--) {
			compareInt = (int) Math.pow(2, i);
			set(pos, (compareInt & value) == compareInt);
			pos++;
		}
	}

	/**
	 * Set 8 * values.length bits in the bitarray
	 * 
	 * @param pos
	 *            position to start from
	 * @param values
	 *            values
	 * @param count
	 *            number of bits to set
	 */
	public void set(int pos, byte[] values, int count) {
		int compareInt;
		checkSize(pos);

		for (int j = 0; j < values.length && count > 0; j++)
			for (int i = 7; i >= 0; i--) {
				compareInt = (int) Math.pow(2, i);
				set(pos, (compareInt & values[j]) == compareInt);
				pos++;
				count--;
			}

	}

	/**
	 * Add one bit to end of the bit array
	 * 
	 * @param bit
	 *            index of this bit
	 * @param value
	 *            boolean value
	 */
	public void add(boolean value) {
		set(currentLength, value);
	}

	/**
	 * add up to 32 bits to the end of the bitarray
	 * 
	 * @param value
	 *            value
	 * @param count
	 *            number of bits to set
	 */
	public void add(int value, int count) {
		set(currentLength, value, count);
	}

	/**
	 * Add 8 * values.length bits to the end of the bitarray
	 * 
	 * @param value
	 *            values
	 * 
	 */
	public void add(byte[] values) {
		set(currentLength, values, values.length * 8);
	}

	/**
	 * Add n* values.length bits to the end of the bitarray
	 * 
	 * @param value
	 *            values
	 * @param count
	 *            n
	 * 
	 */
	public void add(byte[] values, int count) {
		set(currentLength, values, count);
	}

	/**
	 * Appends a BitArray to the end of this BitArray
	 * 
	 * @param bitArray
	 *            BitArray to append
	 */
	public void add(BitArray bitArray) {
		for (int i = 0; i < bitArray.length(); i++) {
			add(bitArray.get(i));
		}
	}

	/**
	 * Clear all barray of the bit array
	 */
	public void clear() {
		for (int i = 0; i < barray.length; i++)
			barray[i] = 0;
	}

	/**
	 * Check a bit in the bit array.
	 * 
	 * @param b
	 *            index of this bit
	 * @return boolean value indicating whether this bit has been set.
	 */
	public boolean get(int bit) {
		return 0 != (barray[bit / 8] & (1 << (bit % 8)));
	}

	/**
	 * Get 8 bits starting at the specified position in the bit array.
	 * 
	 * @param bit
	 *            index of start bit
	 * @return boolean value indicating whether this bit has been set.
	 */
	public byte getByte(int bit) {

		byte returnByte = 0;
		for (int i = 7; i >= 0; i--) {
			// System.out.println("getting" + (bit + i));
			if (get(bit + i)) {
				returnByte += Math.pow(2, 7 - i);
			}
		}
		return returnByte;
	}

	/**
	 * Get n bits starting at the specified position in the bit array.
	 * 
	 * @param bit
	 *            index of start bit
	 * @param n
	 *            number of bits to get
	 * @return boolean value indicating whether this bit has been set.
	 */
	public int getInt(int bit, int n) {

		int returnInt = 0;
		for (int i = 0; i < n; i++) {
			// System.out.println("getting" + (bit + i));
			if (get(bit + i)) {
				// System.out.println("adding " + Math.pow(2, n - i));
				returnInt += Math.pow(2, n - i - 1);
			}
		}
		// System.out.println("result " + returnInt);
		return returnInt;
	}

	/**
	 * Get n bits starting at the specified position in the bit array.
	 * 
	 * @param bit
	 *            index of start bit
	 * @param length
	 *            number of bits to get
	 * @return boolean value indicating whether this bit has been set.
	 */
	public byte[] getByteArray(int bit, int length) {
		byte[] returnArray = new byte[(length + 7) / 8];

		for (int i = 0; i < length / 8; i++) {
			returnArray[i] = getByte(bit + i * 8);
		}
		// handle special case if length is not an divisor of 8
		for (int i = 0; i < length % 8; i++) {
			// System.out.println("getting" + (length + bit - (length % 8) +
			// i));
			if (get((length + bit - (length % 8) + i))) {
				// System.out.println("setting" + (length + bit - (length % 8) +
				// i));
				returnArray[returnArray.length - 1] += Math.pow(2, 7 - i);
			}
		}

		return returnArray;
	}

	public BitArray getBitArray(int start, int end) {
		BitArray bitArray = new BitArray();
		for (int i = start; i < end; i++) {
			bitArray.add(get(i));
		}
		return bitArray;
	}

	/**
	 * Get last 8 bits in the bit array as a byte.
	 * 
	 * @param b
	 *            index of start bit
	 * @return boolean value indicating whether this bit has been set.
	 */
	public byte getLastByte() {
		// System.out.println("Current length: " + currentLength);
		return getByte(currentLength - 8);
	}

	/**
	 * get the bits as an byte array, the byte array might contain extra zeroes
	 * at the end
	 * 
	 * @return byte array containg all bits
	 */

	public byte[] toByteArray() {
		return getByteArray(0, currentLength);

	}

	private int countBits(int x) {
		int y = x;
		y = ((y & 0xaaaaaaaa) >>> 1) + (y & 0x55555555);
		y = ((y & 0xcccccccc) >>> 2) + (y & 0x33333333);
		y = ((y & 0xf0f0f0f0) >>> 4) + (y & 0x0f0f0f0f);
		y = ((y & 0xff00ff00) >>> 8) + (y & 0x00ff00ff);
		y = ((y & 0xffff0000) >>> 16) + (y & 0x0000ffff);

		return (int) y;
	}

	/**
	 * count the number of 1's in the bit array.
	 * 
	 * @return the count of 1's
	 */
	public int count() {
		int cnt = 0;
		int xq = size / 32;
		int xr = size % 32;

		for (int i = 0; i < xq; i++)
			cnt += countBits(barray[i]);

		if (0 != xr) {
			cnt += countBits(barray[xq] & ((1 << xr) - 1));
		}

		return cnt;
	}

	/**
	 * convert bit array to a string for printing.
	 */
	public String toString() {
		StringBuffer str = new StringBuffer();

		for (int i = 0; i < currentLength; i++) {
			if (get(i)) {
				str.append('1');
			} else {
				str.append('0');
			}
			if ((i % 8) == 7) {
				str.append(",");
			}
		}

		return str.toString();
	}



	/**
	 * Check if the int array is big enough.
	 * 
	 * @param position
	 *            index of bit
	 */
	private void checkSize(int position) {
		if (position >= size) {
			doubleMaxSize();
			checkSize(position);
		}
	}

	/**
	 * Double max array size
	 * 
	 */
	private void doubleMaxSize() {
		byte[] newArray = new byte[((size * 2) + 7) / 8];

		for (int i = 0; i < barray.length; i++) {
			newArray[i] = barray[i];
		}

		size = size * 2;
		barray = newArray;

		if (debug > 99) {
			System.out.println("increasing size array size to " + size);
		}
	}

}
